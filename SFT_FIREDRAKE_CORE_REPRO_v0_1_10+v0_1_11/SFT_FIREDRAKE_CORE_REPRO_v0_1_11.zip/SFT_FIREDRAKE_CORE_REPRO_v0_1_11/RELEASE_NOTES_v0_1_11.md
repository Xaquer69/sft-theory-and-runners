# Release Notes v0.1.11

## Scope

This release freezes the S-rigidity compliance landscape result.

The central question is:

> Where is the comfortable rigidity band of the S medium?

The package does not fit alpha, does not target `1/137`, and does not claim an
electron/photon derivation. It maps a declared Firedrake medium translation and
classifies whether each case is comfortable, ruptured, residue-contaminated,
subcritical/decoupled, or unavailable.

## Main Result

The focused `nx=128` fixed-time scan reports:

- total cases: 20;
- comfortable cases: 9;
- rupture cases: 5;
- residue/unstable cases: 6;
- unavailable cases: 0;
- comfortable `kappa` bracket: `[0.40, 0.42]`;
- comfortable `amp` bracket: `[0.30, 0.35]`;
- best representative comfortable case: `kappa=0.42`, `amp=0.30`;
- global pass: true.

This means the comfortable band survives the stricter mesh check in the focused
region. The high-amplitude edge ruptures; the higher-`kappa` edge crosses into
persistent scalar residue slightly above the predeclared residue threshold.

## Guardrails

- No thresholds were moved after the `nx=128` result.
- Alpha is not used as an input, target, or pass condition.
- The result should be read as a map of medium compliance, not as a particle
  discovery claim.
- The residue boundary is close to the `0.10` threshold, so future work should
  include declared sensitivity checks rather than post hoc gate changes.

## Next Work

The next scientifically clean step is not an alpha solver. It is a mode-pair
readout performed inside a previously declared comfortable S-compliance window.

Recommended language:

> First map S. Then ask what modes can live there. Only after that read
> relations between modes.
