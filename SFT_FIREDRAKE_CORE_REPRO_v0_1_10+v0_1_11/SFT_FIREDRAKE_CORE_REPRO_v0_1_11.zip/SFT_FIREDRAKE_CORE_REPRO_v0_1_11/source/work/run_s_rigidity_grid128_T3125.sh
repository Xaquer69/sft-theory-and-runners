#!/usr/bin/env bash
set -euo pipefail

# Focused S-rigidity robustness check.
# This maps the compliance window of S; it does not fit or target alpha.

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"

if [ -f "$HOME/firedrake-build/venv-firedrake/bin/activate" ]; then
  # shellcheck disable=SC1091
  . "$HOME/firedrake-build/venv-firedrake/bin/activate"
fi

export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"

env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_focus_grid128_T3125 \
  --kappas 0.40,0.41,0.42,0.43,0.44 \
  --amps 0.30,0.32,0.35,0.38 \
  --nx 128 \
  --ny 128 \
  --T_final 3.125 \
  --cfl 0.0625

python - <<'PY'
import json
from pathlib import Path

report_path = Path("outputs/sft_s_rigidity_landscape_focus_grid128_T3125/SFT_S_RIGIDITY_LANDSCAPE_REPORT.json")
report = json.loads(report_path.read_text(encoding="utf-8"))
summary = report.get("summary", {})
phase_counts = {}
for row in report.get("scan", []):
    phase = row.get("phase", "unknown")
    phase_counts[phase] = phase_counts.get(phase, 0) + 1
print("\n[grid128_T3125 summary]")
print(f"total_cases: {summary.get('total_cases')}")
print(f"comfortable_count: {summary.get('comfortable_count')}")
print(f"rupture_count: {summary.get('rupture_count')}")
print(f"residue_or_unstable_count: {phase_counts.get('residue_or_unstable', 0)}")
print(f"unavailable_count: {summary.get('unavailable_count')}")
print(f"landscape_has_comfortable_band: {summary.get('landscape_has_comfortable_band')}")
print(f"GLOBAL_PASS: {report.get('GLOBAL_PASS')}")
print(f"report: {report_path}")
PY
