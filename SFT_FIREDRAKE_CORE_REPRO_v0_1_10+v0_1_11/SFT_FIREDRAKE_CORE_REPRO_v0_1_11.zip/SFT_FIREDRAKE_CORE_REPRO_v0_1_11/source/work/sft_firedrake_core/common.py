from __future__ import annotations

import json
import math
import hashlib
from pathlib import Path
from typing import Any


def sanitize_json(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_json(v) for v in obj]
    if isinstance(obj, tuple):
        return [sanitize_json(v) for v in obj]
    try:
        import numpy as np

        if isinstance(obj, np.generic):
            return sanitize_json(obj.item())
    except Exception:
        pass
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


def write_report(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(sanitize_json(data), indent=2), encoding="utf-8")


def ensure_dir(path: str | Path) -> Path:
    out = Path(path)
    out.mkdir(parents=True, exist_ok=True)
    return out


def write_json(path: Path, data: dict[str, Any]) -> Path:
    write_report(path, data)
    return path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def finite_or_none(value: float) -> float | None:
    return value if math.isfinite(value) else None


def verdict_from_support(gates_pass: bool, source_amp: float, anchor_strength: float) -> str:
    if not gates_pass:
        return "forbidden"
    if abs(source_amp) <= 1e-15 and abs(anchor_strength) <= 1e-15:
        return "natural"
    return "maintained"
