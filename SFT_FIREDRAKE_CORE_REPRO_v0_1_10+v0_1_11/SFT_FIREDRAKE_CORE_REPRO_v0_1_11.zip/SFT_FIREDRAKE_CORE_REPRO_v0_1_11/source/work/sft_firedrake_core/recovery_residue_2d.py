"""Recovery, dispersion, and residue test for an SFT-like Firedrake medium.

This module asks a deliberately narrow medium-physics question:

    After a localized impulse, does the medium recover toward the base state,
    disperse the impulse over the domain, or retain a localized residue?

No collapse freeze is applied. Any residue reported here is produced by the
field evolution and the stated diagnostics, not by pinning nodes after a gate.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from .common import ensure_dir, finite_or_none, sha256_file, write_json


RUNNER = "sft_firedrake_recovery_residue_2d"
VERSION = "0.1.0"


@dataclass(frozen=True)
class RecoveryParams:
    nx: int = 64
    ny: int = 64
    Lx: float = 8.0
    Ly: float = 8.0
    degree: int = 1
    c: float = 1.0
    cfl: float = 0.125
    steps: int = 400
    kappa: float = 1.0
    lambda4: float = 0.2
    lambda6: float = 0.0
    alpha_capacity: float = 1.0
    capacity_scale: float = 0.5
    amp: float = 0.8
    sigma: float = 0.75
    k0: float = 1.0
    x0_frac: float = -0.45
    y0: float = 0.0
    residue_sigma: float = 1.0
    sample_every: int = 10
    energy_drift_gate: float = 1.0e-3
    recovery_fraction_gate: float = 0.90
    residue_fraction_gate: float = 0.10


def parse_float_list(text: str) -> list[float]:
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out_dir", default="outputs/sft_recovery_residue_2d")
    parser.add_argument("--alphas", default="1.0")
    parser.add_argument("--nx", type=int, default=RecoveryParams.nx)
    parser.add_argument("--ny", type=int, default=RecoveryParams.ny)
    parser.add_argument("--Lx", type=float, default=RecoveryParams.Lx)
    parser.add_argument("--Ly", type=float, default=RecoveryParams.Ly)
    parser.add_argument("--degree", type=int, default=RecoveryParams.degree)
    parser.add_argument("--c", type=float, default=RecoveryParams.c)
    parser.add_argument("--cfl", type=float, default=RecoveryParams.cfl)
    parser.add_argument("--steps", type=int, default=RecoveryParams.steps)
    parser.add_argument("--kappa", type=float, default=RecoveryParams.kappa)
    parser.add_argument("--lambda4", type=float, default=RecoveryParams.lambda4)
    parser.add_argument("--lambda6", type=float, default=RecoveryParams.lambda6)
    parser.add_argument("--capacity_scale", type=float, default=RecoveryParams.capacity_scale)
    parser.add_argument("--amp", type=float, default=RecoveryParams.amp)
    parser.add_argument("--sigma", type=float, default=RecoveryParams.sigma)
    parser.add_argument("--k0", type=float, default=RecoveryParams.k0)
    parser.add_argument("--x0_frac", type=float, default=RecoveryParams.x0_frac)
    parser.add_argument("--y0", type=float, default=RecoveryParams.y0)
    parser.add_argument("--residue_sigma", type=float, default=RecoveryParams.residue_sigma)
    parser.add_argument("--sample_every", type=int, default=RecoveryParams.sample_every)
    parser.add_argument("--energy_drift_gate", type=float, default=RecoveryParams.energy_drift_gate)
    parser.add_argument("--recovery_fraction_gate", type=float, default=RecoveryParams.recovery_fraction_gate)
    parser.add_argument("--residue_fraction_gate", type=float, default=RecoveryParams.residue_fraction_gate)
    return parser


def base_params(args: argparse.Namespace) -> RecoveryParams:
    return RecoveryParams(
        nx=args.nx,
        ny=args.ny,
        Lx=args.Lx,
        Ly=args.Ly,
        degree=args.degree,
        c=args.c,
        cfl=args.cfl,
        steps=args.steps,
        kappa=args.kappa,
        lambda4=args.lambda4,
        lambda6=args.lambda6,
        capacity_scale=args.capacity_scale,
        amp=args.amp,
        sigma=args.sigma,
        k0=args.k0,
        x0_frac=args.x0_frac,
        y0=args.y0,
        residue_sigma=args.residue_sigma,
        sample_every=max(1, args.sample_every),
        energy_drift_gate=args.energy_drift_gate,
        recovery_fraction_gate=args.recovery_fraction_gate,
        residue_fraction_gate=args.residue_fraction_gate,
    )


def run_case(params: RecoveryParams, out_dir: Path) -> dict:
    original_argv = sys.argv[:]
    sys.argv = [sys.argv[0]]
    try:
        from firedrake import (  # type: ignore
            Constant,
            Function,
            FunctionSpace,
            RectangleMesh,
            SpatialCoordinate,
            TestFunction,
            TrialFunction,
            assemble,
            cos,
            dx,
            exp,
            grad,
            inner,
            solve,
        )
    except Exception as exc:  # pragma: no cover - exercised in non-Firedrake envs.
        return {
            "schema_version": "1.0.0",
            "runner": RUNNER,
            "version": VERSION,
            "status": "unavailable",
            "verdict": "not_run",
            "error": f"{type(exc).__name__}: {exc}",
        }
    finally:
        sys.argv = original_argv

    mesh = RectangleMesh(params.nx, params.ny, 2.0 * params.Lx, 2.0 * params.Ly)
    V = FunctionSpace(mesh, "CG", params.degree)
    x, y = SpatialCoordinate(mesh)
    xc = x - Constant(params.Lx)
    yc = y - Constant(params.Ly)

    h = min((2.0 * params.Lx) / params.nx, (2.0 * params.Ly) / params.ny)
    dt = params.cfl * h / max(params.c, 1.0e-30)
    alpha_capacity = max(params.alpha_capacity, 1.0e-30)
    kappa_eff = params.kappa / alpha_capacity
    lambda4_eff = params.lambda4 / alpha_capacity
    lambda6_eff = params.lambda6 / alpha_capacity
    local_capacity = params.capacity_scale * alpha_capacity
    area = 4.0 * params.Lx * params.Ly

    trial = TrialFunction(V)
    v = TestFunction(V)
    S_prev = Function(V, name="S_prev")
    S_cur = Function(V, name="S")
    S_next = Function(V, name="S_next")

    x0 = params.x0_frac * params.Lx
    r2 = (xc - Constant(x0)) ** 2 + (yc - Constant(params.y0)) ** 2
    phase = Constant(params.k0) * (xc - Constant(x0))
    velocity_kick = Constant(params.amp) * exp(-r2 / Constant(2.0 * params.sigma**2)) * cos(phase)
    S_cur.interpolate(Constant(0.0))
    S_prev.interpolate(-Constant(dt) * velocity_kick)

    residue_weight = exp(-r2 / Constant(2.0 * params.residue_sigma**2))

    def potential(s):
        return (
            Constant(0.5 * kappa_eff) * s**2
            + Constant(0.25 * lambda4_eff) * s**4
            + Constant((1.0 / 6.0) * lambda6_eff) * s**6
        )

    def dpotential(s):
        return Constant(kappa_eff) * s + Constant(lambda4_eff) * s**3 + Constant(lambda6_eff) * s**5

    def energy_density(s, s_old):
        velocity = (s - s_old) / Constant(dt)
        return (
            Constant(0.5) * velocity**2
            + Constant(0.5 * params.c**2) * inner(grad(s), grad(s))
            + potential(s)
        )

    def energy_value(s, s_old) -> float:
        return float(assemble(energy_density(s, s_old) * dx))

    def local_energy_value(s, s_old) -> float:
        return float(assemble(residue_weight * energy_density(s, s_old) * dx))

    def l2_value(s) -> float:
        return math.sqrt(max(float(assemble(s**2 * dx)), 0.0))

    def ipr_value(s, s_old, total_energy: float) -> float:
        density = energy_density(s, s_old)
        numerator = float(assemble(density**2 * dx))
        return area * numerator / max(total_energy**2, 1.0e-30)

    mass_form = trial * v * dx
    solver_parameters = {
        "ksp_type": "cg",
        "pc_type": "jacobi",
        "ksp_rtol": 1.0e-10,
        "ksp_atol": 1.0e-12,
    }

    trace = []
    initial_energy = energy_value(S_cur, S_prev)
    initial_local_energy = local_energy_value(S_cur, S_prev)
    final_energy = initial_energy
    final_local_energy = initial_local_energy
    max_l2 = l2_value(S_cur)
    max_local_fraction = initial_local_energy / max(initial_energy, 1.0e-30)
    max_ipr = ipr_value(S_cur, S_prev, initial_energy)

    for step in range(params.steps + 1):
        total_energy = energy_value(S_cur, S_prev)
        local_energy = local_energy_value(S_cur, S_prev)
        local_fraction = local_energy / max(total_energy, 1.0e-30)
        l2_norm = l2_value(S_cur)
        ipr = ipr_value(S_cur, S_prev, total_energy)

        final_energy = total_energy
        final_local_energy = local_energy
        max_l2 = max(max_l2, l2_norm)
        max_local_fraction = max(max_local_fraction, local_fraction)
        max_ipr = max(max_ipr, ipr)

        if step % params.sample_every == 0 or step == params.steps:
            trace.append(
                {
                    "step": step,
                    "time": step * dt,
                    "energy": total_energy,
                    "local_energy": local_energy,
                    "local_energy_fraction": local_fraction,
                    "l2_norm": l2_norm,
                    "energy_ipr": ipr,
                }
            )

        if step == params.steps:
            break

        rhs = (
            (Constant(2.0) * S_cur - S_prev) * v * dx
            - Constant(dt**2 * params.c**2) * inner(grad(S_cur), grad(v)) * dx
            - Constant(dt**2) * dpotential(S_cur) * v * dx
        )
        solve(mass_form == rhs, S_next, solver_parameters=solver_parameters)

        S_prev.assign(S_cur)
        S_cur.assign(S_next)

    energy_drift = abs(final_energy - initial_energy) / max(abs(initial_energy), 1.0e-30)
    final_l2 = l2_value(S_cur)
    return_to_base_fraction = 1.0 - min(final_l2 / max(max_l2, 1.0e-30), 1.0)
    final_residue_fraction = final_local_energy / max(final_energy, 1.0e-30)
    dispersed_fraction = 1.0 - min(final_residue_fraction, 1.0)
    final_ipr = ipr_value(S_cur, S_prev, final_energy)
    capacity_ratio = final_local_energy / max(local_capacity, 1.0e-30)

    finite_energy = math.isfinite(initial_energy) and math.isfinite(final_energy)
    energy_gate_passed = finite_energy and energy_drift <= params.energy_drift_gate
    recovery_gate_passed = return_to_base_fraction >= params.recovery_fraction_gate
    residue_gate_crossed = final_residue_fraction >= params.residue_fraction_gate

    if not finite_energy:
        verdict = "failed_numerics"
    elif residue_gate_crossed and energy_gate_passed:
        verdict = "persistent_residue"
    elif recovery_gate_passed and energy_gate_passed:
        verdict = "recovered_dispersed"
    elif energy_gate_passed:
        verdict = "finite_mixed_recovery"
    else:
        verdict = "finite_but_drifting"

    trace_path = out_dir / "recovery_trace.csv"
    with trace_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "step",
                "time",
                "energy",
                "local_energy",
                "local_energy_fraction",
                "l2_norm",
                "energy_ipr",
            ],
        )
        writer.writeheader()
        writer.writerows(trace)

    report = {
        "schema_version": "1.0.0",
        "runner": RUNNER,
        "version": VERSION,
        "status": "exploratory",
        "question": "Does a perturbed medium recover, disperse, or retain a localized residue?",
        "non_claim": "2D scalar Firedrake medium diagnostic; not a particle derivation and not a Born-rule derivation.",
        "verdict": verdict,
        "medium": asdict(params),
        "discretization": {
            "mesh": "RectangleMesh",
            "space": f"CG{params.degree}",
            "dt": dt,
            "h_min_estimate": h,
            "boundary_condition": "natural_neumann_weak_form",
            "time_scheme": "explicit_central_difference_mass_solve",
            "initial_condition": "zero displacement plus localized velocity impulse",
        },
        "constitutive_translation": {
            "alpha_capacity": params.alpha_capacity,
            "kappa_eff": finite_or_none(kappa_eff),
            "lambda4_eff": finite_or_none(lambda4_eff),
            "lambda6_eff": finite_or_none(lambda6_eff),
            "capacity_scale": params.capacity_scale,
            "local_capacity": finite_or_none(local_capacity),
            "formula": "kappa_eff, lambda4_eff, lambda6_eff = base coefficients / alpha_capacity; local_capacity = capacity_scale * alpha_capacity",
            "sft_interpretation": "alpha_capacity is treated as medium compliance/capacity; the run measures recovery, dispersion, and residue without freezing collapse.",
        },
        "gates": {
            "energy_drift": f"relative drift <= {params.energy_drift_gate}",
            "recovery": f"return_to_base_fraction >= {params.recovery_fraction_gate}",
            "residue": f"final_local_energy_fraction >= {params.residue_fraction_gate}",
            "residue_region": "Gaussian neighborhood around the injected impulse",
        },
        "diagnostics": {
            "initial_energy": finite_or_none(initial_energy),
            "final_energy": finite_or_none(final_energy),
            "energy_drift_rel": finite_or_none(energy_drift),
            "energy_gate_passed": bool(energy_gate_passed),
            "initial_local_energy_fraction": finite_or_none(initial_local_energy / max(initial_energy, 1.0e-30)),
            "final_local_energy_fraction": finite_or_none(final_residue_fraction),
            "dispersed_fraction_proxy": finite_or_none(dispersed_fraction),
            "max_local_energy_fraction": finite_or_none(max_local_fraction),
            "max_l2_norm": finite_or_none(max_l2),
            "final_l2_norm": finite_or_none(final_l2),
            "return_to_base_fraction": finite_or_none(return_to_base_fraction),
            "recovery_gate_passed": bool(recovery_gate_passed),
            "residue_gate_crossed": bool(residue_gate_crossed),
            "final_energy_ipr": finite_or_none(final_ipr),
            "max_energy_ipr": finite_or_none(max_ipr),
            "local_residue_to_alpha_capacity_ratio": finite_or_none(capacity_ratio),
        },
        "outputs": {
            "recovery_trace_csv": str(trace_path),
        },
    }
    return report


def summarize_case(alpha: float, report: dict) -> dict:
    diagnostics = report.get("diagnostics", {})
    constitutive = report.get("constitutive_translation", {})
    return {
        "alpha_capacity": alpha,
        "verdict": report.get("verdict"),
        "kappa_eff": constitutive.get("kappa_eff"),
        "local_capacity": constitutive.get("local_capacity"),
        "energy_drift_rel": diagnostics.get("energy_drift_rel"),
        "energy_gate_passed": diagnostics.get("energy_gate_passed"),
        "final_local_energy_fraction": diagnostics.get("final_local_energy_fraction"),
        "dispersed_fraction_proxy": diagnostics.get("dispersed_fraction_proxy"),
        "return_to_base_fraction": diagnostics.get("return_to_base_fraction"),
        "residue_gate_crossed": diagnostics.get("residue_gate_crossed"),
        "final_energy_ipr": diagnostics.get("final_energy_ipr"),
        "local_residue_to_alpha_capacity_ratio": diagnostics.get("local_residue_to_alpha_capacity_ratio"),
    }


def main() -> None:
    args = build_parser().parse_args()
    out_dir = ensure_dir(args.out_dir)
    params0 = base_params(args)
    alphas = parse_float_list(args.alphas)

    rows = []
    reports = {}
    for alpha in alphas:
        case_dir = ensure_dir(out_dir / f"alpha_{alpha:g}")
        params = replace(params0, alpha_capacity=alpha)
        report = run_case(params, case_dir)
        reports[f"alpha_{alpha:g}"] = report
        rows.append(summarize_case(alpha, report))
        write_json(case_dir / "SFT_RECOVERY_RESIDUE_2D_REPORT.json", report)

    csv_path = out_dir / "recovery_residue_scan.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    finite_rows = [row for row in rows if row.get("energy_drift_rel") is not None]
    energy_pass_count = sum(1 for row in finite_rows if row.get("energy_gate_passed"))
    residue_count = sum(1 for row in finite_rows if row.get("residue_gate_crossed"))
    best_recovery = max(
        finite_rows,
        key=lambda row: row.get("return_to_base_fraction") if row.get("return_to_base_fraction") is not None else -1.0,
        default=None,
    )
    strongest_residue = max(
        finite_rows,
        key=lambda row: row.get("final_local_energy_fraction") if row.get("final_local_energy_fraction") is not None else -1.0,
        default=None,
    )

    report = {
        "schema_version": "1.0.0",
        "runner": RUNNER + "_scan",
        "version": VERSION,
        "status": "exploratory",
        "question": "Across alpha_capacity values, does the medium recover, disperse, or retain residue?",
        "non_claim": "Alpha scan for recovery/residue diagnostics; not a particle identification.",
        "base_medium": asdict(params0),
        "alphas": alphas,
        "decision_rule": {
            "energy": f"relative drift <= {params0.energy_drift_gate}",
            "residue": f"final local energy fraction >= {params0.residue_fraction_gate}",
            "recovery": f"return_to_base_fraction >= {params0.recovery_fraction_gate}",
        },
        "summary": {
            "total_cases": len(rows),
            "finite_cases": len(finite_rows),
            "energy_pass_count": energy_pass_count,
            "residue_count": residue_count,
            "best_recovery_case": best_recovery,
            "strongest_residue_case": strongest_residue,
        },
        "scan": rows,
        "outputs": {
            "recovery_residue_scan_csv": str(csv_path),
        },
    }

    report_path = write_json(out_dir / "SFT_RECOVERY_RESIDUE_SCAN_REPORT.json", report)
    manifest = {
        "SFT_RECOVERY_RESIDUE_SCAN_REPORT.json": sha256_file(report_path),
        "recovery_residue_scan.csv": sha256_file(csv_path),
    }
    for alpha in alphas:
        case_report = out_dir / f"alpha_{alpha:g}" / "SFT_RECOVERY_RESIDUE_2D_REPORT.json"
        case_trace = out_dir / f"alpha_{alpha:g}" / "recovery_trace.csv"
        if case_report.exists():
            manifest[f"alpha_{alpha:g}/SFT_RECOVERY_RESIDUE_2D_REPORT.json"] = sha256_file(case_report)
        if case_trace.exists():
            manifest[f"alpha_{alpha:g}/recovery_trace.csv"] = sha256_file(case_trace)
    write_json(out_dir / "MANIFEST_SHA256.json", manifest)
    print(json.dumps(report, indent=2, sort_keys=False))


if __name__ == "__main__":
    main()
