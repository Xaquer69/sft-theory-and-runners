"""Exploratory 2D SFT dynamic-collapse solver on a Firedrake mesh.

This module asks a deliberately narrow SFT question:

    Given a medium and an initial wrinkle S(x, y), does the field remain a
    finite compatible structure, disperse, or cross a local collapse gate?

It is not a particle derivation. It is a Firedrake translation of the Doc3
minimal scalar-field dynamics plus auditable diagnostics.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from .common import ensure_dir, finite_or_none, sha256_file, write_json


RUNNER = "sft_firedrake_dynamic_collapse_2d"
VERSION = "0.1.0"


@dataclass(frozen=True)
class DynamicParams:
    nx: int = 64
    ny: int = 64
    Lx: float = 8.0
    Ly: float = 8.0
    degree: int = 1
    c: float = 1.0
    cfl: float = 0.125
    steps: int = 250
    alpha_v: float = 0.0
    lambda4: float = 0.2
    lambda6: float = 0.0
    alpha_capacity: float = 1.0
    capacity_scale: float = 0.5
    amp: float = 1.5
    sigma: float = 0.75
    k0: float = 1.0
    x0_frac: float = -0.45
    y0: float = 0.0
    rho_crit: Optional[float] = None
    energy_drift_gate: float = 1.0e-3
    sample_every: int = 10
    freeze_collapsed: bool = True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out_dir", default="outputs/sft_firedrake_dynamic_2d")
    parser.add_argument("--nx", type=int, default=DynamicParams.nx)
    parser.add_argument("--ny", type=int, default=DynamicParams.ny)
    parser.add_argument("--Lx", type=float, default=DynamicParams.Lx)
    parser.add_argument("--Ly", type=float, default=DynamicParams.Ly)
    parser.add_argument("--degree", type=int, default=DynamicParams.degree)
    parser.add_argument("--c", type=float, default=DynamicParams.c)
    parser.add_argument("--cfl", type=float, default=DynamicParams.cfl)
    parser.add_argument("--steps", type=int, default=DynamicParams.steps)
    parser.add_argument("--alpha_v", type=float, default=DynamicParams.alpha_v)
    parser.add_argument("--lambda4", type=float, default=DynamicParams.lambda4)
    parser.add_argument("--lambda6", type=float, default=DynamicParams.lambda6)
    parser.add_argument(
        "--alpha_capacity",
        type=float,
        default=DynamicParams.alpha_capacity,
        help="SFT wrinkle capacity/compliance of the medium.",
    )
    parser.add_argument(
        "--capacity_scale",
        type=float,
        default=DynamicParams.capacity_scale,
        help="Unit conversion from alpha_capacity to local T00 capacity.",
    )
    parser.add_argument("--amp", type=float, default=DynamicParams.amp)
    parser.add_argument("--sigma", type=float, default=DynamicParams.sigma)
    parser.add_argument("--k0", type=float, default=DynamicParams.k0)
    parser.add_argument("--x0_frac", type=float, default=DynamicParams.x0_frac)
    parser.add_argument("--y0", type=float, default=DynamicParams.y0)
    parser.add_argument(
        "--rho_crit",
        type=float,
        default=DynamicParams.rho_crit,
        help="Optional manual capacity override. If omitted, capacity_scale * alpha_capacity is used.",
    )
    parser.add_argument("--energy_drift_gate", type=float, default=DynamicParams.energy_drift_gate)
    parser.add_argument("--sample_every", type=int, default=DynamicParams.sample_every)
    parser.add_argument(
        "--no_freeze_collapsed",
        action="store_true",
        help="Keep evolving nodes after they cross rho_crit.",
    )
    return parser


def params_from_args(args: argparse.Namespace) -> DynamicParams:
    return DynamicParams(
        nx=args.nx,
        ny=args.ny,
        Lx=args.Lx,
        Ly=args.Ly,
        degree=args.degree,
        c=args.c,
        cfl=args.cfl,
        steps=args.steps,
        alpha_v=args.alpha_v,
        lambda4=args.lambda4,
        lambda6=args.lambda6,
        alpha_capacity=args.alpha_capacity,
        capacity_scale=args.capacity_scale,
        amp=args.amp,
        sigma=args.sigma,
        k0=args.k0,
        x0_frac=args.x0_frac,
        y0=args.y0,
        rho_crit=args.rho_crit,
        energy_drift_gate=args.energy_drift_gate,
        sample_every=max(1, args.sample_every),
        freeze_collapsed=not args.no_freeze_collapsed,
    )


def run_solver(params: DynamicParams, out_dir: Path) -> dict:
    original_argv = sys.argv[:]
    sys.argv = [sys.argv[0]]
    try:
        from firedrake import (  # type: ignore
            Constant,
            Function,
            FunctionSpace,
            RectangleMesh,
            SpatialCoordinate,
            TestFunction,
            TrialFunction,
            assemble,
            cos,
            dx,
            exp,
            grad,
            inner,
            solve,
        )
    except Exception as exc:  # pragma: no cover - exercised in non-Firedrake envs.
        return {
            "schema_version": "1.0.0",
            "runner": RUNNER,
            "version": VERSION,
            "status": "unavailable",
            "verdict": "not_run",
            "error": f"{type(exc).__name__}: {exc}",
        }
    finally:
        sys.argv = original_argv

    mesh = RectangleMesh(params.nx, params.ny, 2.0 * params.Lx, 2.0 * params.Ly)
    V = FunctionSpace(mesh, "CG", params.degree)
    x, y = SpatialCoordinate(mesh)
    xc = x - Constant(params.Lx)
    yc = y - Constant(params.Ly)

    h = min((2.0 * params.Lx) / params.nx, (2.0 * params.Ly) / params.ny)
    dt = params.cfl * h / max(params.c, 1.0e-30)
    alpha_capacity = max(params.alpha_capacity, 1.0e-30)
    alpha_derived_capacity = params.capacity_scale * alpha_capacity
    collapse_capacity = params.rho_crit if params.rho_crit is not None else alpha_derived_capacity

    trial = TrialFunction(V)
    v = TestFunction(V)
    S_prev = Function(V, name="S_prev")
    S_cur = Function(V, name="S")
    S_next = Function(V, name="S_next")

    x0 = params.x0_frac * params.Lx
    r2 = (xc - Constant(x0)) ** 2 + (yc - Constant(params.y0)) ** 2
    phase = Constant(params.k0) * (xc - Constant(x0))
    initial = Constant(params.amp) * exp(-r2 / Constant(2.0 * params.sigma**2)) * cos(phase)
    S_cur.interpolate(initial)
    S_prev.interpolate(initial)

    def potential(s):
        return (
            Constant(0.5 * params.alpha_v) * s**2
            + Constant(0.25 * params.lambda4) * s**4
            + Constant((1.0 / 6.0) * params.lambda6) * s**6
        )

    def dpotential(s):
        return (
            Constant(params.alpha_v) * s
            + Constant(params.lambda4) * s**3
            + Constant(params.lambda6) * s**5
        )

    def energy_value(s, s_old) -> float:
        velocity = (s - s_old) / Constant(dt)
        density = (
            Constant(0.5) * velocity**2
            + Constant(0.5 * params.c**2) * inner(grad(s), grad(s))
            + potential(s)
        )
        return float(assemble(density * dx))

    def t00_function(s, s_old):
        t00 = Function(V, name="T00")
        velocity = (s - s_old) / Constant(dt)
        t00.interpolate(
            Constant(0.5) * velocity**2
            + Constant(0.5 * params.c**2) * inner(grad(s), grad(s))
            + potential(s)
        )
        return t00

    mass_form = trial * v * dx
    solver_parameters = {
        "ksp_type": "cg",
        "pc_type": "jacobi",
        "ksp_rtol": 1.0e-10,
        "ksp_atol": 1.0e-12,
    }

    collapsed = None
    trace = []
    initial_energy = energy_value(S_cur, S_prev)
    final_energy = initial_energy
    max_t00_seen = 0.0
    first_collapse_step = None

    for step in range(params.steps + 1):
        t00 = t00_function(S_cur, S_prev)
        t00_data = t00.dat.data_ro
        over_gate = t00_data > collapse_capacity
        if collapsed is None:
            collapsed = over_gate.copy()
        else:
            collapsed |= over_gate

        collapsed_count = int(collapsed.sum())
        max_t00 = float(t00_data.max()) if len(t00_data) else 0.0
        max_t00_seen = max(max_t00_seen, max_t00)
        final_energy = energy_value(S_cur, S_prev)
        if first_collapse_step is None and collapsed_count > 0:
            first_collapse_step = step

        if step % params.sample_every == 0 or step == params.steps:
            trace.append(
                {
                    "step": step,
                    "time": step * dt,
                    "energy": final_energy,
                    "collapsed_nodes": collapsed_count,
                    "max_T00": max_t00,
                }
            )

        if step == params.steps:
            break

        rhs = (
            (Constant(2.0) * S_cur - S_prev) * v * dx
            - Constant(dt**2 * params.c**2) * inner(grad(S_cur), grad(v)) * dx
            - Constant(dt**2) * dpotential(S_cur) * v * dx
        )
        solve(mass_form == rhs, S_next, solver_parameters=solver_parameters)

        if params.freeze_collapsed and collapsed_count:
            S_next.dat.data[collapsed] = S_cur.dat.data_ro[collapsed]

        S_prev.assign(S_cur)
        S_cur.assign(S_next)

    drift = abs(final_energy - initial_energy) / max(abs(initial_energy), 1.0e-30)
    finite_energy = math.isfinite(initial_energy) and math.isfinite(final_energy)
    stable_numerics = finite_energy and drift <= params.energy_drift_gate
    collapse_observed = bool(collapsed is not None and int(collapsed.sum()) > 0)
    capacity_ratio = max_t00_seen / max(collapse_capacity, 1.0e-30)

    if not finite_energy:
        verdict = "failed_numerics"
    elif collapse_observed and first_collapse_step == 0:
        verdict = "initial_gate_crossed"
    elif collapse_observed:
        verdict = "dynamic_collapse_gate_crossed"
    elif stable_numerics:
        verdict = "finite_evolution"
    else:
        verdict = "finite_but_drifting"

    trace_path = out_dir / "energy_trace.csv"
    with trace_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["step", "time", "energy", "collapsed_nodes", "max_T00"])
        writer.writeheader()
        writer.writerows(trace)

    report = {
        "schema_version": "1.0.0",
        "runner": RUNNER,
        "version": VERSION,
        "status": "exploratory",
        "question": "Which alpha-defined wrinkle capacities allow or forbid this impulse?",
        "non_claim": "2D scalar SFT dynamics with a collapse gate; not a particle derivation.",
        "verdict": verdict,
        "medium": asdict(params),
        "discretization": {
            "mesh": "RectangleMesh",
            "space": f"CG{params.degree}",
            "dt": dt,
            "h_min_estimate": h,
            "boundary_condition": "natural_neumann_weak_form",
            "time_scheme": "explicit_central_difference_mass_solve",
        },
        "gates": {
            "alpha_capacity": params.alpha_capacity,
            "capacity_scale": params.capacity_scale,
            "alpha_derived_capacity": finite_or_none(alpha_derived_capacity),
            "rho_crit_override": params.rho_crit,
            "collapse_capacity_used": finite_or_none(collapse_capacity),
            "energy_drift_gate": params.energy_drift_gate,
            "collapse_rule": "local_T00 / alpha_defined_capacity > 1",
            "capacity_formula": "collapse_capacity = rho_crit_override if provided else capacity_scale * alpha_capacity",
            "sft_interpretation": "alpha_capacity defines how far the field can wrinkle before the medium stops dispersing the impulse",
        },
        "diagnostics": {
            "initial_energy": finite_or_none(initial_energy),
            "final_energy": finite_or_none(final_energy),
            "energy_drift_rel": finite_or_none(drift),
            "energy_gate_passed": bool(stable_numerics),
            "collapsed_nodes_final": int(collapsed.sum()) if collapsed is not None else 0,
            "first_collapse_step": first_collapse_step,
            "collapse_origin": "initial_condition" if first_collapse_step == 0 else "dynamic_evolution",
            "max_T00_seen": finite_or_none(max_t00_seen),
            "impulse_to_dispersion_capacity_ratio": finite_or_none(capacity_ratio),
            "energy_note": (
                "Energy conservation is not expected after freeze_collapsed activates; "
                "use --no_freeze_collapsed for a stricter numerical drift test."
            ),
        },
        "outputs": {
            "energy_trace": str(trace_path),
        },
    }
    return report


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    params = params_from_args(args)
    out_dir = ensure_dir(args.out_dir)
    report = run_solver(params, out_dir)
    report_path = write_json(out_dir / "SFT_DYNAMIC_COLLAPSE_2D_REPORT.json", report)
    manifest = {
        "SFT_DYNAMIC_COLLAPSE_2D_REPORT.json": sha256_file(report_path),
    }
    trace_path = out_dir / "energy_trace.csv"
    if trace_path.exists():
        manifest["energy_trace.csv"] = sha256_file(trace_path)
    write_json(out_dir / "MANIFEST_SHA256.json", manifest)
    print(json.dumps(report, indent=2, sort_keys=False))


if __name__ == "__main__":
    main()
