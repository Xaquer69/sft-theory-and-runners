# Reproduce S-Rigidity Landscape v0.1.11

Run from the repository root, inside the Firedrake virtual environment.

If using the same WSL layout as the development run:

```bash
cd /mnt/c/Users/Xavi/Documents/Codex/2026-06-04/files-mentioned-by-the-user-a
. ~/firedrake-build/venv-firedrake/bin/activate
```

## Focused Grid128 Check

```bash
bash work/run_s_rigidity_grid128_T3125.sh
```

Equivalent expanded command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_focus_grid128_T3125 \
  --kappas 0.40,0.41,0.42,0.43,0.44 \
  --amps 0.30,0.32,0.35,0.38 \
  --nx 128 \
  --ny 128 \
  --T_final 3.125 \
  --cfl 0.0625
```

Expected observed summary:

- total cases: 20;
- comfortable cases: 9;
- rupture cases: 5;
- residue/unstable cases: 6;
- unavailable cases: 0;
- comfortable bracket: `kappa=0.40-0.42`, `amp=0.30-0.35`.

## Earlier Comparison Runs

These are included as observed outputs for audit:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_refined \
  --kappas 0.42,0.45,0.48,0.50,0.52,0.55,0.58,0.60 \
  --amps 0.30,0.35,0.38,0.40,0.42,0.45,0.48,0.50 \
  --nx 64 \
  --ny 64 \
  --steps 200 \
  --cfl 0.0625
```

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_refined_grid96_T3125 \
  --kappas 0.42,0.44,0.45,0.46,0.48 \
  --amps 0.32,0.35,0.38,0.40 \
  --nx 96 \
  --ny 96 \
  --T_final 3.125 \
  --cfl 0.0625
```

The fixed-time comparison is important: a finer mesh with fixed step count runs
for a shorter physical time and is not a like-for-like recovery/residue check.
