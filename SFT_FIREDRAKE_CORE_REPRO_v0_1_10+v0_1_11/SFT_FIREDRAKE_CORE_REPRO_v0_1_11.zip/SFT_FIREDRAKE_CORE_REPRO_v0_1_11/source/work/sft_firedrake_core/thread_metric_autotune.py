"""Autotuned SFT thread metric on a Firedrake medium.

This module treats alpha-like quantities as one member of a wider family of
thread metrics:

    R_S[A, B] = permitted same-level fit between two medium configurations.

It does not search for alpha and does not target 1/137. Instead, it computes a
natural same-distortion-level fit for a declared pair:

    A = localized director bend
    B = radiative scalar phase packet

For each geometry, B is first evaluated at unit amplitude. Since this B energy
scales quadratically with amplitude, the module solves the natural amplitude
that matches A's distortion level and then reads the structural thread metric.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from .common import ensure_dir, finite_or_none, sha256_file, write_json


RUNNER = "sft_firedrake_thread_metric_autotune"
VERSION = "0.1.0"


@dataclass(frozen=True)
class ThreadMetricParams:
    nx: int = 96
    ny: int = 96
    Lx: float = 8.0
    Ly: float = 8.0
    degree: int = 1
    c: float = 1.0
    kappa: float = 1.0
    beta0: float = math.pi / 2.0
    sigma_director: float = 1.0
    sigma_wave: float = 2.0
    k0: float = 1.0
    phase: float = 0.0
    r_floor: float = 1.0e-8
    natural_amp_min: float = 1.0e-9
    natural_amp_max: float = 1.0e9
    metric_span_min: float = 1.0e-5


def parse_float_list(text: str) -> list[float]:
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out_dir", default="outputs/sft_thread_metric_autotune")
    parser.add_argument("--kappas", default="0.5,1.0,2.0,4.0")
    parser.add_argument("--sigmas_director", default="0.8,1.0,1.2")
    parser.add_argument("--sigmas_wave", default="2.0")
    parser.add_argument("--k0_values", default="0.8,1.0,1.2")
    parser.add_argument("--phases", default="0.0")
    parser.add_argument("--nx", type=int, default=ThreadMetricParams.nx)
    parser.add_argument("--ny", type=int, default=ThreadMetricParams.ny)
    parser.add_argument("--Lx", type=float, default=ThreadMetricParams.Lx)
    parser.add_argument("--Ly", type=float, default=ThreadMetricParams.Ly)
    parser.add_argument("--degree", type=int, default=ThreadMetricParams.degree)
    parser.add_argument("--c", type=float, default=ThreadMetricParams.c)
    parser.add_argument("--beta0", type=float, default=ThreadMetricParams.beta0)
    parser.add_argument("--natural_amp_min", type=float, default=ThreadMetricParams.natural_amp_min)
    parser.add_argument("--natural_amp_max", type=float, default=ThreadMetricParams.natural_amp_max)
    parser.add_argument("--metric_span_min", type=float, default=ThreadMetricParams.metric_span_min)
    return parser


def base_params(args: argparse.Namespace) -> ThreadMetricParams:
    return ThreadMetricParams(
        nx=args.nx,
        ny=args.ny,
        Lx=args.Lx,
        Ly=args.Ly,
        degree=args.degree,
        c=args.c,
        beta0=args.beta0,
        natural_amp_min=args.natural_amp_min,
        natural_amp_max=args.natural_amp_max,
        metric_span_min=args.metric_span_min,
    )


def run_case(params: ThreadMetricParams) -> dict:
    original_argv = sys.argv[:]
    sys.argv = [sys.argv[0]]
    try:
        from firedrake import (  # type: ignore
            Constant,
            FunctionSpace,
            RectangleMesh,
            SpatialCoordinate,
            assemble,
            cos,
            dx,
            exp,
            grad,
            inner,
            sin,
            sqrt,
        )
    except Exception as exc:  # pragma: no cover
        return {
            "status": "unavailable",
            "verdict": "not_run",
            "error": f"{type(exc).__name__}: {exc}",
        }
    finally:
        sys.argv = original_argv

    mesh = RectangleMesh(params.nx, params.ny, 2.0 * params.Lx, 2.0 * params.Ly)
    FunctionSpace(mesh, "CG", params.degree)
    x, y = SpatialCoordinate(mesh)
    xc = x - Constant(params.Lx)
    yc = y - Constant(params.Ly)
    r2 = xc**2 + yc**2
    r = sqrt(r2 + Constant(params.r_floor**2))
    area = 4.0 * params.Lx * params.Ly

    beta = Constant(params.beta0) * exp(-r2 / Constant(2.0 * params.sigma_director**2))
    radial_x = xc / r
    radial_y = yc / r

    n_x = sin(beta) * radial_x
    n_y = sin(beta) * radial_y
    n_z = cos(beta)
    bend_grad_sq = inner(grad(n_x), grad(n_x)) + inner(grad(n_y), grad(n_y)) + inner(grad(n_z), grad(n_z))
    density_a = Constant(0.5 * params.kappa) * bend_grad_sq

    envelope = exp(-r2 / Constant(2.0 * params.sigma_wave**2))
    wave_unit = envelope * cos(Constant(params.k0) * xc + Constant(params.phase))
    density_b_unit = Constant(0.5 * params.c**2) * inner(grad(wave_unit), grad(wave_unit)) + Constant(0.5 * params.kappa) * wave_unit**2

    energy_a = float(assemble(density_a * dx))
    energy_b_unit = float(assemble(density_b_unit * dx))
    natural_amp = math.sqrt(max(energy_a, 0.0) / max(energy_b_unit, 1.0e-300))
    natural_amp_in_range = params.natural_amp_min <= natural_amp <= params.natural_amp_max

    density_b_natural = Constant(natural_amp**2) * density_b_unit
    energy_b_natural = float(assemble(density_b_natural * dx))

    density_a_l2 = math.sqrt(max(float(assemble(density_a**2 * dx)), 0.0))
    density_b_l2 = math.sqrt(max(float(assemble(density_b_natural**2 * dx)), 0.0))
    level_a = energy_a / max(area, 1.0e-30)
    level_b = energy_b_natural / max(area, 1.0e-30)
    level_ratio = level_b / max(level_a, 1.0e-30)
    log_level_mismatch = abs(math.log(max(level_ratio, 1.0e-30)))

    overlap_l2 = float(assemble(density_a * density_b_natural * dx)) / max(density_a_l2 * density_b_l2, 1.0e-30)
    overlap_sqrt = float(assemble(sqrt((density_a + Constant(1.0e-30)) * (density_b_natural + Constant(1.0e-30))) * dx))
    thread_metric = overlap_sqrt / max(math.sqrt(max(energy_a * energy_b_natural, 0.0)), 1.0e-30)

    finite_values = all(
        math.isfinite(value)
        for value in (
            energy_a,
            energy_b_unit,
            natural_amp,
            energy_b_natural,
            level_ratio,
            log_level_mismatch,
            overlap_l2,
            thread_metric,
        )
    )
    metric_in_range = 0.0 <= thread_metric <= 1.0 + 1.0e-10
    same_level = log_level_mismatch <= 1.0e-10
    gates_pass = finite_values and metric_in_range and natural_amp_in_range and same_level
    verdict = "natural_thread_metric" if gates_pass else "thread_metric_failed"

    return {
        "status": "exploratory",
        "verdict": verdict,
        "thread_key": "R[e_proxy,gamma_proxy]",
        "config_a": "localized_director_bend",
        "config_b": "radiative_scalar_phase_packet",
        "kappa": params.kappa,
        "sigma_director": params.sigma_director,
        "sigma_wave": params.sigma_wave,
        "k0": params.k0,
        "phase": params.phase,
        "energy_a": finite_or_none(energy_a),
        "energy_b_unit_amp": finite_or_none(energy_b_unit),
        "natural_wave_amp": finite_or_none(natural_amp),
        "energy_b_natural_amp": finite_or_none(energy_b_natural),
        "distortion_level_a": finite_or_none(level_a),
        "distortion_level_b": finite_or_none(level_b),
        "distortion_level_ratio_b_over_a": finite_or_none(level_ratio),
        "log_level_mismatch": finite_or_none(log_level_mismatch),
        "density_l2_level_a": finite_or_none(density_a_l2 / math.sqrt(max(area, 1.0e-30))),
        "density_l2_level_b": finite_or_none(density_b_l2 / math.sqrt(max(area, 1.0e-30))),
        "density_shape_overlap_l2": finite_or_none(overlap_l2),
        "same_level_structural_thread_metric": finite_or_none(thread_metric),
        "finite_values": bool(finite_values),
        "metric_in_range": bool(metric_in_range),
        "natural_amp_in_range": bool(natural_amp_in_range),
        "same_distortion_level": bool(same_level),
    }


def summarize_response(rows: list[dict], metric_span_min: float) -> dict:
    good_rows = [
        row
        for row in rows
        if row.get("verdict") == "natural_thread_metric"
        and row.get("same_level_structural_thread_metric") is not None
    ]
    metrics = [float(row["same_level_structural_thread_metric"]) for row in good_rows]
    amps = [float(row["natural_wave_amp"]) for row in good_rows]
    metric_span = max(metrics, default=0.0) - min(metrics, default=0.0)
    amp_span = max(amps, default=0.0) - min(amps, default=0.0)
    best = max(good_rows, key=lambda row: row["same_level_structural_thread_metric"], default=None)
    weakest = min(good_rows, key=lambda row: row["same_level_structural_thread_metric"], default=None)

    return {
        "natural_thread_cases": len(good_rows),
        "metric_min": finite_or_none(min(metrics, default=float("nan"))),
        "metric_max": finite_or_none(max(metrics, default=float("nan"))),
        "metric_span": finite_or_none(metric_span),
        "metric_span_gate_passed": bool(metric_span >= metric_span_min) if len(metrics) > 1 else bool(len(metrics) == 1),
        "natural_wave_amp_min": finite_or_none(min(amps, default=float("nan"))),
        "natural_wave_amp_max": finite_or_none(max(amps, default=float("nan"))),
        "natural_wave_amp_span": finite_or_none(amp_span),
        "best_thread_case": best,
        "weakest_thread_case": weakest,
    }


def write_scan_csv(path: Path, rows: list[dict]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = build_parser().parse_args()
    out_dir = ensure_dir(args.out_dir)
    params0 = base_params(args)
    kappas = parse_float_list(args.kappas)
    sigmas_director = parse_float_list(args.sigmas_director)
    sigmas_wave = parse_float_list(args.sigmas_wave)
    k0_values = parse_float_list(args.k0_values)
    phases = parse_float_list(args.phases)

    rows = []
    for kappa in kappas:
        for sigma_director in sigmas_director:
            for sigma_wave in sigmas_wave:
                for k0 in k0_values:
                    for phase in phases:
                        params = replace(
                            params0,
                            kappa=kappa,
                            sigma_director=sigma_director,
                            sigma_wave=sigma_wave,
                            k0=k0,
                            phase=phase,
                        )
                        rows.append(run_case(params))

    csv_path = out_dir / "thread_metric_autotune_scan.csv"
    write_scan_csv(csv_path, rows)

    total = len(rows)
    unavailable = [row for row in rows if row.get("verdict") == "not_run"]
    good_rows = [row for row in rows if row.get("verdict") == "natural_thread_metric"]
    response = summarize_response(rows, params0.metric_span_min)
    global_pass = not unavailable and len(good_rows) == total and response["metric_span_gate_passed"]

    report = {
        "schema_version": "1.0.0",
        "runner": RUNNER,
        "version": VERSION,
        "status": "exploratory",
        "question": "What natural same-level thread metric is permitted for R[e_proxy,gamma_proxy]?",
        "non_claim": (
            "This is not alpha and does not target 1/137. It measures one structural thread metric "
            "from a declared pair of same-medium configurations."
        ),
        "base_medium": asdict(params0),
        "scan_axes": {
            "kappas": kappas,
            "sigmas_director": sigmas_director,
            "sigmas_wave": sigmas_wave,
            "k0_values": k0_values,
            "phases": phases,
        },
        "gates": {
            "natural_amplitude": "wave amplitude is solved from energy_density_level_B == energy_density_level_A",
            "same_distortion_level": "|log(level_B/level_A)| <= 1e-10 after autotune",
            "metric_range": "0 <= same_level_structural_thread_metric <= 1",
            "metric_span": f"metric span >= {params0.metric_span_min}, unless a one-case smoke test is used",
            "sft_interpretation": (
                "thread metrics are permitted same-level fits between compatible configurations of one medium"
            ),
        },
        "summary": {
            "total_cases": total,
            "natural_thread_cases": len(good_rows),
            "unavailable_cases": len(unavailable),
            "response": response,
            "GLOBAL_PASS": bool(global_pass),
        },
        "scan": rows,
        "outputs": {
            "thread_metric_autotune_scan_csv": str(csv_path),
        },
    }

    report_path = write_json(out_dir / "SFT_THREAD_METRIC_AUTOTUNE_REPORT.json", report)
    manifest = {
        "SFT_THREAD_METRIC_AUTOTUNE_REPORT.json": sha256_file(report_path),
        "thread_metric_autotune_scan.csv": sha256_file(csv_path),
    }
    write_json(out_dir / "MANIFEST_SHA256.json", manifest)
    print(json.dumps(report, indent=2, sort_keys=False))


if __name__ == "__main__":
    main()
