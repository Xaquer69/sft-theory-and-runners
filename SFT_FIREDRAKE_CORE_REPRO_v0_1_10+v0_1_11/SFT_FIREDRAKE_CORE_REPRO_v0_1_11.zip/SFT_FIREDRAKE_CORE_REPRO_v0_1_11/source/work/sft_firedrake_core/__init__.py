"""SFT Firedrake Core v0."""

__version__ = "0.0.1"
