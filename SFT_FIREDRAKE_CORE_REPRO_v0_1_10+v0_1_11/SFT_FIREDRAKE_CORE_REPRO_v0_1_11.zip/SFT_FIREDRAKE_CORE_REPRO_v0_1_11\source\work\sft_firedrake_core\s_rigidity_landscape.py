"""Rigidity landscape scan for the SFT medium S on a Firedrake mesh.

This module does not fit alpha and does not target 1/137.

It asks a prior medium question:

    For which declared S-rigidity values does the medium fail to couple,
    remain comfortably compatible, or cross a rupture/collapse boundary?

The scan treats kappa as the declared rigidity of S. For each kappa and impulse
amplitude it combines three existing Firedrake diagnostics:

1. dynamic rupture: does local T00 cross a declared rupture capacity?
2. scalar recovery/residue: does the medium disperse without trapped scalar
   residue?
3. same-level thread metric: do localized/director and radiative/wave proxy
   configurations have a nontrivial same-level fit?

Alpha is deliberately absent from the decision rule. If an alpha-like scale is
later read from this landscape, it must come from a reproducible comfortable
band, not from a target value.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from .common import ensure_dir, sha256_file, write_json
from .dynamic_collapse_2d import DynamicParams, run_solver as run_dynamic_solver
from .recovery_residue_2d import RecoveryParams, run_case as run_recovery_case
from .thread_metric_autotune import ThreadMetricParams, run_case as run_thread_case


RUNNER = "sft_firedrake_s_rigidity_landscape"
VERSION = "0.1.0"


def parse_float_list(text: str) -> list[float]:
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out_dir", default="outputs/sft_s_rigidity_landscape")
    parser.add_argument("--kappas", default="0.25,0.5,0.75,1.0,1.5,2.0,3.0,4.0")
    parser.add_argument("--amps", default="0.4,0.6,0.8,1.0,1.2,1.5,2.0")
    parser.add_argument("--nx", type=int, default=64)
    parser.add_argument("--ny", type=int, default=64)
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument(
        "--T_final",
        type=float,
        default=None,
        help="Optional physical final time. If provided, steps is computed from cfl, mesh spacing, and c.",
    )
    parser.add_argument("--cfl", type=float, default=0.0625)
    parser.add_argument("--c", type=float, default=1.0)
    parser.add_argument("--lambda4", type=float, default=0.2)
    parser.add_argument("--lambda6", type=float, default=0.0)
    parser.add_argument("--sigma", type=float, default=0.75)
    parser.add_argument("--k0", type=float, default=1.0)
    parser.add_argument(
        "--rupture_scale",
        type=float,
        default=0.5,
        help="Declared rupture capacity is rupture_scale * kappa.",
    )
    parser.add_argument("--energy_drift_gate", type=float, default=1.0e-3)
    parser.add_argument("--residue_fraction_gate", type=float, default=0.10)
    parser.add_argument("--thread_metric_min", type=float, default=0.05)
    parser.add_argument("--thread_metric_max", type=float, default=0.95)
    parser.add_argument(
        "--write_case_reports",
        action="store_true",
        help="Write nested dynamic/recovery reports for every scanned point.",
    )
    return parser


def classify_case(
    dynamic_report: dict,
    recovery_report: dict,
    thread_report: dict,
    thread_metric_min: float,
    thread_metric_max: float,
) -> str:
    dynamic_verdict = dynamic_report.get("verdict")
    recovery_verdict = recovery_report.get("verdict")
    thread_metric = thread_report.get("same_level_structural_thread_metric")
    thread_ok = (
        thread_report.get("verdict") == "natural_thread_metric"
        and thread_metric is not None
        and thread_metric_min <= float(thread_metric) <= thread_metric_max
    )

    if "not_run" in {dynamic_verdict, recovery_verdict, thread_report.get("verdict")}:
        return "unavailable"
    if dynamic_verdict in {"initial_gate_crossed", "dynamic_collapse_gate_crossed"}:
        return "rupture"
    if dynamic_verdict in {"failed_numerics", "finite_but_drifting"}:
        return "unstable"
    if recovery_verdict in {"persistent_residue", "failed_numerics", "finite_but_drifting"}:
        return "residue_or_unstable"
    if not thread_ok:
        return "subcritical_or_decoupled"
    return "comfortable_compatibility"


def summarize_case(kappa: float, amp: float, dynamic_report: dict, recovery_report: dict, thread_report: dict, phase: str) -> dict:
    dyn_diag = dynamic_report.get("diagnostics", {})
    rec_diag = recovery_report.get("diagnostics", {})
    return {
        "kappa": kappa,
        "amp": amp,
        "phase": phase,
        "dynamic_verdict": dynamic_report.get("verdict"),
        "recovery_verdict": recovery_report.get("verdict"),
        "thread_verdict": thread_report.get("verdict"),
        "rupture_capacity": dynamic_report.get("gates", {}).get("collapse_capacity_used"),
        "max_T00_seen": dyn_diag.get("max_T00_seen"),
        "impulse_to_capacity_ratio": dyn_diag.get("impulse_to_dispersion_capacity_ratio"),
        "collapsed_nodes_final": dyn_diag.get("collapsed_nodes_final"),
        "first_collapse_step": dyn_diag.get("first_collapse_step"),
        "dynamic_energy_drift_rel": dyn_diag.get("energy_drift_rel"),
        "recovery_energy_drift_rel": rec_diag.get("energy_drift_rel"),
        "final_local_energy_fraction": rec_diag.get("final_local_energy_fraction"),
        "dispersed_fraction_proxy": rec_diag.get("dispersed_fraction_proxy"),
        "return_to_base_fraction": rec_diag.get("return_to_base_fraction"),
        "residue_gate_crossed": rec_diag.get("residue_gate_crossed"),
        "same_level_thread_metric": thread_report.get("same_level_structural_thread_metric"),
        "natural_wave_amp": thread_report.get("natural_wave_amp"),
        "density_shape_overlap_l2": thread_report.get("density_shape_overlap_l2"),
    }


def write_scan_csv(path: Path, rows: list[dict]) -> None:
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def summarize_landscape(rows: list[dict]) -> dict:
    total = len(rows)
    comfortable = [row for row in rows if row["phase"] == "comfortable_compatibility"]
    rupture = [row for row in rows if row["phase"] == "rupture"]
    decoupled = [row for row in rows if row["phase"] == "subcritical_or_decoupled"]
    unavailable = [row for row in rows if row["phase"] == "unavailable"]

    comfortable_kappas = sorted({float(row["kappa"]) for row in comfortable})
    comfortable_amps = sorted({float(row["amp"]) for row in comfortable})

    best_sofa = None
    if comfortable:
        best_sofa = min(
            comfortable,
            key=lambda row: (
                abs((row.get("impulse_to_capacity_ratio") or 0.0) - 0.5),
                row.get("final_local_energy_fraction") or 1.0e9,
                -(row.get("same_level_thread_metric") or 0.0),
            ),
        )

    return {
        "total_cases": total,
        "comfortable_count": len(comfortable),
        "rupture_count": len(rupture),
        "subcritical_or_decoupled_count": len(decoupled),
        "unavailable_count": len(unavailable),
        "comfortable_kappa_values": comfortable_kappas,
        "comfortable_amp_values": comfortable_amps,
        "comfortable_kappa_bracket": (
            [min(comfortable_kappas), max(comfortable_kappas)] if comfortable_kappas else None
        ),
        "comfortable_amp_bracket": [min(comfortable_amps), max(comfortable_amps)] if comfortable_amps else None,
        "best_sofa_candidate": best_sofa,
        "landscape_has_comfortable_band": bool(len(comfortable) > 0),
    }


def main() -> None:
    args = build_parser().parse_args()
    out_dir = ensure_dir(args.out_dir)
    kappas = parse_float_list(args.kappas)
    amps = parse_float_list(args.amps)
    rows: list[dict] = []
    h = min(16.0 / args.nx, 16.0 / args.ny)
    dt = args.cfl * h / max(args.c, 1.0e-30)
    steps = args.steps if args.T_final is None else max(1, int(math.ceil(args.T_final / dt)))
    physical_T = steps * dt

    for kappa in kappas:
        thread_params = ThreadMetricParams(
            nx=args.nx,
            ny=args.ny,
            c=args.c,
            kappa=kappa,
            sigma_wave=2.0,
            k0=args.k0,
        )
        thread_report = run_thread_case(thread_params)

        for amp in amps:
            case_dir = ensure_dir(out_dir / f"kappa_{kappa:g}_amp_{amp:g}")
            rupture_capacity = args.rupture_scale * kappa
            dynamic_params = DynamicParams(
                nx=args.nx,
                ny=args.ny,
                c=args.c,
                cfl=args.cfl,
                steps=steps,
                alpha_v=kappa,
                lambda4=args.lambda4,
                lambda6=args.lambda6,
                amp=amp,
                sigma=args.sigma,
                k0=args.k0,
                rho_crit=rupture_capacity,
                energy_drift_gate=args.energy_drift_gate,
                freeze_collapsed=True,
            )
            recovery_params = RecoveryParams(
                nx=args.nx,
                ny=args.ny,
                c=args.c,
                cfl=args.cfl,
                steps=steps,
                kappa=kappa,
                lambda4=args.lambda4,
                lambda6=args.lambda6,
                alpha_capacity=1.0,
                capacity_scale=args.rupture_scale,
                amp=amp,
                sigma=args.sigma,
                k0=args.k0,
                energy_drift_gate=args.energy_drift_gate,
                residue_fraction_gate=args.residue_fraction_gate,
            )

            dynamic_dir = ensure_dir(case_dir / "dynamic")
            recovery_dir = ensure_dir(case_dir / "recovery")
            dynamic_report = run_dynamic_solver(dynamic_params, dynamic_dir)
            recovery_report = run_recovery_case(recovery_params, recovery_dir)
            phase = classify_case(
                dynamic_report,
                recovery_report,
                thread_report,
                args.thread_metric_min,
                args.thread_metric_max,
            )
            rows.append(summarize_case(kappa, amp, dynamic_report, recovery_report, thread_report, phase))

            if args.write_case_reports:
                write_json(case_dir / "SFT_DYNAMIC_COLLAPSE_2D_REPORT.json", dynamic_report)
                write_json(case_dir / "SFT_RECOVERY_RESIDUE_2D_REPORT.json", recovery_report)
                write_json(case_dir / "SFT_THREAD_METRIC_AUTOTUNE_REPORT.json", thread_report)

    csv_path = out_dir / "s_rigidity_landscape.csv"
    write_scan_csv(csv_path, rows)
    summary = summarize_landscape(rows)
    global_pass = bool(summary["landscape_has_comfortable_band"])

    report = {
        "schema_version": "1.0.0",
        "runner": RUNNER,
        "version": VERSION,
        "status": "exploratory",
        "question": "Where is the comfortable rigidity band of the S medium?",
        "non_claim": (
            "This does not fit alpha, does not target 1/137, and does not derive electron or photon physics. "
            "It maps subcritical, comfortable, and rupture regimes for a declared S-rigidity scan."
        ),
        "scan_axes": {
            "kappas": kappas,
            "amps": amps,
        },
        "fixed_medium": {
            "nx": args.nx,
            "ny": args.ny,
            "c": args.c,
            "cfl": args.cfl,
            "steps": steps,
            "dt": dt,
            "physical_T": physical_T,
            "T_final_requested": args.T_final,
            "lambda4": args.lambda4,
            "lambda6": args.lambda6,
            "sigma": args.sigma,
            "k0": args.k0,
            "rupture_capacity_formula": "rho_crit = rupture_scale * kappa",
            "rupture_scale": args.rupture_scale,
        },
        "decision_rule": {
            "subcritical_or_decoupled": "same-level thread metric is absent or outside the declared nontrivial range",
            "comfortable_compatibility": (
                "no dynamic rupture, no scalar residue/instability, and thread metric within declared range"
            ),
            "rupture": "dynamic local T00 crosses declared rho_crit",
            "unavailable": "one or more Firedrake sub-diagnostics could not run",
            "alpha_guardrail": "alpha is not an input target; this scan reports the S-rigidity landscape only",
        },
        "thresholds": {
            "energy_drift_gate": args.energy_drift_gate,
            "residue_fraction_gate": args.residue_fraction_gate,
            "thread_metric_min": args.thread_metric_min,
            "thread_metric_max": args.thread_metric_max,
        },
        "summary": summary,
        "GLOBAL_PASS": global_pass,
        "scan": rows,
        "outputs": {
            "s_rigidity_landscape_csv": str(csv_path),
        },
    }

    report_path = write_json(out_dir / "SFT_S_RIGIDITY_LANDSCAPE_REPORT.json", report)
    manifest = {
        "SFT_S_RIGIDITY_LANDSCAPE_REPORT.json": sha256_file(report_path),
        "s_rigidity_landscape.csv": sha256_file(csv_path),
    }
    write_json(out_dir / "MANIFEST_SHA256.json", manifest)
    print(json.dumps(report, indent=2, sort_keys=False))


if __name__ == "__main__":
    main()
