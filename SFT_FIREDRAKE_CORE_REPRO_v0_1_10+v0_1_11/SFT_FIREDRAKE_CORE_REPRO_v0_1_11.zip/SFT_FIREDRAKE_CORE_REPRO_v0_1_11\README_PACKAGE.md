# SFT Firedrake Core Repro v0.1.11

Exploratory Firedrake reproducibility package for the S-rigidity compliance
landscape.

This package is not a derivation of alpha, not a target fit to `1/137`, and not
a derivation of electron or photon physics. It preserves a focused result:
within a declared scalar/director Firedrake translation, a comfortable
S-compliance band appears between rupture and persistent scalar residue.

## What changed from v0.1.10

v0.1.11 adds the S-rigidity landscape gate:

- the medium rigidity parameter `kappa` and impulse amplitude `amp` are scanned;
- physical time is fixed with `T_final=3.125` for mesh comparisons;
- cases are classified as comfortable compatibility, rupture,
  subcritical/decoupled, residue/unstable, or unavailable;
- alpha is explicitly guarded out of the decision rule.

Observed focused result:

- `nx=128`, `T_final=3.125`, `cfl=0.0625`;
- 20 total cases;
- 9 comfortable cases;
- 5 rupture cases;
- 6 residue/unstable cases;
- 0 unavailable cases;
- comfortable bracket: `kappa=0.40-0.42`, `amp=0.30-0.35`;
- best sofa candidate: `kappa=0.42`, `amp=0.30`;
- global pass: true.

Interpretation: this is stronger mesh-robustness evidence for an S-compliance
window in the current Firedrake translation. It is not an alpha result.

## Included Outputs

- `outputs/sft_s_rigidity_landscape_edge_refined/`
  - `nx=64`, refined scan, fixed steps from the original run.
- `outputs/sft_s_rigidity_landscape_edge_refined_grid96_T3125/`
  - `nx=96`, fixed physical time `T_final=3.125`.
- `outputs/sft_s_rigidity_landscape_focus_grid128_T3125/`
  - `nx=128`, focused fixed-time check.

The earlier non-comparable `nx=96`, fixed-step run is intentionally not part of
the main package evidence because it used a shorter physical time.

## Layout

- `source/work/sft_firedrake_core/`: source modules needed by the S-rigidity
  landscape runner.
- `source/work/run_s_rigidity_grid128_T3125.sh`: focused reproduction command.
- `source/work/SFT_S_RIGIDITY_LANDSCAPE_SAVE_NOTE_v0_1_0.md`: development
  audit note and interpretation record.
- `outputs/`: observed outputs included for audit convenience.
- `MANIFEST_SHA256.txt`: SHA256 hashes for packaged files.
- `RELEASE_NOTES_v0_1_11.md`: reviewer-safe scope statement.

For strict reproduction, run the commands in
`source/work/sft_firedrake_core/REPRODUCE.md` inside the Firedrake virtual
environment and compare fresh outputs against the included reports.
