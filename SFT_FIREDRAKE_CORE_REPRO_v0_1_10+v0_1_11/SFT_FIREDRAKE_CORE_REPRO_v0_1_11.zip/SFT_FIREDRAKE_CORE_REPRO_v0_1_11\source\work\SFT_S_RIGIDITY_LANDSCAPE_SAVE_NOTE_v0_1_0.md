# SFT S-Rigidity Landscape Save Note v0.1.0

Date: 2026-06-26

Purpose: preserve the first Firedrake S-rigidity landscape pass used to look for
the comfortable rigidity band of the medium S without fitting alpha and without
targeting 1/137.

## Code

Module:

`work/sft_firedrake_core/s_rigidity_landscape.py`

SHA256 initial:

`3DF52138D0AD9E02DD6144D816EBEE964B663C074089EC5C89D5BCB67C6107A9`

SHA256 after adding `--T_final` physical-time control:

`884F32CA5CA4ED883786E4F64D578AD96D33D8C96E769BD4332EDA53ECDAE314`

## Guardrail

This module does not fit alpha. It scans declared S-rigidity `kappa` and impulse
amplitude `amp`, then classifies each point as:

- `subcritical_or_decoupled`
- `comfortable_compatibility`
- `rupture`
- `residue_or_unstable`
- `unstable`
- `unavailable`

The intended SFT reading is:

`subcritical -> comfortable S band -> rupture/residue`

Alpha, if later recovered, must be read from the medium landscape. It is not an
input target.

## Smoke Run

Command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_smoke \
  --kappas 0.5,1.0,2.0 \
  --amps 0.6,0.8,1.0 \
  --nx 32 \
  --ny 32 \
  --steps 100
```

Result summary:

- total cases: 9
- comfortable: 0
- rupture: 8
- unavailable: 0

Interpretation: the initial scan was mostly over the rupture wall.

## Edge Smoke

Command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_smoke \
  --kappas 0.4,0.5,0.6,0.8,1.0 \
  --amps 0.2,0.3,0.4,0.5,0.55,0.6 \
  --nx 32 \
  --ny 32 \
  --steps 100
```

Result summary:

- total cases: 30
- comfortable: 5
- rupture: 15
- comfortable kappa bracket: `[0.4, 0.5]`
- comfortable amp bracket: `[0.2, 0.4]`
- best sofa candidate: `kappa=0.5`, `amp=0.3`

Interpretation: a first comfortable S band appeared.

## Refined Run

Command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_refined \
  --kappas 0.42,0.45,0.48,0.50,0.52,0.55,0.58,0.60 \
  --amps 0.30,0.35,0.38,0.40,0.42,0.45,0.48,0.50 \
  --nx 64 \
  --ny 64 \
  --steps 200 \
  --cfl 0.0625
```

Result summary:

- total cases: 64
- comfortable: 5
- rupture: 33
- comfortable kappa bracket: `[0.42, 0.45]`
- comfortable amp bracket: `[0.30, 0.38]`
- best sofa candidate: `kappa=0.45`, `amp=0.3`

Important refined edge cases:

- `kappa=0.42`, `amp=0.35`: comfortable
- `kappa=0.42`, `amp=0.38`: rupture, ratio approximately `1.000625`
- `kappa=0.45`, `amp=0.38`: comfortable, ratio approximately `0.955153`
- `kappa=0.45`, `amp=0.40`: rupture, ratio approximately `1.010712`
- `kappa=0.48`, `amp=0.30`: persistent scalar residue appears, local fraction approximately `0.100774`

Interpretation: the refined scan suggests a narrow comfortable S-rigidity island
around `kappa ~= 0.42-0.45`, bounded by dynamic rupture on the impulse side and
scalar residue on the higher-rigidity side.

## Next Reproducibility Check

The first `nx=96`, `steps=200` robustness command is not a strict
physical-time comparison with the `nx=64`, `steps=200` refined run, because
`dt = cfl*h/c` changes with mesh spacing. At fixed `steps`, the finer mesh runs
for a shorter physical time and therefore can retain more local scalar energy.

To compare like with like, use the new `--T_final` option or scale steps with
mesh resolution. The `nx=64`, `steps=200`, `cfl=0.0625` run has physical time
approximately `T = 3.125`. For `nx=96`, the equivalent fixed-time run requires
about `steps=300`.

Proposed grid robustness command with fixed physical time:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_refined_grid96_T3125 \
  --kappas 0.42,0.44,0.45,0.46,0.48 \
  --amps 0.32,0.35,0.38,0.40 \
  --nx 96 \
  --ny 96 \
  --T_final 3.125 \
  --cfl 0.0625
```

Pass criterion for the next step: the comfortable band should reappear near the
same `kappa` range without retuning thresholds or targeting alpha.

## Grid96 Fixed-Time Run

Command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_edge_refined_grid96_T3125 \
  --kappas 0.42,0.44,0.45,0.46,0.48 \
  --amps 0.32,0.35,0.38,0.40 \
  --nx 96 \
  --ny 96 \
  --T_final 3.125 \
  --cfl 0.0625
```

Result summary:

- total cases: 20
- comfortable: 2
- rupture: 6
- comfortable kappa bracket: `[0.42, 0.42]`
- comfortable amp bracket: `[0.32, 0.35]`
- best sofa candidate: `kappa=0.42`, `amp=0.32`
- fixed physical time: `T=3.125`
- computed steps: `300`

Important fixed-time grid96 edge cases:

- `kappa=0.42`, `amp=0.32`: comfortable, residue absent, ratio approximately `0.728687`
- `kappa=0.42`, `amp=0.35`: comfortable, residue absent, ratio approximately `0.872109`
- `kappa=0.42`, `amp=0.38`: rupture, ratio approximately `1.052880`
- `kappa=0.44`, `amp=0.32`: persistent scalar residue just above threshold, local fraction approximately `0.100349`
- `kappa=0.44`, `amp=0.38`: no rupture, but persistent scalar residue, ratio approximately `0.989795`

Interpretation: after fixing physical time, the comfortable S-rigidity band
reappears under mesh refinement, but it narrows and shifts to the lower edge of
the previous bracket. This is a partial robustness result, not a final
convergence claim. The next required check is a focused scan around
`kappa=0.40-0.44` and `amp=0.30-0.38`, preferably across `nx=64,96,128` with
the same `T_final`.

## Grid128 Focused Fixed-Time Check

Purpose: test whether the S-rigidity comfortable window survives a stricter
mesh refinement at the same physical time, without retuning thresholds and
without targeting alpha.

Prepared runner:

```bash
bash work/run_s_rigidity_grid128_T3125.sh
```

Expanded command:

```bash
env -u PETSC_DIR -u PETSC_ARCH python -m work.sft_firedrake_core.s_rigidity_landscape \
  --out_dir outputs/sft_s_rigidity_landscape_focus_grid128_T3125 \
  --kappas 0.40,0.41,0.42,0.43,0.44 \
  --amps 0.30,0.32,0.35,0.38 \
  --nx 128 \
  --ny 128 \
  --T_final 3.125 \
  --cfl 0.0625
```

Expected interpretation rule:

- If a comfortable band reappears, the S-compliance window has stronger
  mesh-robustness evidence.
- If the band disappears, this is a valid negative result for this translation
  or for the current gates.
- In neither case should thresholds be moved after the fact to recover a pass.

Output target:

```text
outputs/sft_s_rigidity_landscape_focus_grid128_T3125/
```

Result summary:

- total cases: 20
- comfortable: 9
- rupture: 5
- residue_or_unstable: 6
- unavailable: 0
- comfortable kappa bracket: `[0.40, 0.42]`
- comfortable amp bracket: `[0.30, 0.35]`
- best sofa candidate: `kappa=0.42`, `amp=0.30`
- fixed physical time: `T=3.125`
- computed steps: `400`
- `GLOBAL_PASS`: true

Important grid128 focused edge cases:

- `kappa=0.40`, `amp=0.35`: comfortable, ratio approximately `0.920537`
- `kappa=0.40`, `amp=0.38`: rupture, ratio approximately `1.409355`
- `kappa=0.42`, `amp=0.35`: comfortable, ratio approximately `0.883878`
- `kappa=0.42`, `amp=0.38`: rupture, ratio approximately `1.239752`
- `kappa=0.43`, `amp=0.30`: persistent scalar residue just above threshold, local fraction approximately `0.100377`
- `kappa=0.44`, `amp=0.30`: persistent scalar residue, local fraction approximately `0.100815`

Report hash:

```text
SHA256(outputs/sft_s_rigidity_landscape_focus_grid128_T3125/SFT_S_RIGIDITY_LANDSCAPE_REPORT.json)
= 28B3A478F4E2773A6E508E3B03163CF49AF26CD9137689D79AA34630DD83A2A4
```

Interpretation: the comfortable S-rigidity band survives the stricter `nx=128`
fixed-time scan and appears as a coherent focused region around `kappa=0.40-0.42`
and `amp=0.30-0.35`. The high-amplitude edge ruptures, while the higher-kappa
edge crosses into persistent scalar residue very close to the predeclared
`0.10` residue threshold. This is stronger mesh-robustness evidence for an
S-compliance window, not an alpha result.
