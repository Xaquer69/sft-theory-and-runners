
# Reproducibility — Doc 4 (CPU-only)

This pack is the quick, CPU-only reviewer helper for the SFT Release Candidate.

## What to check quickly
- Text guardrails and PPN integration: signature (−,+,+,+); S ≡ −U; Δϖ formula with (β,γ); α policy (α-in) stated.
- Figures/notes: Mercury uses (a=0.387 AU, e≈0.206) for ≈43″/century; any ≈150″ plot is flagged as *synthetic* (a≈0.24 AU) for error-scaling only.
- Consistent unit policy: Δx in u.m. with SI shown only in captions.

## Quick integrity
All files are listed in `/_meta/MANIFEST.json` and hashed in `checksums_SHA256.txt`.
