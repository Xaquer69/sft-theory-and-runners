# G-Factor data formats
Aceptados por scripts/calc_gfactor.py:

1) CSV con columna g_est (recomendado)
   B_T,freq_hz,g_est
   0.50,2.803e10,2.0021
   ...

2) CSV con B y frecuencia (calculado como g = h*nu/(mu_B*B))
   B_T,freq_hz
   0.50,2.803e10
   0.55,3.083e10
   ...

3) Tripletes verticales (fallback; para datos antiguos)
   B
   mu
   g_est
   (se repite)

Etiqueta tus datasets como (C) calibración o (P) predicción.

---

### Notes on PPN metrics
- **Shapiro (two-way):** All expectations are expressed as *two-way* light-time delay with closest approach near the solar limb: **248.05 µs**.
- **Deflection:** Expected stellar light deflection at the solar limb: **1.75 arcsec**.
- **Key names:** JSON fields use `deflection_arcsec` and `shapiro_us`.
