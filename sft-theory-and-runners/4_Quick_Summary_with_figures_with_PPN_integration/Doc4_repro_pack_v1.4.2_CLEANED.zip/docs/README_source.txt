
SFT (Structural-Field Theory) — Supplementary Data Package
=========================================================

This archive contains all data and code required to reproduce the main
figures and numerical results of the manuscript:

    "Structural‑Field Theory: Bridging Quantum and Solar‑System Scales"

Directory layout
----------------
data/
  varpi_series_0-1M.csv   – perihelion angle ϖ(t) every 1000 steps
  ppn_summary.txt         – numerical values of β, γ, α₁, α₂

  (Placeholder) U_tail_fit.csv
  (Placeholder) g_factor_raw.csv
  The two placeholder files will be added in the public Zenodo record.

code/
  perihelio_fit.ipynb     – Jupyter notebook that reproduces Fig. 2
  requirements.txt        – Python dependencies

figures/
  perihelio_fit.png       – high‑resolution version of Fig. 2
  error_scaling.png       – high‑resolution version of Fig. 3

Reproducing the figures
-----------------------
1. Create a Python 3.10 virtual environment and install the requirements:

   pip install -r code/requirements.txt

2. Run the Jupyter notebook:

   jupyter notebook code/perihelio_fit.ipynb

3. The notebook will read *data/varpi_series_0-1M.csv* and regenerate
   the fit plot (Fig. 2) and the residuals.

License
-------
Data: Creative Commons Attribution 4.0 International (CC‑BY‑4.0)
Code: MIT License

Authors
-------
Francisco Queral Rallo
ChatGPT Assistant (OpenAI)

Generated: 2025-07-10T16:26:37.058472 UTC
