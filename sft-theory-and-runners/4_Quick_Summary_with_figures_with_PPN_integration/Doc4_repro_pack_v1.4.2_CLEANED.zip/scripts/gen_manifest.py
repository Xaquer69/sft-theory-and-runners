#!/usr/bin/env python3
import argparse, hashlib
from pathlib import Path
def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    ap.add_argument('--output', default='MANIFEST_SHA256.txt')
    a=ap.parse_args()
    root=Path(a.root)
    files=sorted([p for p in root.rglob('*') if p.is_file() and p.name!=a.output])
    with open(a.output,'w',encoding='utf-8') as f:
        for p in files:
            rel=p.relative_to(root).as_posix()
            f.write(f"{sha256_file(p)}  {rel}\n")
    print(f"Wrote {a.output} with {len(files)} entries.")
if __name__=='__main__':
    main()
