#!/usr/bin/env python3
import subprocess, json, sys, os
def run(cmd):
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
        return 0, out
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--profile', choices=['test','mercury'], default=None,
                    help="Ajusta sólo la expectativa de perihelio: 'test'~150″, 'mercury'~43″.")
    args,_ = ap.parse_known_args()
    profile_expect = {'value': 42.99, 'tol': 0.20}
    if args.profile == 'test':
        profile_expect = {'value': 150.863, 'tol': 0.5}
    elif args.profile == 'mercury':
        profile_expect = {'value': 42.99, 'tol': 0.20}

    root = os.path.dirname(os.path.abspath(__file__)) + '/..'
    data = os.path.join(root, 'data')
    scripts = os.path.join(root, 'scripts')
    report = {'perihelio_fit': None, 'ppn': None, 'g_factor': None}
    peri_csv = os.path.join(data, 'varpi_series_0-1M.csv')
    # Selección automática del dataset según --profile
    if args.profile == 'test':
        test_csv = os.path.join(data, 'varpi_series_test.csv')
        if os.path.exists(test_csv):
            peri_csv = test_csv
        else:
            # Fallback seguro si el CSV de test no existe
            print('[WARN] varpi_series_test.csv no encontrado; usando varpi_series_0-1M.csv')
    if os.path.exists(peri_csv):
        code, out = run(['python', os.path.join(scripts,'perihelio_fit.py'), '--csv', peri_csv,
                         '--expect-slope', str(profile_expect['value']), '--tol', str(profile_expect['tol'])])
        try: report['perihelio_fit'] = json.loads(out)
        except Exception: report['perihelio_fit']={'raw':out,'exit_code':code}
    else:
        report['perihelio_fit']={'error':'missing varpi_series_0-1M.csv'}
    ppn_file = os.path.join(data, 'ppn_summary.txt')
    if os.path.exists(ppn_file):
        code, out = run(['python', os.path.join(scripts,'ppn_check.py'),
                         '--summary', ppn_file])
        try: report['ppn'] = json.loads(out)
        except Exception: report['ppn']={'raw':out,'exit_code':code}
    else:
        report['ppn']={'error':'missing ppn_summary.txt'}
    g_raw = os.path.join(data, 'g_factor_raw.csv')
    if os.path.exists(g_raw):
        code, out = run(['python', os.path.join(scripts,'calc_gfactor.py'),
                         '--raw', g_raw, '--expect', '2.0022', '--tol', '0.0003'])
        try: report['g_factor'] = json.loads(out)
        except Exception: report['g_factor']={'raw':out,'exit_code':code}
    else:
        report['g_factor']={'error':'missing g_factor_raw.csv'}
    print(json.dumps(report, indent=2))
    with open(os.path.join(root,'Quick_Report.json'),'w',encoding='utf-8') as f:
        f.write(json.dumps(report, indent=2))
if __name__=='__main__':
    main()
