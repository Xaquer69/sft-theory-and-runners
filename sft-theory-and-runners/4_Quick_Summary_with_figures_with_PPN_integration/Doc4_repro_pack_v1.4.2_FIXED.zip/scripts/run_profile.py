#!/usr/bin/env python3
import argparse, subprocess, json, os, sys
def run(cmd):
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
        return 0, out
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output
def main():
    ap = argparse.ArgumentParser(description='Ejecuta quick_report con un perfil predefinido.')
    ap.add_argument('--profile', choices=['test','mercury'], required=True)
    args = ap.parse_args()
    root = os.path.dirname(os.path.abspath(__file__)) + '/..'
    code, out = run(['python', os.path.join(root,'scripts','quick_report.py'), '--profile', args.profile])
    print(out)
    with open(os.path.join(root, f'Quick_Report_{args.profile}.json'), 'w', encoding='utf-8') as f:
        f.write(out)
    sys.exit(code)
if __name__ == '__main__':
    main()
