#!/usr/bin/env python3
import argparse, json, math, sys, csv, statistics
from pathlib import Path
H = 6.62607015e-34
MU_B = 9.2740100783e-24
def detect_delim(path):
    sample = Path(path).read_text(encoding='utf-8', errors='ignore')[:4096]
    if '\t' in sample and (sample.count('\t') > sample.count(',')):
        return '\t'
    return ','
def try_float(x):
    try:
        return float(str(x).strip())
    except Exception:
        return None
def read_csv_rows(path):
    delim = detect_delim(path)
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        rdr = csv.DictReader(f, delimiter=delim)
        rows = [{(k.strip() if k is not None else k):(v.strip() if isinstance(v,str) else v) for k,v in row.items()} for row in rdr]
    return rows
def parse_vertical_triplets(path):
    txt = Path(path).read_text(encoding='utf-8', errors='ignore').strip().splitlines()
    vals, buf = [], []
    for line in txt:
        line=line.strip()
        if not line: 
            continue
        try:
            buf.append(float(line))
        except Exception:
            buf=[]
            continue
        if len(buf)==3:
            vals.append({'B_T':buf[0],'mu':buf[1],'g_est':buf[2]})
            buf=[]
    return vals
def calc_from_rows(rows):
    g_vals=[]
    for row in rows:
        g=None
        for key in ['g_est','g','g_factor','g_hat','ĝ']:
            if key in row and row[key] not in ('',None):
                g = try_float(row[key]); break
        if g is not None and math.isfinite(g):
            g_vals.append(g); continue
        B=None
        for key in ['B_tesla','B_T','B']:
            if key in row: B = try_float(row[key]); 
            if B is not None: break
        nu=None
        for key in ['freq_hz','nu_hz','f_hz','frequency_hz']:
            if key in row: nu = try_float(row[key])
            if nu is not None: break
        if nu is None:
            omega=None
            for key in ['omega_rad_s','omega','w_rad_s']:
                if key in row: omega = try_float(row[key])
                if omega is not None: break
            if omega is not None:
                nu = omega/(2*math.pi)
        if B is not None and nu is not None and B != 0:
            g = (H*nu)/(MU_B*B)
            if math.isfinite(g): g_vals.append(g)
    if not g_vals:
        raise ValueError('No pude extraer g: añade g_est o columnas B y (freq_hz|omega_rad_s).')
    mean = statistics.mean(g_vals)
    std  = statistics.pstdev(g_vals) if len(g_vals)>1 else 0.0
    sem  = std/math.sqrt(len(g_vals)) if len(g_vals)>1 else 0.0
    return {'n':len(g_vals),'g_mean':mean,'g_std':std,'g_sem':sem}
def main():
    ap=argparse.ArgumentParser(description='Compute g-factor summary')
    ap.add_argument('--raw', required=True)
    ap.add_argument('--expect', type=float, default=None)
    ap.add_argument('--tol', type=float, default=3e-4)
    a=ap.parse_args()
    try:
        rows = read_csv_rows(a.raw)
    except Exception:
        rows = []
    if not rows:
        rows = parse_vertical_triplets(a.raw)
    payload = calc_from_rows(rows)
    if a.expect is not None:
        ok = abs(payload['g_mean'] - a.expect) <= a.tol
        payload['check'] = {'expect':a.expect,'tol':a.tol,'pass':ok}
        print(json.dumps(payload, indent=2)); sys.exit(0 if ok else 1)
    print(json.dumps(payload, indent=2))
if __name__=='__main__':
    main()
