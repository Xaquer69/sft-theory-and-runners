#!/usr/bin/env python3
import argparse, json, math, re, sys
from pathlib import Path
def parse_pairs(path):
    text = Path(path).read_text(encoding='utf-8', errors='ignore')
    pairs = {}
    for line in text.splitlines():
        line=line.strip()
        if not line or line.startswith('#'): continue
        m=re.match(r'([A-Za-z0-9_]+)\s*[:=]\s*(.+)', line)
        if not m: continue
        k=m.group(1).lower(); v=m.group(2)
        val=None; unc=None
        m2=re.match(r'([-+]?[\d\.Ee+-]+)\s*(?:\+/-|±)\s*([-+]?[\d\.Ee+-]+)', v)
        if m2:
            try:
                val=float(m2.group(1)); unc=float(m2.group(2))
            except Exception: pass
        else:
            nums=re.findall(r'[-+]?[\d\.Ee+-]+', v)
            if nums:
                try: val=float(nums[0])
                except Exception: pass
        if val is not None:
            pairs[k]={'value':val}
            if unc is not None: pairs[k]['unc']=unc
    return pairs
def main():
    ap=argparse.ArgumentParser(description='Verifica PPN y pruebas de luz')
    ap.add_argument('--summary', required=True)
    ap.add_argument('--beta', type=float, default=1.0)
    ap.add_argument('--beta_tol', type=float, default=1e-4)
    ap.add_argument('--gamma', type=float, default=1.0)
    ap.add_argument('--gamma_tol', type=float, default=1e-5)
    ap.add_argument('--deflection_arcsec', type=float, default=1.75)
    ap.add_argument('--deflection_tol', type=float, default=0.02)
    ap.add_argument('--shapiro_us', type=float, default=248.05)
    ap.add_argument('--shapiro_tol', type=float, default=0.1)
    a=ap.parse_args()
    pairs=parse_pairs(a.summary)
    out={'inputs':{'beta':a.beta,'beta_tol':a.beta_tol,'gamma':a.gamma,'gamma_tol':a.gamma_tol,
                   'deflection_arcsec':a.deflection_arcsec,'deflection_tol':a.deflection_tol,
                   'shapiro_us':a.shapiro_us,'shapiro_tol':a.shapiro_tol},
         'measurements':pairs, 'checks':{}}
    status=0
    def check(name, expect, tol, keys):
        nonlocal status
        for k in keys:
            if k in pairs:
                val=pairs[k]['value']
                ok = abs(val-expect) <= tol
                out['checks'][name]={'value':val,'expect':expect,'tol':tol,'pass':ok}
                if not ok: status=1
                return
        out['checks'][name]={'error':f'Faltan claves {keys}'}
        status=1
    check('beta', a.beta, a.beta_tol, ['beta'])
    check('gamma', a.gamma, a.gamma_tol, ['gamma'])
    check('deflection_arcsec', a.deflection_arcsec, a.deflection_tol, ['deflection','deflection_arcsec','alpha_arcsec'])
    check('shapiro_us', a.shapiro_us, a.shapiro_tol, ['shapiro','shapiro_us','shapiro_delay_us'])
    print(json.dumps(out, indent=2)); sys.exit(status)
if __name__=='__main__':
    main()
