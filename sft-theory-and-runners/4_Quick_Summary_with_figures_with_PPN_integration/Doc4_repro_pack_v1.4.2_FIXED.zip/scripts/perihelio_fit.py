#!/usr/bin/env python3
import argparse, json, math, sys, csv
from pathlib import Path
def detect_delim(path):
    sample = Path(path).read_text(encoding='utf-8', errors='ignore')[:4096]
    if '\t' in sample and (sample.count('\t') > sample.count(',')):
        return '\t'
    return ','
def read_xy(path, t_col=None, y_col=None):
    delim = detect_delim(path)
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        rdr = csv.DictReader(f, delimiter=delim)
        cols = rdr.fieldnames or []
        rows = list(rdr)
    def find_col(cands):
        for c in cands:
            for col in cols:
                if col.lower()==c or c in col.lower():
                    return col
        return None
    t_col = t_col or find_col(['t_century','t_centuries','century','centuries','time_century','time_centuries','t','time','step'])
    y_col = y_col or find_col(['varpi_arcsec','perihelion_arcsec','omega_arcsec','varpi','perihelion','omega'])
    if t_col is None or y_col is None:
        raise ValueError(f'No pude detectar columnas. Columnas: {cols}')
    T,Y=[],[]
    for row in rows:
        try:
            t=float(row[t_col]); y=float(row[y_col])
        except Exception:
            continue
        if math.isfinite(t) and math.isfinite(y):
            T.append(t); Y.append(y)
    if len(T)<2:
        raise ValueError('Datos insuficientes para ajuste')
    return T,Y,t_col,y_col
def linregress_np(x,y):
    import numpy as np
    x=np.asarray(x,float); y=np.asarray(y,float)
    n=x.size
    X=np.vstack([x, np.ones(n)]).T
    beta,resid,rank,s = np.linalg.lstsq(X,y,rcond=None)
    slope=beta[0]; intercept=beta[1]
    if resid.size==0:
        yhat=slope*x+intercept
        resid=float(((y-yhat)**2).sum())
    else:
        resid=float(resid[0])
    yhat=slope*x+intercept
    n=len(x)
    s_err=(float(((y-yhat)**2).sum())/(n-2))**0.5 if n>2 else float('nan')
    x_mean=float(x.mean())
    sxx=float(((x-x_mean)**2).sum())
    slope_se = s_err/(sxx**0.5) if (sxx>0 and n>2) else float('nan')
    rms=float((((y-yhat)**2).mean())**0.5)
    return slope,intercept,slope_se,rms
def main():
    ap=argparse.ArgumentParser(description='Ajuste de ϖ(t)')
    ap.add_argument('--csv', required=True)
    ap.add_argument('--t-col'); ap.add_argument('--y-col')
    ap.add_argument('--t-unit', choices=['century','years','days','seconds','steps'], default='century')
    ap.add_argument('--dt', type=float, default=None)
    ap.add_argument('--varpi-unit', choices=['arcsec','deg','rad'], default='arcsec')
    ap.add_argument('--expect-slope', type=float, default=None)
    ap.add_argument('--tol', type=float, default=0.20)
    a=ap.parse_args()
    T,Y,tcol,ycol = read_xy(a.csv, a.t_col, a.y_col)
    import numpy as np
    T=np.asarray(T,float); Y=np.asarray(Y,float)
    if a.varpi_unit=='deg': Y=Y*3600.0
    elif a.varpi_unit=='rad': Y=Y*(180.0/math.pi)*3600.0
    if a.t_unit=='years': T=T/100.0
    elif a.t_unit=='days': T=T/36525.0
    elif a.t_unit=='seconds': T=T/(36525.0*24*3600.0)
    elif a.t_unit=='steps':
        if a.dt is None: sys.exit('--dt requerido si t-unit=steps')
        T = T*(a.dt/(36525.0*24*3600.0))
    slope,intercept,slope_se,rms = linregress_np(T,Y)
    payload={'n':int(len(T)),'t_col':tcol,'y_col':ycol,
             'slope_arcsec_per_century':float(slope),
             'slope_se':(float(slope_se) if slope_se==slope_se else None),
             'intercept_arcsec':float(intercept),
             'residual_rms_arcsec':float(rms)}
    if a.expect_slope is not None:
        ok = abs(payload['slope_arcsec_per_century']-a.expect_slope) <= a.tol
        payload['check']={'expect_slope':a.expect_slope,'tol':a.tol,'pass':bool(ok)}
        print(json.dumps(payload, indent=2)); sys.exit(0 if ok else 1)
    print(json.dumps(payload, indent=2))
if __name__=='__main__':
    main()
