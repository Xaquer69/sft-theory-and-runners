# Doc4 Reproducibility Pack (v1)
Reúne scripts y datos para verificar **Perihelio**, **PPN** y **g-factor** con checks automáticos (PASS/FAIL).

## Uso rápido
```bash
python scripts/quick_report.py
```


> **Nota CPU-only**: Este pack reproduce los **pipelines (C)** con datos incluidos; **no** ejecuta la campaña GPU de generación (P).
> Python de referencia: 3.11.9 en Linux x86_64; instala dependencias con `pip install -r requirements.txt`.

### Selección de dataset por `--profile`
- `--profile mercury` → usa `data/varpi_series_0-1M.csv` y espera **42.99 ± 0.20″/siglo**.
- `--profile test` → usa `data/varpi_series_test.csv` (si existe) y espera **150.863 ± 0.5″/siglo**. Si el CSV no está, hace *fallback* al de Mercury y avisa con `[WARN]`.


Más comandos y detalles en el README completo (sección Units & Calibration, formatos, tolerancias) que puedes ampliar.


## Perfiles listos para usar
- **test**: espera ~150.86″/siglo (serie de prueba).
- **mercury**: espera ~42.99″/siglo (Mercurio real).

Ejemplos:
```bash
python scripts/run_profile.py --profile test
python scripts/run_profile.py --profile mercury
```

## Plantillas y ejemplos
- PPN: `docs/PPN_EXAMPLE_summary.txt`
- g-factor (formato): `docs/GFACTOR_FORMAT.md`
- Dataset sintético de demo (NO usar para claims): `data/synthetic/g_factor_synth_demo_(synthetic).csv`

## Buenas prácticas
- Distingue (C) calibración vs (P) predicción en README y metadatos.
- Añade `MANIFEST_SHA256.txt` con `python scripts/gen_manifest.py` antes de publicar.


## CPU-only addendum (v1.4.1)
Este paquete incluye datasets **(C) de calibración generados por CPU**:
- `data/varpi_series_0-1M.csv` → serie *Mercury-real* basada en la fórmula PPN de precesión (Schwarzschild).
- `data/g_factor_raw.csv` → dataset sintético alrededor de 2.0022.
- `data/ppn_summary.txt` → valores estándar (β≈1, γ≈1, deflection≈1.75", Shapiro≈248.05 μs (Cassini-like, dos vías)).

> Nota: Estos datos sirven para validar **pipelines** y tablas/figuras (C). No sustituyen los resultados (P) de la simulación GPU.

## Notas de verificación rápida (PASS/FAIL)

- Ejecuta `python scripts/quick_report.py --profile mercury` para generar `artifacts/Quick_Report_mercury.json`.
- Cada bloque reporta `status: PASS` o `FAIL`. Un `PASS` indica que el valor observado cae dentro de la tolerancia definida (p.ej., perihelio 42.99″±0.20, Shapiro 248.05 μs).
- Si algún check marca `FAIL`, revisa que estés usando las **versiones fijadas** en `requirements-lock.txt`.

## Semillas y determinismo

Este pack usa únicamente lectura de CSV y cálculos deterministas en CPU. No se emplea aleatoriedad; no se requieren semillas. Si introduces sampling/ruido en futuras versiones, documenta `SEED` aquí.

## Proveniencia de datos (resumen)

- `data/varpi_series_0-1M.csv` se generó con la corrección de perihelio (PPN, Schwarzschild) y parámetros orbitales de Mercurio; el ajuste debe dar ~42.99″/siglo con σ∝1/√N.
- `data/ppn_summary.txt` refleja la deflection estándar (≈1.7500″ a R⊙) y **Shapiro dos‑vías ≈ 248.05 μs** para geometría de conjunción superior.

---

### Notes on PPN metrics
- **Shapiro (two-way):** All expectations are expressed as *two-way* light-time delay with closest approach near the solar limb: **248.05 µs**.
- **Deflection:** Expected stellar light deflection at the solar limb: **1.75 arcsec**.
- **Key names:** JSON fields use `deflection_arcsec` and `shapiro_us`.
