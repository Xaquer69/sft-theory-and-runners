# Reviewer Quick Guide

This package is **CPU-only** and is meant to *verify* the reported (C) results using included datasets.
It does **not** re-generate the raw physics data.

## 1) Prerequisites
- Python 3.9+ recommended
- `pip install -r requirements.txt`

## 2) One-command verification
```bash
make quick        # or: python scripts/quick_report.py
```
This generates `Quick_Report.json` with PASS/FAIL for:
- Perihelion (Mercury)
- PPN summary (β≈1, γ≈1, deflection ≈ 1.75″, Shapiro ≈ 248.05 μs)  *(read from included summary file)*
- g-factor (mean ≈ 2.0022 ± 0.0003)  *(computed from included CSV)*

### Optional: choose a profile
```bash
make quick PROFILE=test
# or:
python scripts/quick_report.py --profile test
```

## 3) Show the report contents
```bash
make report
```
Prints the contents of `Quick_Report.json` (pretty).

## 4) Clean up
```bash
make clean
```

## Notes
- This is a **verification kit (C)**: it validates numbers using included artifacts and scripts.
- For end-to-end regeneration of datasets (GPU/AMR), use the separate numerical core or GPU-enabled repo when available.
- If you hit environment issues, create a virtualenv and reinstall requirements.

*Esta guía rápida está pensada para revisores. Si prefieres todo en español, dímelo y añado un README ES completo.*
