# BUILD GUIDE (tce_gpu_full integration)

Consulta BUILD_AUDIT.json para ver referencias de CMake e includes faltantes.
Para CUDA, ajusta `CMAKE_CUDA_ARCHITECTURES=<SM_ARCHES>` según tu GPU (p.ej., 80 para A100).

---

### Notes on PPN metrics
- **Shapiro (two-way):** All expectations are expressed as *two-way* light-time delay with closest approach near the solar limb: **248.05 µs**.
- **Deflection:** Expected stellar light deflection at the solar limb: **1.75 arcsec**.
- **Key names:** JSON fields use `deflection_arcsec` and `shapiro_us`.
