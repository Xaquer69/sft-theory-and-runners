# SFT Firedrake Solver Mini-Pack v1.2.2
> Pack version: **v1.2.2**. Bundled runner version: **sft_firedrake_solver_improved_v1_1.py** (`__version__ = 1.1.0`).

Cleaner audit-friendly mini-pack for exploratory/CI use in the SFT corpus.

## Layout
- `runner/` — main runner source
- `verify_runner.py` — artifact verifier
- `schemas/` — JSON schema for reports
- `examples/benchmark1d_solver/` — example CI artifacts
- `examples/dispersion_expected/` — example expected-curve artifacts
- `examples/topology3d_exploratory/` — example exploratory artifacts
- `checksums_SHA256.txt` — non-self-referential checksum list for the pack

## Modes
- `benchmark1d_solver` — 1D numerical benchmark (**CI**)
- `dispersion_expected` — analytical expected curve exporter (**CI**)
- `topology3d_exploratory` — ansatz-based 3D diagnostics (**exploratory**)

Backward-compatible aliases:
- `benchmark1d` -> `benchmark1d_solver`
- `dispersion` -> `dispersion_expected`
- `topology3d` -> `topology3d_exploratory`

## Quick start

### Benchmark
```bash
python runner/sft_firedrake_solver_improved_v1_1.py --mode benchmark1d_solver --T 5.0 --nx 200 --out_dir out_bench
python verify_runner.py --mode benchmark1d_solver --out_dir out_bench
```

### Expected dispersion
```bash
python runner/sft_firedrake_solver_improved_v1_1.py --mode dispersion_expected --nx 100 --out_dir out_disp
python verify_runner.py --mode dispersion_expected --out_dir out_disp
```

### Exploratory topology diagnostic
```bash
python runner/sft_firedrake_solver_improved_v1_1.py --mode topology3d_exploratory --nx 48 --L 8.0 --out_dir out_topo
python verify_runner.py --mode topology3d_exploratory --out_dir out_topo
```

## Status discipline
- `CI` = pipeline/runner validation only, not physical confirmation.
- `exploratory` = ansatz/post-processing diagnostic, not solved 3D field evolution.
- `REAL-ready` is not claimed by this mini-pack.

## Non-claims
- `dispersion_expected` does not measure dispersion from solved dynamics.
- `topology3d_exploratory` does not solve the 3D PDE; it evaluates prescribed ansatz fields.

## Verification contract
`verify_runner.py` checks:
- required files exist
- `DECISION_RULE.json` exists and matches the report's `decision_rule_sha256`
- report validates against the schema (if `jsonschema` is installed)
- the manifest hashes the exported artifacts

## Recommendation
Treat this pack as a clean base for corpus integration and further hardening, not as the final canonical production solver.

## Manifest policy
This mini-pack uses a **non-self-referential manifest policy by design**. This differs from some older Doc14-era bundles that appended a self-hash line. Here, `MANIFEST_SHA256.txt` hashes exported artifacts only, while `checksums_SHA256.txt` covers the pack itself.

## Minimal requirements
Install:
```bash
pip install -r requirements.txt
```

`Firedrake` is optional and should be installed separately if you want the actual Firedrake branch of `benchmark1d_solver`.

## Pack-level verification
To verify the pack itself (including `checksums_SHA256.txt` and all example directories):
```bash
python verify_pack.py
```
