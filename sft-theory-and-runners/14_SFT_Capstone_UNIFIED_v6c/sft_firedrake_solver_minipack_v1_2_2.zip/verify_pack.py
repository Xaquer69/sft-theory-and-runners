#!/usr/bin/env python3
import argparse
import hashlib
import pathlib
import subprocess
import sys
sys.dont_write_bytecode = True

ROOT = pathlib.Path(__file__).resolve().parent

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def parse_checksums(root: pathlib.Path):
    checksum_path = root / "checksums_SHA256.txt"
    if not checksum_path.exists():
        raise SystemExit("FAIL: checksums_SHA256.txt not found")
    lines = [ln.strip() for ln in checksum_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if not lines:
        raise SystemExit("FAIL: checksums_SHA256.txt is empty")
    listed = {}
    for ln in lines:
        parts = ln.split()
        if len(parts) < 2:
            raise SystemExit(f"FAIL: malformed checksum line: {ln}")
        expected = parts[0]
        relname = parts[-1]
        if relname == "checksums_SHA256.txt":
            raise SystemExit("FAIL: checksums_SHA256.txt must not include itself")
        listed[relname] = expected
    return listed

def verify_checksums(root: pathlib.Path, strict: bool = False):
    listed = parse_checksums(root)
    for relname, expected in listed.items():
        fpath = root / relname
        if not fpath.exists():
            raise SystemExit(f"FAIL: missing file listed in checksums: {relname}")
        got = sha256_file(fpath)
        if got != expected:
            raise SystemExit(f"FAIL: checksum mismatch for {relname}")

    if strict:
        actual = set()
        for p in root.rglob("*"):
            if p.is_file():
                rel = p.relative_to(root).as_posix()
                if "__pycache__/" in rel or rel.endswith(".pyc"):
                    raise SystemExit(f"FAIL: strict mode found forbidden cache artifact: {rel}")
                actual.add(rel)
        expected_files = set(listed.keys()) | {"checksums_SHA256.txt"}
        extras = sorted(actual - expected_files)
        if extras:
            raise SystemExit("FAIL: strict mode found unlisted files:\n" + "\n".join(extras))

def verify_examples(root: pathlib.Path):
    verifier = root / "verify_runner.py"
    examples = [
        ("benchmark1d_solver", root / "examples" / "benchmark1d_solver"),
        ("dispersion_expected", root / "examples" / "dispersion_expected"),
        ("topology3d_exploratory", root / "examples" / "topology3d_exploratory"),
    ]
    for mode, out_dir in examples:
        proc = subprocess.run(
            [sys.executable, str(verifier), "--mode", mode, "--out_dir", str(out_dir)],
            capture_output=True, text=True
        )
        if proc.returncode != 0:
            raise SystemExit(f"FAIL: verify_runner failed for {mode}\n{proc.stdout}\n{proc.stderr}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--strict", action="store_true", help="Fail if any file exists in the pack but is not listed in checksums_SHA256.txt")
    args = ap.parse_args()
    root = pathlib.Path(args.root).resolve()
    verify_checksums(root, strict=args.strict)
    verify_examples(root)
    if args.strict:
        print("GLOBAL_PASS = true")
        print("Pack checksums + example artifacts verified (strict mode)")
    else:
        print("GLOBAL_PASS = true")
        print("Pack checksums + example artifacts verified")

if __name__ == "__main__":
    main()
