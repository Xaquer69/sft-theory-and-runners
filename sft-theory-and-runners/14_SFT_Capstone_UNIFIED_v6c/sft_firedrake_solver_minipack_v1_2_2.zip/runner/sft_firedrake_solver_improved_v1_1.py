#!/usr/bin/env python3
"""
sft_firedrake_solver_improved_v1_1.py
=====================================

Improved audit-friendly runner for Structural Field Theory (SFT).

Key improvements
----------------
1) Non-self-referential manifest.
2) Explicit DECISION_RULE.json + gate_id + decision_rule_sha256.
3) Clear mode names:
     - benchmark1d_solver
     - dispersion_expected
     - topology3d_exploratory
   Backward-compatible aliases:
     benchmark1d -> benchmark1d_solver
     dispersion  -> dispersion_expected
     topology3d  -> topology3d_exploratory
4) The scheme is described accurately: centered second-order acceleration residual
   with implicit nonlinear solve in the Firedrake branch.
5) Explicit status labels: CI / exploratory / REAL-ready.

This file is intended as a cleaner runner base, not as a claim that every mode
is equally mature. In particular:
- benchmark1d_solver: numerical CI benchmark
- dispersion_expected: analytical expected curve exporter
- topology3d_exploratory: ansatz-based exploratory diagnostic, not solved 3D evolution
"""

__version__ = "1.1.0"

import argparse
import csv
import hashlib
import json
import math
import pathlib
from typing import Dict, Any, List

import numpy as np

try:
    from firedrake import (
        UnitIntervalMesh,
        FunctionSpace, Function, TestFunction,
        dx, grad, inner, assemble,
        File, Constant,
        NonlinearVariationalProblem, NonlinearVariationalSolver,
        norm,
    )
    FIREDRAKE_AVAILABLE = True
except Exception:
    FIREDRAKE_AVAILABLE = False
    print("[WARN] Firedrake not available — falling back to numpy/demo branches where applicable.")


SFT_DEFAULTS = {
    "alpha_V": 1.0,
    "lambda4": 0.1,
    "c": 1.0,
    "CFL": 0.25,
    "S0": 1.2,
    "v_sol": 0.5,
    "xi": 0.5,
    "ALPHA_REF": 1.0 / 137.036,
    "LAMBDA_C": 1.0,
    "amp_e": 1.0,
    "r_core_e": 0.5,
    "amp_g": 0.2,
    "sigma_g": 1.0,
    "thr_e_frac": 0.30,
    "thr_g_frac": 0.30,
}

MODE_ALIASES = {
    "benchmark1d": "benchmark1d_solver",
    "dispersion": "dispersion_expected",
    "topology3d": "topology3d_exploratory",
}


def sanitize(obj):
    if isinstance(obj, dict):
        return {k: sanitize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize(v) for v in obj]
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: pathlib.Path, data: Dict[str, Any]) -> None:
    path.write_text(json.dumps(sanitize(data), indent=2, ensure_ascii=False), encoding="utf-8")


def write_manifest(files: List[pathlib.Path], manifest_path: pathlib.Path) -> None:
    """Writes a non-self-referential manifest."""
    lines = []
    for f in files:
        if f.exists():
            lines.append(f"{sha256_file(f)}  {f.name}")
    manifest_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def build_decision_rule(mode: str, args, p: Dict[str, Any]) -> Dict[str, Any]:
    if mode == "benchmark1d_solver":
        return {
            "gate_id": "SFT-BENCH1D-CI-v1",
            "status": "CI",
            "mode": mode,
            "equation": "d2S_dt2 = c^2 laplacian(S) - (alpha_V*S + lambda4*S^3)",
            "scheme": "centered-second-order acceleration residual; implicit nonlinear solve in Firedrake branch; explicit leapfrog-like update in numpy branch",
            "thresholds": {
                "L2_error_soliton_max": 1e-3,
                "relative_energy_drift_max": 1e-4,
            },
            "domain": {"L": args.L, "nx": args.nx, "T": args.T},
            "parameters": {
                "alpha_V": p["alpha_V"], "lambda4": p["lambda4"], "c": p["c"],
                "CFL": p["CFL"], "S0": p["S0"], "v_sol": p["v_sol"]
            },
            "non_claim": "This benchmark validates the numerical pipeline against a controlled traveling-profile check; it is not by itself a physical validation of the full theory."
        }
    if mode == "dispersion_expected":
        return {
            "gate_id": "SFT-DISPERSION-EXPECTED-v1",
            "status": "CI",
            "mode": mode,
            "equation": "omega = c*k*sqrt(1 + xi*(a*k)^2)",
            "thresholds": {"interpretation": "expected-curve export only"},
            "domain": {"L": args.L, "nx": args.nx},
            "parameters": {"xi": p["xi"], "c": p["c"]},
            "non_claim": "This mode exports an expected analytical curve; it does not infer dispersion from a solved field evolution."
        }
    if mode == "topology3d_exploratory":
        return {
            "gate_id": "SFT-TOPOLOGY3D-EXPLORATORY-v1",
            "status": "exploratory",
            "mode": mode,
            "equation": "3D ansatz fields S_e + S_g with geometric/topological diagnostic integrals",
            "thresholds": {
                "thr_e_frac": p["thr_e_frac"],
                "thr_g_frac": p["thr_g_frac"],
                "alpha_rel_err_pass_if_under": 0.50
            },
            "domain": {"L": args.L, "nx": args.nx},
            "parameters": {
                "alpha_V": p["alpha_V"], "lambda4": p["lambda4"],
                "amp_e": p["amp_e"], "r_core_e": p["r_core_e"],
                "amp_g": p["amp_g"], "sigma_g": p["sigma_g"],
                "LAMBDA_C": p["LAMBDA_C"], "ALPHA_REF": p["ALPHA_REF"]
            },
            "non_claim": "This mode evaluates diagnostic integrals on prescribed ansatz fields. It is not a solved 3D field evolution and should be cited as exploratory only."
        }
    raise ValueError(f"Unknown mode for decision rule: {mode}")


def write_decision_rule(out_dir: pathlib.Path, mode: str, args, p: Dict[str, Any]):
    dr = build_decision_rule(mode, args, p)
    dr_path = out_dir / "DECISION_RULE.json"
    write_json(dr_path, dr)
    return dr, dr_path, sha256_file(dr_path)


def build_weak_form(S, S_old, S_old2, v, dt, p):
    c2 = Constant(p["c"] ** 2)
    alpha_V = Constant(p["alpha_V"])
    lam4 = Constant(p["lambda4"])
    dt2 = Constant(dt ** 2)

    accel = (S - 2 * S_old + S_old2) / dt2
    dV_dS = alpha_V * S + lam4 * S**3

    F = (
        inner(accel, v) * dx
        + c2 * inner(grad(S), grad(v)) * dx
        + inner(dV_dS, v) * dx
    )
    return F


def soliton_profile_1d(x_coords, t, p, x0=0.0):
    S0 = p["S0"]
    v = p["v_sol"]
    c = p["c"]
    aV = p["alpha_V"]
    gamma2 = 1.0 / (1.0 - (v / c) ** 2)
    w = 1.0 / math.sqrt(aV * gamma2)
    xi_vals = (x_coords - x0 - v * t) / w
    return S0 / np.cosh(xi_vals)


def compute_energy_numpy(S_arr, S_prev_arr, dx_val, dt_val, p):
    c = p["c"]
    aV = p["alpha_V"]
    lam4 = p["lambda4"]
    dS_dt = (S_arr - S_prev_arr) / dt_val
    grad_S = np.gradient(S_arr, dx_val)
    T = 0.5 * np.sum(dS_dt**2) * dx_val
    Kx = 0.5 * c**2 * np.sum(grad_S**2) * dx_val
    V = np.sum(0.5 * aV * S_arr**2 + 0.25 * lam4 * S_arr**4) * dx_val
    return T + Kx + V


def write_common_report(path: pathlib.Path, mode: str, verdict: str, status: str,
                        decision_rule_sha256: str, dr: Dict[str, Any],
                        payload: Dict[str, Any]) -> None:
    report = {
        "schema_version": "1.0.0",
        "runner": "sft_firedrake_solver_improved",
        "version": __version__,
        "mode": mode,
        "status": status,
        "gate_id": dr["gate_id"],
        "decision_rule_ref": "DECISION_RULE.json",
        "decision_rule_sha256": decision_rule_sha256,
        "verdict": verdict,
    }
    report.update(payload)
    write_json(path, report)


def run_benchmark1d_numpy(args, p, out_dir, dr, dr_sha):
    nx = args.nx
    T = args.T
    L = args.L
    dx_ = 2 * L / nx
    dt_ = p["CFL"] * dx_ / (p["c"] * math.sqrt(1))
    nt = int(T / dt_) + 1
    x = np.linspace(-L, L, nx, endpoint=False)

    S_cur = soliton_profile_1d(x, 0.0, p)
    S_prev = soliton_profile_1d(x, -dt_, p)

    csv_path = out_dir / "sft_scan.csv"
    rows = []
    E0 = compute_energy_numpy(S_cur, S_prev, dx_, dt_, p)

    for step in range(nt):
        t = step * dt_
        dV = p["alpha_V"] * S_cur + p["lambda4"] * S_cur**3
        lap_S = (np.roll(S_cur, -1) - 2 * S_cur + np.roll(S_cur, 1)) / dx_**2
        S_next = 2 * S_cur - S_prev + dt_**2 * (p["c"]**2 * lap_S - dV)

        E = compute_energy_numpy(S_next, S_cur, dx_, dt_, p)
        dE_rel = abs(E - E0) / (abs(E0) + 1e-30)
        S_exact = soliton_profile_1d(x, t, p)
        l2_err = np.sqrt(np.mean((S_next - S_exact) ** 2))

        if step % max(1, nt // 50) == 0:
            rows.append({
                "step": step, "t": round(t, 6),
                "energy": E, "dE_rel": dE_rel,
                "l2_err_soliton": l2_err,
            })

        S_prev, S_cur = S_cur, S_next

    final_l2 = rows[-1]["l2_err_soliton"]
    final_dE = rows[-1]["dE_rel"]
    passed_l2 = final_l2 < dr["thresholds"]["L2_error_soliton_max"]
    passed_E = final_dE < dr["thresholds"]["relative_energy_drift_max"]
    verdict = "pass" if (passed_l2 and passed_E) else "fail"

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["step", "t", "energy", "dE_rel", "l2_err_soliton"])
        w.writeheader()
        w.writerows(rows)

    report_path = out_dir / "SFT_FIELD_REPORT.json"
    write_common_report(
        report_path, "benchmark1d_solver", verdict, "CI", dr_sha, dr,
        {
            "benchmarks": {
                "L2_error_soliton": final_l2,
                "L2_threshold": dr["thresholds"]["L2_error_soliton_max"],
                "L2_passed": passed_l2,
                "dE_rel_final": final_dE,
                "dE_threshold": dr["thresholds"]["relative_energy_drift_max"],
                "dE_passed": passed_E,
            },
            "provenance": {
                "backend": "numpy",
                "nx": nx, "T": T, "L": L, "dt": dt_, "nt": nt,
                **{k: v for k, v in p.items()}
            }
        }
    )

    manifest_path = out_dir / "MANIFEST_SHA256.txt"
    write_manifest([out_dir / "DECISION_RULE.json", csv_path, report_path], manifest_path)
    return report_path, manifest_path


def run_benchmark1d_firedrake(args, p, out_dir, dr, dr_sha):
    nx = args.nx
    T = args.T
    L = args.L

    mesh = UnitIntervalMesh(nx)
    mesh.coordinates.dat.data[:] = mesh.coordinates.dat.data[:] * 2 * L - L

    V = FunctionSpace(mesh, "CG", 1)
    v = TestFunction(V)
    S = Function(V, name="S")
    S_old = Function(V, name="S_old")
    S_old2 = Function(V, name="S_old2")

    x_coords = mesh.coordinates.dat.data_ro.copy()
    dx_mesh = 2 * L / nx
    dt_val = p["CFL"] * dx_mesh / (p["c"] * math.sqrt(1))

    S_old2.dat.data[:] = soliton_profile_1d(x_coords, -dt_val, p)
    S_old.dat.data[:] = soliton_profile_1d(x_coords, 0.0, p)
    S.assign(S_old)

    F = build_weak_form(S, S_old, S_old2, v, dt_val, p)
    problem = NonlinearVariationalProblem(F, S)
    solver = NonlinearVariationalSolver(
        problem,
        solver_parameters={"snes_type": "newtonls", "ksp_type": "preonly", "pc_type": "lu"}
    )

    vtk_file = File(str(out_dir / "sft_field.pvd"))
    vtk_file.write(S, time=0.0)

    nt = int(T / dt_val) + 1
    E0 = None
    rows = []

    for step in range(1, nt + 1):
        t = step * dt_val
        solver.solve()

        dS_dt = (S - S_old) / Constant(dt_val)
        E_expr = (
            0.5 * inner(dS_dt, dS_dt)
            + 0.5 * p["c"]**2 * inner(grad(S), grad(S))
            + 0.5 * p["alpha_V"] * S * S
            + 0.25 * p["lambda4"] * S**4
        )
        E = assemble(E_expr * dx)
        if E0 is None:
            E0 = E
        dE_rel = abs(E - E0) / (abs(E0) + 1e-30)

        S_exact_vals = soliton_profile_1d(x_coords, t, p)
        S_exact_fn = Function(V)
        S_exact_fn.dat.data[:] = S_exact_vals
        l2_err = norm(S - S_exact_fn)

        if step % max(1, nt // 50) == 0:
            rows.append({
                "step": step, "t": round(t, 6),
                "energy": float(E), "dE_rel": float(dE_rel),
                "l2_err_soliton": float(l2_err),
            })
            vtk_file.write(S, time=t)

        S_old2.assign(S_old)
        S_old.assign(S)

    final_l2 = rows[-1]["l2_err_soliton"]
    final_dE = rows[-1]["dE_rel"]
    passed_l2 = final_l2 < dr["thresholds"]["L2_error_soliton_max"]
    passed_E = final_dE < dr["thresholds"]["relative_energy_drift_max"]
    verdict = "pass" if (passed_l2 and passed_E) else "fail"

    csv_path = out_dir / "sft_scan.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["step", "t", "energy", "dE_rel", "l2_err_soliton"])
        w.writeheader()
        w.writerows(rows)

    report_path = out_dir / "SFT_FIELD_REPORT.json"
    write_common_report(
        report_path, "benchmark1d_solver", verdict, "CI", dr_sha, dr,
        {
            "benchmarks": {
                "L2_error_soliton": final_l2,
                "L2_threshold": dr["thresholds"]["L2_error_soliton_max"],
                "L2_passed": passed_l2,
                "dE_rel_final": final_dE,
                "dE_threshold": dr["thresholds"]["relative_energy_drift_max"],
                "dE_passed": passed_E,
            },
            "provenance": {
                "backend": "firedrake",
                "nx": nx, "T": T, "L": L, "dt": dt_val, "nt": nt,
                **{k: v for k, v in p.items()}
            }
        }
    )

    manifest_path = out_dir / "MANIFEST_SHA256.txt"
    write_manifest([out_dir / "DECISION_RULE.json", csv_path, report_path], manifest_path)
    return report_path, manifest_path


def run_dispersion_expected(args, p, out_dir, dr, dr_sha):
    nx = args.nx
    L = args.L
    a = 2 * L / nx
    xi = p["xi"]
    c = p["c"]

    k_vals = np.linspace(0.01 / a, 3.0 / a, 300)
    ak = a * k_vals
    omega = c * k_vals * np.sqrt(1.0 + xi * ak**2)
    ratio = omega / (c * k_vals)
    approx = 1.0 + 0.5 * xi * ak**2

    csv_path = out_dir / "sft_dispersion.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ak", "omega_ck_ratio", "small_ak_approx"])
        for row in zip(ak.tolist(), ratio.tolist(), approx.tolist()):
            w.writerow(row)

    report_path = out_dir / "SFT_DISPERSION_REPORT.json"
    write_common_report(
        report_path, "dispersion_expected", "pass", "CI", dr_sha, dr,
        {
            "dispersion": {
                "xi": xi, "c": c, "a": a,
                "expected_slope_ck_ratio": xi / 2,
                "description": "Expected analytical curve only; not inferred from solved field evolution.",
            },
            "provenance": {"nx": nx, "L": L, **{k: v for k, v in p.items()}}
        }
    )

    manifest_path = out_dir / "MANIFEST_SHA256.txt"
    write_manifest([out_dir / "DECISION_RULE.json", csv_path, report_path], manifest_path)
    return report_path, manifest_path


def _electron_soliton_3d(X, Y, Z, p):
    amp = p["amp_e"]
    r_core = p["r_core_e"]
    lc = p["LAMBDA_C"]
    eps = 0.3

    R = np.sqrt(X**2 + Y**2 + Z**2)
    R_safe = np.maximum(R, 1e-12)
    Theta = np.arccos(np.where(R > 0.0, Z / R_safe, 0.0))
    Y10 = np.sqrt(3.0 / (4.0 * np.pi)) * np.cos(Theta)

    f_core = amp / r_core
    f_tail = amp * np.exp(-R_safe / lc) / R_safe
    f_r = np.where(R <= r_core, f_core, f_tail)
    return f_r * (1.0 + eps * Y10)


def _photon_wavepacket_3d(X, Y, Z, p):
    amp = p["amp_g"]
    sigma = p["sigma_g"]
    lc = p["LAMBDA_C"]
    k0 = 2.0 * np.pi / lc
    R2 = X**2 + Y**2 + Z**2
    envelope = amp * np.exp(-R2 / (2.0 * sigma**2))
    return envelope * np.cos(k0 * X)


def _topological_integrals_3d(S_e, S_g, dx):
    dVol = dx**3
    I1 = float(np.sum(S_e * S_g)) * dVol
    dEx, dEy, dEz = np.gradient(S_e, dx, dx, dx, edge_order=2)
    grad_e_sq = dEx**2 + dEy**2 + dEz**2
    I2 = float(np.sum(grad_e_sq * S_g**2)) * dVol
    I3 = float(np.sum(S_e**2 * S_g**2)) * dVol
    dGx, dGy, dGz = np.gradient(S_g, dx, dx, dx, edge_order=2)
    cx = dEy * dGz - dEz * dGy
    cy = dEz * dGx - dEx * dGz
    cz = dEx * dGy - dEy * dGx
    Gam = float(np.sum(np.sqrt(cx**2 + cy**2 + cz**2))) * dVol
    return I1, I2, I3, Gam


def _alpha_candidates(I1, I2, I3, Gam, V_e, V_c):
    def safe(num, den):
        return (num / den) if (den != 0 and not math.isnan(den)) else 0.0
    return {
        "I1_over_Ve": safe(I1, V_e),
        "I3_over_Ve": safe(I3, V_e),
        "Vcoup_over_Ve": safe(V_c, V_e),
        "Gamma_over_4pi": Gam / (4.0 * math.pi),
        "I2_over_I1Ve": safe(I2, I1 * V_e),
        "I1_sq_over_I3Ve": safe(I1**2, I3 * V_e),
        "sqrt_I3_over_Ve": math.sqrt(abs(safe(I3, V_e))),
    }


def _run_single_topology(N, L, p):
    dx = 2.0 * L / N
    x = np.linspace(-L, L, N, endpoint=False)
    X, Y, Z = np.meshgrid(x, x, x, indexing="ij")

    S_e = _electron_soliton_3d(X, Y, Z, p)
    S_g = _photon_wavepacket_3d(X, Y, Z, p)

    thr_e = p["thr_e_frac"] * np.abs(S_e).max()
    thr_g = p["thr_g_frac"] * np.abs(S_g).max()
    mask_e = np.abs(S_e) > thr_e
    mask_g = np.abs(S_g) > thr_g
    mask_c = mask_e & mask_g

    V_e = float(np.sum(mask_e)) * dx**3
    V_g = float(np.sum(mask_g)) * dx**3
    V_c = float(np.sum(mask_c)) * dx**3
    frac_c = float(np.mean(mask_c))

    I1, I2, I3, Gam = _topological_integrals_3d(S_e, S_g, dx)
    cands = _alpha_candidates(I1, I2, I3, Gam, V_e, V_c)

    alpha_ref = p["ALPHA_REF"]
    errs = {k: abs(v - alpha_ref) / alpha_ref for k, v in cands.items() if v != 0}
    best_k = min(errs, key=errs.get) if errs else "none"
    best_val = cands.get(best_k, 0.0)
    best_err = errs.get(best_k, float("inf"))

    return {
        "integrals": {"I1": I1, "I2": I2, "I3": I3, "Gamma": Gam},
        "regions": {
            "V_e": V_e, "V_g": V_g, "V_coup": V_c,
            "frac_coup": frac_c, "thr_e": float(thr_e), "thr_g": float(thr_g)
        },
        "candidates": cands,
        "best": {"key": best_k, "value": best_val, "alpha_rel_err": best_err},
    }


def run_topology3d_exploratory(args, p, out_dir, dr, dr_sha):
    N = args.nx
    L = args.L
    alpha_ref = p["ALPHA_REF"]

    if not args.sweep:
        res = _run_single_topology(N, L, p)
        best = res["best"]
        verdict = "pass" if best["alpha_rel_err"] < dr["thresholds"]["alpha_rel_err_pass_if_under"] else "exploratory"

        report_path = out_dir / "SFT_TOPOLOGY_REPORT.json"
        write_common_report(
            report_path, "topology3d_exploratory", verdict, "exploratory", dr_sha, dr,
            {
                "alpha_ref": alpha_ref,
                **res,
                "provenance": {
                    "N": N, "L": L,
                    "alpha_V": p["alpha_V"], "lambda4": p["lambda4"],
                    "amp_e": p["amp_e"], "r_core_e": p["r_core_e"],
                    "amp_g": p["amp_g"], "sigma_g": p["sigma_g"],
                    "LAMBDA_C": p["LAMBDA_C"],
                },
            }
        )
        manifest_path = out_dir / "MANIFEST_SHA256.txt"
        write_manifest([out_dir / "DECISION_RULE.json", report_path], manifest_path)
        return report_path, manifest_path

    av_vals = np.linspace(args.alpha_V_min, args.alpha_V_max, args.alpha_V_steps)
    l4_vals = np.linspace(args.lambda4_min, args.lambda4_max, args.lambda4_steps)
    rows = []
    best_global = {"alpha_rel_err": float("inf")}

    for av in av_vals:
        for l4 in l4_vals:
            p_run = {**p, "alpha_V": float(av), "lambda4": float(l4)}
            res = _run_single_topology(N, L, p_run)
            b = res["best"]
            row = {
                "alpha_V": round(float(av), 6),
                "lambda4": round(float(l4), 6),
                "I1": res["integrals"]["I1"],
                "I2": res["integrals"]["I2"],
                "I3": res["integrals"]["I3"],
                "Gamma": res["integrals"]["Gamma"],
                "V_e": res["regions"]["V_e"],
                "V_coup": res["regions"]["V_coup"],
                "frac_coup": res["regions"]["frac_coup"],
                "best_candidate": b["key"],
                "best_value": b["value"],
                "alpha_rel_err": b["alpha_rel_err"],
            }
            rows.append(row)
            if b["alpha_rel_err"] < best_global["alpha_rel_err"]:
                best_global = row

    csv_path = out_dir / "sft_topology_scan.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    verdict = "pass" if best_global["alpha_rel_err"] < dr["thresholds"]["alpha_rel_err_pass_if_under"] else "exploratory"
    report_path = out_dir / "SFT_TOPOLOGY_REPORT.json"
    write_common_report(
        report_path, "topology3d_exploratory", verdict, "exploratory", dr_sha, dr,
        {
            "alpha_ref": alpha_ref,
            "best_global": best_global,
            "sweep": {
                "alpha_V_range": [float(av_vals[0]), float(av_vals[-1]), int(len(av_vals))],
                "lambda4_range": [float(l4_vals[0]), float(l4_vals[-1]), int(len(l4_vals))],
                "n_runs": len(rows),
                "csv": str(csv_path.resolve()),
            },
            "provenance": {
                "N": N, "L": L,
                "amp_e": p["amp_e"], "r_core_e": p["r_core_e"],
                "amp_g": p["amp_g"], "sigma_g": p["sigma_g"],
                "LAMBDA_C": p["LAMBDA_C"],
            },
        }
    )

    manifest_path = out_dir / "MANIFEST_SHA256.txt"
    write_manifest([out_dir / "DECISION_RULE.json", csv_path, report_path], manifest_path)
    return report_path, manifest_path


def parse_args():
    ap = argparse.ArgumentParser(
        description="Improved SFT Firedrake runner",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--mode", choices=[
        "benchmark1d_solver", "dispersion_expected", "topology3d_exploratory",
        "benchmark1d", "dispersion", "topology3d"
    ], default="benchmark1d_solver")
    ap.add_argument("--nx", type=int, default=64)
    ap.add_argument("--T", type=float, default=5.0)
    ap.add_argument("--L", type=float, default=8.0)
    ap.add_argument("--out_dir", type=str, default="sft_outputs")

    ap.add_argument("--alpha_V", type=float, default=SFT_DEFAULTS["alpha_V"])
    ap.add_argument("--lambda4", type=float, default=SFT_DEFAULTS["lambda4"])
    ap.add_argument("--xi", type=float, default=SFT_DEFAULTS["xi"])
    ap.add_argument("--S0", type=float, default=SFT_DEFAULTS["S0"])
    ap.add_argument("--v_sol", type=float, default=SFT_DEFAULTS["v_sol"])

    ap.add_argument("--amp_e", type=float, default=SFT_DEFAULTS["amp_e"])
    ap.add_argument("--r_core_e", type=float, default=SFT_DEFAULTS["r_core_e"])
    ap.add_argument("--amp_g", type=float, default=SFT_DEFAULTS["amp_g"])
    ap.add_argument("--sigma_g", type=float, default=SFT_DEFAULTS["sigma_g"])
    ap.add_argument("--thr_e_frac", type=float, default=SFT_DEFAULTS["thr_e_frac"])
    ap.add_argument("--thr_g_frac", type=float, default=SFT_DEFAULTS["thr_g_frac"])

    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--alpha_V_min", type=float, default=0.05)
    ap.add_argument("--alpha_V_max", type=float, default=0.25)
    ap.add_argument("--alpha_V_steps", type=int, default=6)
    ap.add_argument("--lambda4_min", type=float, default=0.04)
    ap.add_argument("--lambda4_max", type=float, default=0.15)
    ap.add_argument("--lambda4_steps", type=int, default=6)
    return ap.parse_args()


def main():
    args = parse_args()
    mode = MODE_ALIASES.get(args.mode, args.mode)

    out_dir = pathlib.Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    p = {
        **SFT_DEFAULTS,
        "alpha_V": args.alpha_V,
        "lambda4": args.lambda4,
        "xi": args.xi,
        "S0": args.S0,
        "v_sol": args.v_sol,
        "amp_e": args.amp_e,
        "r_core_e": args.r_core_e,
        "amp_g": args.amp_g,
        "sigma_g": args.sigma_g,
        "thr_e_frac": args.thr_e_frac,
        "thr_g_frac": args.thr_g_frac,
    }

    dr, dr_path, dr_sha = write_decision_rule(out_dir, mode, args, p)

    if mode == "benchmark1d_solver":
        if FIREDRAKE_AVAILABLE:
            report_path, manifest_path = run_benchmark1d_firedrake(args, p, out_dir, dr, dr_sha)
        else:
            report_path, manifest_path = run_benchmark1d_numpy(args, p, out_dir, dr, dr_sha)
    elif mode == "dispersion_expected":
        report_path, manifest_path = run_dispersion_expected(args, p, out_dir, dr, dr_sha)
    elif mode == "topology3d_exploratory":
        report_path, manifest_path = run_topology3d_exploratory(args, p, out_dir, dr, dr_sha)
    else:
        raise ValueError(f"Unhandled mode: {mode}")

    print(f"[OK] mode={mode}")
    print(f"[OK] decision rule: {dr_path.name}")
    print(f"[OK] report:        {report_path.name}")
    print(f"[OK] manifest:      {manifest_path.name}")


if __name__ == "__main__":
    main()
