#!/usr/bin/env python3
import argparse, hashlib, json, pathlib, sys

try:
    import jsonschema
except Exception:
    jsonschema = None

REPORT_BY_MODE = {
    "benchmark1d_solver": "SFT_FIELD_REPORT.json",
    "dispersion_expected": "SFT_DISPERSION_REPORT.json",
    "topology3d_exploratory": "SFT_TOPOLOGY_REPORT.json",
    "benchmark1d": "SFT_FIELD_REPORT.json",
    "dispersion": "SFT_DISPERSION_REPORT.json",
    "topology3d": "SFT_TOPOLOGY_REPORT.json",
}

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--schema", default=str(pathlib.Path(__file__).resolve().parent / "schemas" / "SFT_REPORT.schema.json"))
    args = ap.parse_args()

    out_dir = pathlib.Path(args.out_dir)
    if not out_dir.exists():
        raise SystemExit(f"FAIL: output directory not found: {out_dir}")

    report_name = REPORT_BY_MODE.get(args.mode, REPORT_BY_MODE.get(args.mode.split()[0], None))
    if report_name is None:
        raise SystemExit(f"FAIL: unknown mode: {args.mode}")

    report_path = out_dir / report_name
    dr_path = out_dir / "DECISION_RULE.json"
    manifest_path = out_dir / "MANIFEST_SHA256.txt"

    for p in [report_path, dr_path, manifest_path]:
        if not p.exists():
            raise SystemExit(f"FAIL: missing required file: {p.name}")

    report = json.loads(report_path.read_text(encoding="utf-8"))
    dr = json.loads(dr_path.read_text(encoding="utf-8"))

    # decision rule hash consistency
    real_dr_sha = sha256_file(dr_path)
    if report.get("decision_rule_sha256") != real_dr_sha:
        raise SystemExit("FAIL: decision_rule_sha256 mismatch")

    # gate id consistency
    if report.get("gate_id") != dr.get("gate_id"):
        raise SystemExit("FAIL: gate_id mismatch between report and decision rule")

    # optional schema validation
    schema_path = pathlib.Path(args.schema)
    if jsonschema is not None and schema_path.exists():
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        jsonschema.validate(report, schema)

    # manifest validation
    lines = [ln.strip() for ln in manifest_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    for ln in lines:
        parts = ln.split()
        if len(parts) < 2:
            raise SystemExit(f"FAIL: malformed manifest line: {ln}")
        expected = parts[0]
        fname = parts[-1]
        fpath = out_dir / fname
        if not fpath.exists():
            raise SystemExit(f"FAIL: manifest entry missing file: {fname}")
        got = sha256_file(fpath)
        if got != expected:
            raise SystemExit(f"FAIL: manifest hash mismatch for {fname}")

    print("GLOBAL_PASS = true")
    print(f"Verified: {report_name}")
    print(f"Status: {report.get('status')}")
    print(f"Gate: {report.get('gate_id')}")

if __name__ == "__main__":
    main()
