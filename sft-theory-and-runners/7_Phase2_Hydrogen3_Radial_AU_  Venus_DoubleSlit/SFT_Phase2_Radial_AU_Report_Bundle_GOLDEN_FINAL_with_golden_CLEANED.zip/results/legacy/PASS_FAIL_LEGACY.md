# PASS/FAIL — Mini checks

| Check | Value | Note | Status |
|---|---|---|---|
| Energy 1s | -13.563452 eV (ref -13.603218) | rel=2.92e-03 | FAIL |
| Degeneracy 2s–2p | |Δ|=4.076000e-03 eV | threshold 1e-5 eV | FAIL |
| Dispersion (phase error ≤1%) | N/A | needs wave test dataset | N/A |
