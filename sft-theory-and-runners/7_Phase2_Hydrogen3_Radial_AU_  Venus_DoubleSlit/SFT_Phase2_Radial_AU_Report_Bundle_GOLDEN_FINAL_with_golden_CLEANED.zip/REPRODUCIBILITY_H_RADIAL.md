
# Reproducibility — Hydrogen (Radial, a.u.) — CPU‑only

This package validates the **Coulomb degeneracy** (2s–2p ≈ 0) and basic residuals (normalization, virial) for H and T using the **golden‑path** outputs in `results/golden/`. No GPU is required.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python verify_h3_radial.py
```

## What the verifier checks
- **Degeneracy**: `|E(2s)−E(2p)| ≤ 0.1 meV` for H and for T.
- **Normalization residual** per state `≤ 1e-3` (ideal ≤ 1e-6).
- **Virial residual (relative)** per state `≤ 1e-3`.
- Grid/BC flags are as documented: `Rmax≈110 a0`, `dr≈0.0035 a0`, BC=`asymptotic_log_derivative`.

It reads `results/golden/golden_output.json` and `results/golden/golden_path_results_2s_2p_Rmax110_dr0.0035.csv`.

## Notes
- Legacy runs under `results/legacy/` are kept for traceability and are expected to **FAIL** the degeneracy gate (multi‑meV box artifact). They **do not** affect the PASS of the golden‑path.
