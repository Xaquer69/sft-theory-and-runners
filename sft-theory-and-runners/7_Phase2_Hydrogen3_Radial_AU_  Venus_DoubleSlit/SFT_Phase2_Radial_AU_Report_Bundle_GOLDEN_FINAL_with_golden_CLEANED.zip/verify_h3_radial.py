
import json, os, sys, math
import pandas as pd

GOLDEN_JSON = os.path.join("results","golden","golden_output.json")
GOLDEN_CSV  = os.path.join("results","golden","golden_path_results_2s_2p_Rmax110_dr0.0035.csv")

def main():
    ok = True
    msgs = []

    with open(GOLDEN_JSON, "r", encoding="utf-8") as f:
        G = json.load(f)

    # thresholds
    thr_deg = G["acceptance"]["degeneracy_threshold_meV"]
    thr_norm = G["acceptance"]["norm_residual_max"]
    thr_vir = G["acceptance"]["virial_rel_max"]

    # degeneracy from JSON
    for iso in ["H","T"]:
        dmev = G["isotopes"][iso]["degeneracy_abs_meV"]
        if dmev <= thr_deg:
            msgs.append(f"[PASS] {iso} degeneracy |2s-2p|={dmev:.3f} meV <= {thr_deg} meV")
        else:
            msgs.append(f"[FAIL] {iso} degeneracy |2s-2p|={dmev:.3f} meV > {thr_deg} meV")
            ok = False

    # residuals
    for iso in ["H","T"]:
        for st in ["2s","2p"]:
            S = G["isotopes"][iso]["states"][st]
            nr = abs(S.get("norm_residual", 0.0))
            vr = abs(S.get("virial_residual_rel", 0.0))
            if nr <= thr_norm:
                msgs.append(f"[PASS] {iso} {st} norm_residual={nr:.3e} <= {thr_norm}")
            else:
                msgs.append(f"[FAIL] {iso} {st} norm_residual={nr:.3e} > {thr_norm}"); ok=False
            if vr <= thr_vir:
                msgs.append(f"[PASS] {iso} {st} virial_residual_rel={vr:.3e} <= {thr_vir}")
            else:
                msgs.append(f"[FAIL] {iso} {st} virial_residual_rel={vr:.3e} > {thr_vir}"); ok=False

    # secondary cross-check using energies CSV
    df = pd.read_csv(GOLDEN_CSV)
    def split_mev(iso):
        e2s = float(df.query("Isotope == @iso and State == '2s'")["Energy (eV)"].iloc[0])
        e2p = float(df.query("Isotope == @iso and State == '2p'")["Energy (eV)"].iloc[0])
        return abs(e2s - e2p)*1000.0
    for iso in ["H","T"]:
        d = split_mev(iso)
        if d <= thr_deg+1e-6:
            msgs.append(f"[PASS] {iso} CSV check |2s-2p|={d:.3f} meV <= {thr_deg} meV")
        else:
            msgs.append(f"[FAIL] {iso} CSV check |2s-2p|={d:.3f} meV > {thr_deg} meV"); ok=False

    print("\n".join(msgs))
    print("\nGLOBAL_PASS =", ok)
    return 0 if ok else 2

if __name__ == "__main__":
    sys.exit(main())
