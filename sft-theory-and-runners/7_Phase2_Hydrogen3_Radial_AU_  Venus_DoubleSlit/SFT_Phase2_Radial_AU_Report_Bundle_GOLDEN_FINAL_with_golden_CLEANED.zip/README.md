# SFT Phase-2 — GOLDEN bundle

This bundle contains the corrected **golden-path** results for the hydrogenic radial solver in atomic units (a.u.), using **full Numerov** and **asymptotic log-derivative** boundary condition at Rmax (no Dirichlet).

## How to reproduce (short)
1. Use a uniform radial grid with **Rmax = 110.0 a0** and **Δr = 0.0035 a0** (points = 31430).
2. Potential **V(r) = −Z/r**, Z=1. No soft-core (r0=0).
3. Reduced mass: μr(H) = 0.999455383, μr(T) = 0.999818080.
4. Solve for n=2 with ℓ=0 (**2s**) and ℓ=1 (**2p**) by inward/outward Numerov and **log-derivative matching** near the classical turning point.
5. Impose BC at Rmax via **u'/u = −κ(E)** with κ = √(−2 μr E).

## Acceptance thresholds
- Coulomb degeneracy: **|E2s − E2p| ≤ 0.1 meV** (fine mesh).
- Normalization residual: **≤ 1e−3** (we report ≲ 1e−16 due to explicit normalization).
- Virial (Coulomb): **|2⟨T⟩ + ⟨V⟩|/|E| ≤ 1e−3**.

## Files
- `docs/SFT_Phase2_Radial_AU_Report_CORRECTED_v1.1_EN_GOLDEN_plus_err_conv.docx` — Main report (**v1.1 GOLDEN**).
- `results/golden/golden_output.json` — Traceable output with grid, flags, energies (H/T), degeneracy, residuals, and SHA-256 for wavefunction CSVs.
- `results/golden/wf_*.csv` — Normalized radial profiles `u(r)` for (H,T)×(2s,2p).
- `results/golden/golden_path_results_2s_2p_Rmax110_dr0.0035.csv` — Energies (H/T).
- `results/golden/golden_path_error_vs_analytical.csv` — Error vs analytical reference.
- `results/golden/convergence_2s_2p_vs_dr.csv`, `results/golden/convergence_2s2p_vs_dr.png` — Convergence figure/data.
- `results/legacy/…` — Original Dirichlet results preserved for traceability.
- `metadata/` — `RUN_CARD_GOLDEN.txt` and reference CSVs/templates.

## PASS/FAIL (summary)
- H: |Δ(2s−2p)| ≈ 0.0824 meV → **PASS**
- T: |Δ(2s−2p)| ≈ 0.0824 meV → **PASS**
- Residuals: normalization ≲1e−16, virial ≲2.4e−4 (PASS).

## Notes
- The reported virial residual uses ⟨V⟩ = ∫ |u|² V(r) dr and checks **⟨V⟩ ≈ 2E** for Coulomb; values ≪ 1e−3 are expected on the fine mesh.
- For ℓ>0 we do **not** apply the Langer correction here (flag: `Langer=false`); adding it changes 2p at the O(μeV) level on this mesh.