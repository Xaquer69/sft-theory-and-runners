# Reproducibility — Double‑Slit (CPU‑only)

Metrics:
1) Phase vs S0: R² ≥ 0.98
2) Visibility: strictly decreasing; last-step relative change ≤ 0.10

Quick start:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -U numpy pandas
python verify_double_slit.py
```
