# SFT publication cleanup audit report

Date: 2026-05-28

## Scope

This cleaned release separates two claims that should not be mixed in publication:

1. **Double-slit synthetic benchmark**: reproducible PASS for the preregistered phase/visibility gates.
2. **Optics-null QA protocol**: corrected publication gate that evaluates only designated physical null inputs, not generated artifacts or empty templates.

## Double-slit package status

Path: `DoubleSlit_PACKAGE_FIXED_AUDITED/`

### Verified result

`python verify_double_slit.py` returns:

- `phase_slope`: 0.2593984937478938
- `phase_r2`: 0.999812580721433
- `vis_monotonic`: true
- `vis_last_rel_change`: 0.05999999999999987
- `GLOBAL_PASS`: true

### Cleanup applied

- `exp_double_slit.json` now uses the same `rho_crit` grid as `output_double_slit/visibility.csv`:
  - 0.1, 0.2, 0.35, 0.5, 0.8, 1.2, 1.6, 2.0
- The package remains explicitly a **synthetic reference run**, not an experimental validation.
- New checksums were generated in `checksums_SHA256_AUDITED.txt`.

### Publication-safe wording

Use:

> The synthetic double-slit reference run passes the preregistered phase/visibility gates and validates the analysis/reproducibility pipeline.

Avoid:

> The double-slit experiment validates SFT physically.

## Optics-null package status

Path: `Optics_Null_RELEASE_AUDITED/`

### Original issue

The original aggregate null artifact reported `overall_pass: false` because the broad runner scanned files that are not physical null measurements, including artifacts, generated summaries, empty templates, and report tables. That output should not be used as a global null-gate certificate.

### Cleanup applied

Added a scoped publication gate:

- `config/null_manifest_publication.json`
- `scripts/null_tests_scoped.py`
- `scripts/aggregate_publication_gates.py`
- `scripts/run_publication_gates.sh`

The scoped runner evaluates only manifest-listed physical null channels. It excludes artifacts, outputs, reports, templates, and prior summaries.

Also patched:

- `HOW_TO_RUN.txt`: replaced missing `dispersion_analysis_patched.py` reference with `scripts/dispersion_analysis.py`.
- `scripts/dispersion_analysis.py`: now returns nonzero exit status when either `pass_null` or `pass_stability` is false, so CI cannot silently pass a failed dispersion gate.
- `scripts/run_publication_gates.sh`: sets `--max_dt_s 1.1` for the example dataset, matching the one-second alternating wavelength cadence.

### Verified publication gate

`./scripts/run_publication_gates.sh` returns:

- birefringence `pass_null`: true
- dispersion `pass_null`: true
- dispersion `pass_stability`: true under the `practical` profile
- scoped null aggregate `overall_pass`: true
- `GLOBAL_PUBLICATION_GATE_PASS`: true

Main artifact:

`Optics_Null_RELEASE_AUDITED/artifacts_publication/optics_publication_overall.json`

## Recommended manuscript claim

> The double-slit synthetic reference benchmark passes the preregistered phase and visibility gates. The optics-null QA package now includes a scoped publication gate that excludes non-physical generated artifacts from aggregate null testing and passes on the designated example inputs under the practical profile.

## Remaining limitation

This cleaned package is suitable for a reproducible benchmark/protocol release. It is still not a substitute for a real-solver or experimental validation run.
