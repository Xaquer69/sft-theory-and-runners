# Re-run audit report — SFT publication bundle

Date: 2026-05-28

## Scope

This re-audit checked the uploaded `SFT_PUBLICATION_CLEANED.zip` as an executable release package: archive integrity, checksum manifests, double-slit gates, optics-null publication gates, and failure behavior under deliberately stricter criteria.

## Results

### Top-level integrity

The top-level manifest passed before execution. After re-running scripts, output artifacts with timestamps were regenerated, as expected; for this re-audited package the checksum files have been regenerated to reflect the packaged state.

### Double-slit benchmark

Command tested:

```bash
cd DoubleSlit_PACKAGE_FIXED_AUDITED
./scripts/run_auto_fixed.sh --out audit_run_default
```

Result:

- exit code: 0
- `source_kind`: `synthetic`
- phase slope: `0.2593984937478938`
- phase R²: `0.999812580721433`
- visibility monotonic: `true`
- last relative visibility change: `0.05999999999999987`
- `GLOBAL_PASS`: `true`

Negative control:

```bash
./scripts/run_auto_fixed.sh --out audit_run_tight_fail --phase-r2-min 0.99999
```

Result: exit code 1 and `GLOBAL_PASS: false`, as expected.

Strict solver-failure behavior was also checked with an intentionally failing solver command; `--strict` aborted with nonzero exit code, as expected.

### Optics-null publication gate

Command tested:

```bash
cd Optics_Null_RELEASE_AUDITED
./scripts/run_publication_gates.sh
```

Result:

- exit code: 0
- birefringence `pass_null`: `true`
- dispersion `pass_null`: `true`
- dispersion `pass_stability`: `true`
- scoped null `overall_pass`: `true`
- `GLOBAL_PUBLICATION_GATE_PASS`: `true`

The scoped null gate evaluated only manifest-listed physical null channels and did not recursively scan generated artifacts, reports, templates, or prior summaries.

Negative control:

```bash
python scripts/dispersion_analysis.py \
  --csv examples/dispersion_example_data.csv \
  --max_dt_s 1.1 \
  --criteria_profile strict \
  --criteria_path config/criteria.json \
  --out /tmp/disp_strict_audit
```

Result: exit code 1 because `pass_stability: false` under the strict profile, as expected.

## Residual limitation

This release is suitable as a reproducibility / verification benchmark package. It remains a synthetic reference/pipeline validation and should not be described as standalone experimental validation of SFT.
