#!/usr/bin/env python3
import argparse, json
from pathlib import Path
from datetime import datetime, timezone


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--birefringence', required=True)
    ap.add_argument('--dispersion', required=True)
    ap.add_argument('--scoped-null', required=True)
    ap.add_argument('--out', default='artifacts_publication/optics_publication_overall.json')
    args = ap.parse_args()

    biref = load(args.birefringence)
    disp = load(args.dispersion)
    scoped = load(args.scoped_null)
    summary = {
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'scope_note': 'Publication gate uses designated physical examples only. It does not scan artifacts, reports, templates, or previously generated summaries as raw null data.',
        'birefringence_pass_null': bool(biref.get('pass_null')),
        'dispersion_pass_null': bool(disp.get('pass_null')),
        'dispersion_pass_stability': bool(disp.get('pass_stability')),
        'dispersion_criteria_profile': disp.get('criteria_profile'),
        'scoped_null_overall_pass': bool(scoped.get('overall_pass')),
        'GLOBAL_PUBLICATION_GATE_PASS': bool(biref.get('pass_null')) and bool(disp.get('pass_null')) and bool(disp.get('pass_stability')) and bool(scoped.get('overall_pass')),
        'inputs': {
            'birefringence_summary': args.birefringence,
            'dispersion_summary': args.dispersion,
            'scoped_null_overall': args.scoped_null
        }
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, indent=2))
    return 0 if summary['GLOBAL_PUBLICATION_GATE_PASS'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
