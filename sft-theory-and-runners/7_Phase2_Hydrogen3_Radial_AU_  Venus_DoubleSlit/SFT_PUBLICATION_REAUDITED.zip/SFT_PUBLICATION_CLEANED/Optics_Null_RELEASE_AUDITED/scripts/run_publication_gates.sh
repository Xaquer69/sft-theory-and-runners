#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="artifacts_publication"
rm -rf "$OUT"
mkdir -p "$OUT/birefringence" "$OUT/dispersion" "$OUT/null_tests"

python scripts/birefringence_analysis.py \
  --csv examples/birefringence_example_null.csv \
  --out "$OUT/birefringence"

python scripts/dispersion_analysis.py \
  --csv examples/dispersion_example_data.csv \
  --max_dt_s 1.1 \
  --criteria_profile practical \
  --criteria_path config/criteria.json \
  --out "$OUT/dispersion"

python scripts/null_tests_scoped.py \
  --manifest config/null_manifest_publication.json \
  --out "$OUT/null_tests"

python scripts/aggregate_publication_gates.py \
  --birefringence "$OUT/birefringence/birefringence_summary.json" \
  --dispersion "$OUT/dispersion/dispersion_summary.json" \
  --scoped-null "$OUT/null_tests/optics_null_overall.json" \
  --out "$OUT/optics_publication_overall.json"
