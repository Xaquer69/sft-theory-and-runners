#!/usr/bin/env python3
"""Scoped optics-null gate runner.

This script intentionally evaluates only the CSV files and columns listed in a
manifest. It does not scan artifacts/, outputs/, or template files, because
those are not physical null channels and can create misleading aggregate FAILs.
"""
import argparse, json, math, os
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd


def normal_cdf(z: float) -> float:
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def pval_mean_zero(mean: float, se: float) -> float:
    if not np.isfinite(se) or se == 0:
        return 1.0 if mean == 0 else 0.0
    return max(min(2.0 * (1.0 - normal_cdf(abs(mean / se))), 1.0), 0.0)


def slope_stats(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    X = np.vstack([x, np.ones_like(x)]).T
    slope, intercept = np.linalg.lstsq(X, y, rcond=None)[0]
    yhat = slope * x + intercept
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    df = max(len(x) - 2, 1)
    s2 = ss_res / df
    sxx = float(np.sum((x - np.mean(x)) ** 2))
    se_slope = math.sqrt(s2 / sxx) if sxx > 0 else float('inf')
    if not np.isfinite(se_slope) or se_slope == 0:
        p = 1.0 if slope == 0 else 0.0
    else:
        p = max(min(2.0 * (1.0 - normal_cdf(abs(slope / se_slope))), 1.0), 0.0)
    return float(slope), float(intercept), float(r2), float(se_slope), float(p)


def bh_rejections(pvals, q):
    pvals = np.asarray(pvals, dtype=float)
    finite = np.isfinite(pvals)
    finite_idx = np.where(finite)[0]
    if len(finite_idx) == 0:
        return set()
    p = pvals[finite_idx]
    order = np.argsort(p)
    kmax = 0
    m = len(p)
    for rank, local_idx in enumerate(order, start=1):
        if p[local_idx] <= (rank / m) * q:
            kmax = rank
    if kmax == 0:
        return set()
    return set(int(finite_idx[i]) for i in order[:kmax])


def relpath(path: Path, base: Path) -> str:
    try:
        return str(path.resolve().relative_to(base.resolve()))
    except Exception:
        return str(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', required=True, help='JSON manifest listing physical null channels')
    ap.add_argument('--out', default='artifacts_publication/null_tests', help='Output directory')
    args = ap.parse_args()

    manifest_path = Path(args.manifest)
    base = manifest_path.parent.parent if manifest_path.parent.name == 'config' else Path.cwd()
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)

    mean_p_min = float(manifest.get('mean_p_min', 0.05))
    slope_p_min = float(manifest.get('slope_p_min', 0.05))
    fdr_q = float(manifest.get('fdr_q', 0.05))
    rows = []
    inventory = []

    for item in manifest.get('files', []):
        csv_path = (base / item['path']).resolve()
        if not csv_path.exists():
            raise FileNotFoundError(f'Manifest input not found: {csv_path}')
        df = pd.read_csv(csv_path)
        predictor = item.get('predictor')
        channels = item.get('null_signals', [])
        if predictor and predictor not in df.columns:
            raise ValueError(f'Predictor {predictor!r} not found in {csv_path}')
        for ch in channels:
            col = ch['column'] if isinstance(ch, dict) else ch
            if col not in df.columns:
                raise ValueError(f'Null signal {col!r} not found in {csv_path}')
        inventory.append({
            'csv_path': relpath(csv_path, base),
            'n_rows': int(len(df)),
            'predictor': predictor or '',
            'null_signals': ';'.join([(c['column'] if isinstance(c, dict) else c) for c in channels])
        })
        for ch in channels:
            if isinstance(ch, str):
                col = ch
                bounds = None
                label = col
            else:
                col = ch['column']
                bounds = ch.get('bounds')
                label = ch.get('label', col)
            y = pd.to_numeric(df[col], errors='coerce')
            valid = y.notna()
            if predictor:
                x = pd.to_numeric(df[predictor], errors='coerce')
                valid = valid & x.notna()
                x = x[valid].to_numpy(dtype=float)
            else:
                x = None
            yv = y[valid].to_numpy(dtype=float)
            n = len(yv)
            if n < 3:
                raise ValueError(f'Need at least 3 numeric samples for {col} in {csv_path}; got {n}')
            mean = float(np.mean(yv))
            std = float(np.std(yv, ddof=1))
            se = float(std / math.sqrt(n))
            p_mean = pval_mean_zero(mean, se)
            ci_lo = mean - 1.96 * se
            ci_hi = mean + 1.96 * se
            slope = intercept = r2 = se_slope = p_slope = float('nan')
            if x is not None:
                slope, intercept, r2, se_slope, p_slope = slope_stats(x, yv)
            bounds_ok = True
            if bounds is not None:
                lo, hi = bounds
                bounds_ok = bool(np.all((yv >= lo) & (yv <= hi)))
            rows.append({
                'csv_path': relpath(csv_path, base),
                'label': label,
                'column': col,
                'n': n,
                'mean': mean,
                'std': std,
                'se': se,
                'mean_p': p_mean,
                'ci95_lo': ci_lo,
                'ci95_hi': ci_hi,
                'slope': slope,
                'slope_intercept': intercept,
                'slope_se': se_slope,
                'slope_p': p_slope,
                'r2': r2,
                'bounds_ok': bounds_ok,
                'pass_mean_pre_fdr': bool((ci_lo <= 0 <= ci_hi) or (p_mean > mean_p_min)),
                'pass_slope_pre_fdr': bool((not np.isfinite(p_slope)) or (p_slope > slope_p_min)),
            })

    df = pd.DataFrame(rows)
    mean_rej = bh_rejections(df['mean_p'].to_numpy(), fdr_q)
    slope_rej = bh_rejections(df['slope_p'].to_numpy(), fdr_q)
    df['fdr_mean_reject'] = [i in mean_rej for i in range(len(df))]
    df['fdr_slope_reject'] = [i in slope_rej for i in range(len(df))]
    df['PASS_column'] = df['pass_mean_pre_fdr'] & df['pass_slope_pre_fdr'] & df['bounds_ok'] & (~df['fdr_mean_reject']) & (~df['fdr_slope_reject'])

    file_df = df.groupby('csv_path').agg(
        n_columns_checked=('column', 'size'),
        n_pass=('PASS_column', 'sum'),
    ).reset_index()
    file_df['n_fail'] = file_df['n_columns_checked'] - file_df['n_pass']
    file_df['PASS_file'] = file_df['n_fail'] == 0
    overall_pass = bool(file_df['PASS_file'].all())

    pd.DataFrame(inventory).to_csv(outdir / 'optics_null_inventory.csv', index=False)
    df.to_csv(outdir / 'optics_null_summary_per_column.csv', index=False)
    file_df.to_csv(outdir / 'optics_null_summary_per_file.csv', index=False)
    overall = {
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'overall_pass': overall_pass,
        'files_checked': int(len(file_df)),
        'columns_checked': int(len(df)),
        'manifest_used': relpath(manifest_path.resolve(), base),
        'scope_note': 'Only manifest-listed physical null channels were evaluated; artifacts, outputs, reports, and templates were excluded.',
        'mean_p_min': mean_p_min,
        'slope_p_min': slope_p_min,
        'fdr_q': fdr_q,
    }
    (outdir / 'optics_null_overall.json').write_text(json.dumps(overall, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(overall, indent=2))
    return 0 if overall_pass else 1


if __name__ == '__main__':
    raise SystemExit(main())
