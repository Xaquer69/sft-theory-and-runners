# Cleaned SFT publication bundle

This bundle contains audited/cleaned versions of the double-slit benchmark package and optics-null QA package.

## Run checks

### Double-slit synthetic benchmark

```bash
cd DoubleSlit_PACKAGE_FIXED_AUDITED
python verify_double_slit.py
```

Expected: `GLOBAL_PASS: true`.

### Optics-null publication gate

```bash
cd Optics_Null_RELEASE_AUDITED
./scripts/run_publication_gates.sh
```

Expected: `GLOBAL_PUBLICATION_GATE_PASS: true`.

## Important caveat

The double-slit result is a synthetic reference/pipeline validation, not a physical validation of SFT. Use the wording in `AUDIT_REPORT.md` when preparing the manuscript.
