#!/usr/bin/env python3
import numpy as np, pandas as pd, argparse, json, math, sys, os

G = 6.67430e-11
M_sun = 1.98847e30
mu = G*M_sun
YEAR = 365.25*24*3600.0

def unwrap_phase(phi):
    return np.unwrap(phi)

def compute_varpi_from_state(t, x, y, vx, vy):
    # Planar 2D: eccentricity vector e = (v x h)/mu - r_hat
    r = np.stack([x, y], axis=1)
    v = np.stack([vx, vy], axis=1)
    rnorm = np.linalg.norm(r, axis=1)
    h_z = x*vy - y*vx  # z-component of angular momentum
    # v x h (for planar, v x h_z k = h_z * ( -v_y, v_x ))
    v_cross_h = np.stack([-vy*h_z, vx*h_z], axis=1)
    r_hat = r / rnorm[:,None]
    e_vec = v_cross_h/mu - r_hat
    # longitude of perihelion ~ angle of e_vec
    phi = np.arctan2(e_vec[:,1], e_vec[:,0])
    phi_u = unwrap_phase(phi)
    # Convert to arcsec
    varpi_arcsec = phi_u * (180/np.pi)*3600.0
    # Time to centuries (assuming t in seconds)
    centuries = (t - t[0]) / (100.0*YEAR)
    return centuries, varpi_arcsec

def fit_line(x, y):
    A = np.vstack([x, np.ones_like(x)]).T
    m, b = np.linalg.lstsq(A, y, rcond=None)[0]
    yhat = m*x + b
    ss_res = float(np.sum((y - yhat)**2))
    ss_tot = float(np.sum((y - y.mean())**2))
    R2 = 1 - ss_res/ss_tot
    return m, b, R2

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Orbit CSV with columns time(s),x,y,vx,vy OR with precomputed varpi series (centuries,varpi_arcsec)")
    ap.add_argument("--time", default="time", help="Column for time (seconds)")
    ap.add_argument("--x", default="x", help="Column for x (m)")
    ap.add_argument("--y", default="y", help="Column for y (m)")
    ap.add_argument("--vx", default="vx", help="Column for vx (m/s)")
    ap.add_argument("--vy", default="vy", help="Column for vy (m/s)")
    ap.add_argument("--out_series", default="varpi_series_venus_real.csv")
    ap.add_argument("--out_report", default="perihelion_venus_real_report.json")
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    # autodetect: if there is 'centuries' and 'varpi_arcsec' columns (or alternated format), use directly
    if 'centuries' in df.columns and 'varpi_arcsec' in df.columns:
        centuries = df['centuries'].values.astype(float)
        varpi = df['varpi_arcsec'].values.astype(float)
    elif list(df.columns) == ['centuries'] and len(df)>2 and not df['centuries'].iloc[1].replace('.','',1).isdigit():
        # alternating format like your bundle; fall back to manual parse
        lines = [l.strip() for l in open(args.csv, encoding='utf-8') if l.strip()!='']
        assert lines[0].startswith("centuries")
        assert lines[1].startswith("varpi_arcsec")
        vals = lines[2:]
        if len(vals)%2==1: vals = vals[:-1]
        centuries = np.array([float(vals[i]) for i in range(0, len(vals), 2)])
        varpi = np.array([float(vals[i]) for i in range(1, len(vals), 2)])
    else:
        # compute from state vectors
        try:
            t = df[args.time].values.astype(float)
            x = df[args.x].values.astype(float)
            y = df[args.y].values.astype(float)
            vx = df[args.vx].values.astype(float)
            vy = df[args.vy].values.astype(float)
        except KeyError as e:
            print("Missing column:", e, file=sys.stderr); sys.exit(2)
        centuries, varpi = compute_varpi_from_state(t, x, y, vx, vy)

    # Fit slope
    m, b, R2 = fit_line(centuries, varpi)

    # Write alternating series for pipeline compatibility
    with open(args.out_series, "w", encoding="utf-8") as f:
        f.write("centuries,\n")
        f.write("varpi_arcsec\n")
        for tt, vv in zip(centuries, varpi):
            f.write(f"{tt}\n{vv}\n")

    report = {
        "artifact": args.out_series,
        "fit": {"slope_arcsec_per_century": float(m), "intercept_arcsec": float(b), "R2": float(R2)},
        "input_csv": os.path.basename(args.csv)
    }
    json.dump(report, open(args.out_report,"w"), indent=2)
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
