#!/usr/bin/env python3
import json, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", default="perihelion_venus_real_report.json")
    ap.add_argument("--manifest", default="manifest_venus_real.json")
    ap.add_argument("--out", default="report_venus_real_verify.json")
    args = ap.parse_args()
    rep = json.load(open(args.report,"r"))
    man = json.load(open(args.manifest,"r"))
    slope = rep["fit"]["slope_arcsec_per_century"]
    R2 = rep["fit"]["R2"]
    expected = man["expected_GR_arcsec_per_century"]
    tol = man["pass_fail"]["slope_tolerance_arcsec_per_century"]
    R2_min = man["pass_fail"]["R2_min"]
    pass_slope = abs(slope - expected) <= tol
    pass_R2 = R2 >= R2_min
    overall = bool(pass_slope and pass_R2)
    out = {"slope":slope,"R2":R2,"expected":expected,"tol":tol,
           "pass_slope":pass_slope,"pass_R2":pass_R2,"PASS":overall}
    json.dump(out, open(args.out,"w"), indent=2)
    print("PASS" if overall else "FAIL", out)

if __name__ == "__main__":
    main()
