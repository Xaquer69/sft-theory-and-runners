# Overlay — Venus perihelion (real pipeline)

This overlay provides helper scripts to extract perihelion advance from real solver outputs and verify against a manifest.
It does not include real state vectors — plug in your data and run the verify script.

Suggested flow:
1) Produce `orbit_venus_state.csv`.
2) Run `extract_varpi.py` to compute `varpi_arcsec` vs `centuries`.
3) Run `verify_venus_real.py --report perihelion_venus_real_report.json --manifest manifest_venus_real.json`.
