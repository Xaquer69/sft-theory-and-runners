VENUS — Real Solver Overlay (GPU-ready)
---------------------------------------
Este overlay añade al paquete SFT scripts para:
(1) extraer la serie varpi(t) de un CSV de órbita (posiciones/velocidades o varpi precomputado),
(2) ajustar la pendiente (″/siglo) y
(3) verificar PASS/FAIL contra GR con umbrales preregistrados.

USO (dos rutas)
A) Si YA tienes un CSV con columnas [time(s), x, y, vx, vy]:
   $ python3 extract_varpi.py --csv orbit_venus_state.csv
   (genera varpi_series_venus_real.csv y perihelion_venus_real_report.json)

B) Si tu solver ya produce 'centuries,varpi_arcsec':
   $ python3 extract_varpi.py --csv varpi_series_from_solver.csv

VERIFICACIÓN
   $ python3 verify_venus_real.py --report perihelion_venus_real_report.json --manifest manifest_venus_real.json

MANIFIESTO (umbral por defecto)
- |slope_fit - expected_GR| ≤ 0.2 arcsec/century
- R² ≥ 0.995

NOTAS
- Este overlay no ejecuta el integrador CUDA; lo consume. Úsalo junto a tu 'run_orbit_gpu.sh'.
- Si tu CSV usa otros nombres de columnas: añade --time T --x X --y Y --vx VX --vy VY.
