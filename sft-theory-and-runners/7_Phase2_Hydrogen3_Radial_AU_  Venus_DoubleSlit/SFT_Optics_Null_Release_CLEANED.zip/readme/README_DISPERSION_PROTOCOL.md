# Vacuum Dispersion Test (Dual‑Color Cavity) — SFT Null Test

**Goal.** Measure a fractional index difference between two wavelengths in high vacuum:
Δn = n(λ₂) − n(λ₁). Standard SM+GR predict Δn = 0 (in vacuum, absent fields/matter).
SFT predicts a tiny dispersion: v/c ≈ 1 − C·(k·ℓ)². This protocol yields either a **limit** on ℓ or a **detection** (slope ≠ 0).

## Bill of Materials (minimal)
- Linear Fabry–Perot cavity, effective optical length L ≈ 10 m (folded OK), mirrors ULE or equivalent.
- Two lasers: λ₁ ≈ 1550 nm, λ₂ ≈ 775 nm (frequency-doubled channel OK).
- Frequency reference: optical comb or RF-stabilized transfer cavity. Record absolute frequencies if possible.
- Vacuum: ≤ 1e−6 mbar; temperature stability ≤ 10 mK/hour.
- Photodiodes for both channels, polarization-maintaining fibers preferred.
- DAQ: timestamps, frequency readback(s), temperature, pressure, lock error signals.

## Measurement Overview
Resonances satisfy m·λ = 2·n·L  (m ∈ ℤ). Equivalently, f = m·c/(2·n·L).
For each snapshot i, log (f_i, m_i, λ_i, L_i, T_i, P_i). Compute n_i = m_i·c/(2·L_i·f_i).
Form time series n(λ₁,t) and n(λ₂,t). The null observable is Δn(t) = n(λ₂,t) − n(λ₁,t).

## Key Practices
- Alternate quickly between λ₁ and λ₂ on the **same cavity**; minimize time skew to cancel L drift.
- Keep the **same longitudinal mode order m** for each wavelength across time. If m hops, note it.
- Log cavity temperature and pressure; include a CTE coefficient α_L if known (or fit a linear drift to cancel).
- Verify lock quality: reject samples with large error signal or lost lock (flag in CSV).

## PASS/FAIL (suggested thresholds)
- Stability: Allan deviation of Δn at τ = 10–100 s < 1e−15.
- Null test: |⟨Δn⟩| ≤ 5·σ_Δn → **PASS (null)**. If |⟨Δn⟩| > 5·σ_Δn → **FAIL (detection)**.
- If you test >2 wavelengths, fit Δn vs k²; nonzero slope at >5σ ⇒ **FAIL (detection)**.

## Analysis Steps
1) Compute n per row: n = m·c/(2·L·f). Use n≈1 as starting point if needed.
2) Construct Δn time series aligned by nearest timestamps.
3) Remove common-mode linear drift by regressing n(λ₁) and n(λ₂) against T,P (optional); re-check Δn.
4) Compute mean, stderr, Allan deviation, and export a JSON summary + plots.
5) Convert |⟨Δn⟩| (or slope vs k²) into a bound on ℓ:  ℓ < sqrt(|Δn| / (|C|·(k₂² − k₁²))).

## Data Fields (CSV)
- timestamp_iso8601
- wavelength_nm   (e.g., 1550 or 775)
- mode_index_m    (integer)
- freq_hz         (measured cavity resonance or locked laser frequency)
- cavity_length_m (geometric; if unknown, set nominal and let drift cancel)
- temperature_C
- pressure_mbar
- lock_ok         (1=valid, 0=drop)
- notes

See `dispersion_data_template.csv` for a prefilled header.

## PASS/FAIL JSON
The analysis writes `dispersion_summary.json` with: mean_Dn, stderr_Dn, allan_min, pass_stability, pass_null, bound_l_upper (if applicable).

## Safety
Laser class 3B/4—follow eyewear and beam management SOP. Maintain vacuum interlocks and ESD practices.
