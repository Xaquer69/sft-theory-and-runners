# Induced Circular Birefringence in Vacuum — SFT Null Test

**Claim tested.** In SFT, a helicity bias (two counter-propagating circularly polarized pumps with equal |E|)
can induce a tiny circular birefringence in vacuum for a weak probe: the cavity resonances for LCP vs RCP split by
Δf = (c/2L)·Δn, with Δn = ξ·h. SM+GR predict **zero** in this configuration (no matter, no external B-field).

## Minimal setup (telecom-friendly)
- Linear or ring cavity with dual-band HR/AR optics around 1550 nm.
- Two pump beams: one LCP along +z and one RCP along −z, same power; modulate total pump power P.
- Weak probe at same λ; detect the probe resonance for LCP and RCP (swap with a quarter-wave + polarizer).
- Vacuum is ideal; low-pressure air OK for a first look (then evacuate).

## Observable
At each pump power P (and helicity configuration), measure the **frequency splitting** Δf(P) = f_RCP − f_LCP of the **probe**.
SM+GR ⇒ Δf(P) = 0. SFT ⇒ Δf(P) ≈ K · ξ · P (linear at small P), where K depends on cavity geometry and mode overlap.

## PASS/FAIL
- Fit Δf vs P. If slope S = d(Δf)/dP is 0 within 5σ ⇒ **PASS (null)** and publish a **limit on |ξ|**.
- If |S| > 5σ ⇒ **FAIL (detection)**: report S and cross-check systematics (mirror birefringence drift, residual Faraday).

## Data schema (CSV)
- power_W       (average total pump power)
- split_Hz      (measured f_RCP − f_LCP of the probe)
- split_err_Hz  (1σ uncertainty of the splitting measurement)
- helicity      (+1 for (+z LCP, −z RCP), -1 for reversed; use both to cancel mirror drift)
- notes

See `birefringence_data_template.csv` for the header.

## Analysis outputs
- Linear fit slope S ± σ_S, χ²/ndf, p-value.
- PASS/FAIL flags and bound on ξ:  |ξ| < |S|/(K) at 5σ (provide/estimate K; script shows S/σ_S).
- Plots: Δf vs P with fit, and residuals.

Safety: beams at 1550 nm are invisible — wear InGaAs-rated eyewear.
