SFT Optics Null Tests — Release v1.1 (patched)
Generated: 2025-09-01T09:55:10.584379Z

Contents
========
/ (bundle core): original optics_null_tests_bundle_v1.1 contents
/docs:
  - SFT_Optics_Null_Tests_Pre-DoubleSlit_PATCH_dispersion_FIXED.docx   <-- place this before Double-Slit section
/artifacts:
  - optics_null_inventory.csv
  - optics_null_summary_per_column.csv
  - optics_null_summary_per_file.csv
  - optics_null_overall.json
  - dispersion_summary.json

How to use
==========
1) Review docs/SFT_Optics_Null_Tests_Pre-DoubleSlit_PATCH_dispersion_FIXED.docx (protocol + worked example).
2) Run the null tests on your CSVs (per the doc), producing the artifacts above.
3) Gate decision:
   - Null PASS & Stability PASS  -> proceed to Double-Slit
   - Null PASS & Stability FAIL -> hold; stabilize (ROI/temp/vibration), re-run
   - Null FAIL                  -> re-zero/diagnose, re-run

Notes
=====
- The manifest referenced in optics_null_overall.json (e.g., config/criteria.json) remains unchanged from the bundle.
- All files here are SHA-256 verifiable in your VCS/CI as needed.