#!/usr/bin/env python3
import json, argparse
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import chi2

def weighted_linear_fit(x, y, yerr):
    w = 1.0/(yerr**2)
    S = np.sum(w)
    Sx = np.sum(w*x)
    Sy = np.sum(w*y)
    Sxx = np.sum(w*x*x)
    Sxy = np.sum(w*x*y)
    Delta = S*Sxx - Sx*Sx
    m = (S*Sxy - Sx*Sy)/Delta
    b = (Sxx*Sy - Sx*Sxy)/Delta
    # errors
    m_err = np.sqrt(S/Delta)
    b_err = np.sqrt(Sxx/Delta)
    # chi2
    yfit = m*x + b
    chi2_val = np.sum(((y - yfit)/yerr)**2)
    dof = len(x)-2
    pval = 1 - chi2.cdf(chi2_val, dof) if dof>0 else 1.0
    return m, m_err, b, b_err, chi2_val, dof, pval

def analyze(csv_path, out_dir=".", K=1.0, sigma_thresh=5.0):
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=["power_W","split_Hz","split_err_Hz"])
    # Average opposite helicities to cancel drifts (optional)
    # Here we simply include both in the weighted fit.
    x = df["power_W"].values
    y = df["split_Hz"].values
    yerr = df["split_err_Hz"].values
    m, m_err, b, b_err, chi2_val, dof, pval = weighted_linear_fit(x,y,yerr)
    significance = abs(m)/m_err if m_err>0 else np.inf
    pass_null = (significance < sigma_thresh)
    # bound on xi (if K provided): |xi| < |m|/K at sigma_thresh if pass_null else report detection
    xi_bound = abs(m)/K if pass_null else None
    summary = {
        "csv": csv_path,
        "N": int(len(df)),
        "slope_Hz_per_W": float(m),
        "slope_err_Hz_per_W": float(m_err),
        "intercept_Hz": float(b),
        "chi2": float(chi2_val), "dof": int(dof), "pval": float(pval),
        "significance_sigma": float(significance),
        "pass_null": bool(pass_null),
        "xi_bound_over_K": float(xi_bound) if xi_bound is not None else None
    }
    import os, json
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "birefringence_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    # Plot
    import matplotlib.pyplot as plt
    plt.figure()
    plt.errorbar(x, y, yerr=yerr, fmt="o", label="data")
    xx = np.linspace(min(x), max(x), 200)
    plt.plot(xx, m*xx + b, "-", label=f"fit slope={m:.3e}±{m_err:.3e} Hz/W")
    plt.xlabel("Pump power P (W)")
    plt.ylabel("Probe splitting Δf (Hz)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir,"birefringence_fit.png"), dpi=160)
    plt.close()
    return summary

if __name__ == "__main__":
    import argparse, os, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", default=".")
    ap.add_argument("--K", type=float, default=1.0)
    ap.add_argument("--sigma", type=float, default=5.0)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    S = analyze(args.csv, out_dir=args.out, K=args.K, sigma_thresh=args.sigma)
    print(json.dumps(S, indent=2))
