#!/usr/bin/env python3
import json, argparse
from datetime import datetime
import numpy as np
import pandas as pd
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import Tuple

import json, os

def load_criteria(profile: str = "practical", config_path: str = None):
    # Find config near script if not provided
    if config_path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        cfg = os.path.join(os.path.dirname(here), "config", "criteria.json")
    else:
        cfg = config_path
    # Defaults
    defaults = {"dispersion": {"allan_threshold": 1e-15, "null_sigma": 5}}
    try:
        with open(cfg, "r") as f:
            data = json.load(f)
        profiles = data.get("profiles", {})
        if profile not in profiles:
            profile = data.get("default_profile", "practical")
        picked = profiles.get(profile, {})
        out = defaults
        out.update(picked)
        return out, profile, cfg
    except Exception:
        return defaults, profile, cfg


C0 = 299792458.0  # m/s

def parse_time(s):
    return datetime.fromisoformat(s.replace("Z","+00:00")) if "Z" in s else datetime.fromisoformat(s)

def load_data(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    # Basic cleaning
    df = df[df["lock_ok"]==1].copy()
    df["t"] = df["timestamp_iso8601"].apply(parse_time)
    df["k"] = 2*np.pi / (df["wavelength_nm"].values*1e-9)
    # Compute index n per sample: n = m*c/(2*L*f)
    df["n_est"] = (df["mode_index_m"]*C0)/(2*df["cavity_length_m"]*df["freq_hz"])
    return df

def align_series(df, wl1=1550, wl2=775, max_dt_s=0.5) -> pd.DataFrame:
    d1 = df[df["wavelength_nm"]==wl1].copy()
    d2 = df[df["wavelength_nm"]==wl2].copy()
    if d1.empty or d2.empty:
        raise ValueError("Both wavelengths must be present.")
    # Sort and convert times to epoch seconds (float) to avoid dtype issues
    d1 = d1.sort_values("t")
    d2 = d2.sort_values("t")
    t1 = d1["t"].apply(lambda x: x.timestamp()).values.astype(float)
    t2 = d2["t"].apply(lambda x: x.timestamp()).values.astype(float)
    out_rows = []
    j = 0
    for i in range(len(d1)):
        # advance pointer j to be near t1[i]
        while j+1 < len(d2) and abs(t2[j+1]-t1[i]) <= abs(t2[j]-t1[i]):
            j += 1
        # nearest neighbor around j
        cand_idx = [j]
        if j+1 < len(d2): cand_idx.append(j+1)
        if j-1 >= 0: cand_idx.append(j-1)
        # choose the closest among candidates
        idx = min(cand_idx, key=lambda k: abs(t2[k]-t1[i]))
        dt = abs(t2[idx]-t1[i])
        if dt <= max_dt_s:
            r1 = d1.iloc[i]
            r2 = d2.iloc[idx]
            out_rows.append({
                "t1": r1["t"], "t2": r2["t"],
                "dt_s": float(dt),
                "n1": float(r1["n_est"]), "n2": float(r2["n_est"]),
                "k1": float(r1["k"]), "k2": float(r2["k"]),
                "T1": float(r1.get("temperature_C", np.nan)), "T2": float(r2.get("temperature_C", np.nan)),
                "P1": float(r1.get("pressure_mbar", np.nan)),   "P2": float(r2.get("pressure_mbar", np.nan))
            })
    if not out_rows:
        raise ValueError("No aligned pairs within max_dt_s.")
    return pd.DataFrame(out_rows)
def allan_deviation(x: np.ndarray, m: int) -> float:
    """Overlapping Allan deviation for mean-removed series x, with averaging factor m (integer samples)."""
    if m < 1 or 2*m >= len(x):
        return np.nan
    # moving average of window m
    kernel = np.ones(m)/m
    y = np.convolve(x, kernel, mode='valid')
    # successive differences of adjacent averaged blocks
    diffs = y[m:] - y[:-m]
    return float(np.sqrt(0.5*np.mean(diffs**2)))
def run_analysis(csv_path: str, wl1=1550, wl2=775, max_dt_s=0.5, out_dir=".", criteria_profile=None, criteria_path=None):
    df = load_data(csv_path)
    crit, crit_profile, crit_path = load_criteria(criteria_profile, criteria_path)
    pairs = align_series(df, wl1=wl1, wl2=wl2, max_dt_s=max_dt_s)
    pairs["Dn"] = pairs["n2"] - pairs["n1"]
    mean_Dn = float(np.mean(pairs["Dn"]))
    std_Dn = float(np.std(pairs["Dn"], ddof=1))
    stderr_Dn = float(std_Dn/np.sqrt(len(pairs)))
    # Allan deviation across a grid of tau
    taus = np.unique(np.maximum(1, np.round(np.logspace(0, np.log10(max(2, len(pairs)//3)), 12)).astype(int)))
    allan = [(int(t), float(allan_deviation(pairs["Dn"].values, int(t)))) for t in taus if int(t)>=1]
    allan = [a for a in allan if not (np.isnan(a[1]) or np.isinf(a[1]))]
    allan_min = float(np.nanmin([a[1] for a in allan])) if allan else float("nan")
    # PASS/FAIL
    allan_thr = float(crit["dispersion"]["allan_threshold"])
    pass_stability = (allan_min < allan_thr) if not math.isnan(allan_min) else False
    null_sigma = float(crit["dispersion"]["null_sigma"])
    pass_null = (abs(mean_Dn) <= null_sigma*stderr_Dn) if stderr_Dn>0 else False
    # Optional bound on ℓ if mean ≠ 0: ℓ < sqrt(|Δn| / (C*(k2^2 - k1^2))) with C≈1
    k1 = float(np.median(pairs["k1"]))
    k2 = float(np.median(pairs["k2"]))
    denom = abs(k2**2 - k1**2)
    l_bound = float(np.sqrt(abs(mean_Dn)/denom)) if denom>0 and mean_Dn!=0 else None
    # Save summary
    summary = {
        "csv": csv_path,
        "N_pairs": int(len(pairs)),
        "mean_Dn": mean_Dn,
        "stderr_Dn": stderr_Dn,
        "allan_threshold_used": allan_thr,
        "null_sigma_used": null_sigma,
        "criteria_profile": crit_profile,
        "criteria_path": crit_path,
        "allan_min": allan_min,
        "pass_stability": pass_stability,
        "pass_null": pass_null,
        "wavelengths_nm": [wl1, wl2],
        "k1": k1, "k2": k2,
        "l_upper_bound_m_if_nonzero": l_bound
    }
    os.makedirs(out_dir, exist_ok=True)
    with open(f"{out_dir}/dispersion_summary.json","w") as f:
        json.dump(summary, f, indent=2)
    # Plots
    plt.figure()
    plt.plot(pairs["Dn"].values, marker=".", linestyle="-")
    plt.xlabel("Aligned sample index")
    plt.ylabel("Δn = n(λ2) − n(λ1)")
    plt.title("Vacuum dispersion null observable")
    plt.tight_layout()
    plt.savefig(f"{out_dir}/Dn_timeseries.png", dpi=160)
    plt.close()
    # Allan deviation plot
    if allan:
        taus = np.unique(np.maximum(1, np.round(np.logspace(0, np.log10(max(2, len(pairs)//3)), 12)).astype(int)))
        sigmas = [a[1] for a in allan]
        plt.figure()
        plt.loglog(taus, sigmas, marker="o")
        plt.xlabel("Averaging time τ (samples)")
        plt.ylabel("Allan deviation of Δn")
        plt.tight_layout()
        plt.savefig(f"{out_dir}/allan_deviation.png", dpi=160)
        plt.close()
    return summary

if __name__ == "__main__":
    import os
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Path to dispersion CSV")
    ap.add_argument("--wl1", type=float, default=1550.0)
    ap.add_argument("--wl2", type=float, default=775.0)
    ap.add_argument("--max_dt_s", type=float, default=0.5)
    ap.add_argument("--out", type=str, default=".")
    ap.add_argument("--criteria_profile", default=None)
    ap.add_argument("--criteria_path", default=None)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    summary = run_analysis(args.csv, wl1=args.wl1, wl2=args.wl2, max_dt_s=args.max_dt_s, out_dir=args.out, criteria_profile=args.criteria_profile, criteria_path=args.criteria_path)
    print(json.dumps(summary, indent=2))
