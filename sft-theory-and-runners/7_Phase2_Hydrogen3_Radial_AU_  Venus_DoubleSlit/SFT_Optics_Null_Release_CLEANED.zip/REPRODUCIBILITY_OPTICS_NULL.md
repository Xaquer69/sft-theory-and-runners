
# Reproducibility — Optics Null Tests (CPU-only)

Implements the SFT QA protocol for **null signals**: mean≈0 and drift≈0 vs predictor (time/S0), with BH-FDR at q=0.05.
Outputs CSV/JSON artifacts and a PASS/FAIL decision per columna, por archivo y global.

**Thresholds**
- Mean test: 95% CI incluye 0 **o** p> 0.05
- Pendiente vs predictor: p> 0.05
- FDR: q= 0.05 (Benjamini–Hochberg) aplicado por familias (medias y pendientes)
- Bounds opcionales (p.ej., visibility∈[0,1]) desde `manifest_null.json` si existe.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -U numpy pandas
python null_tests.py --inputs data/*.csv --manifest manifest_null.json --out artifacts/
```

Artifacts generados: `optics_null_inventory.csv`, `optics_null_summary_per_column.csv`, `optics_null_summary_per_file.csv`, `optics_null_overall.json`.
