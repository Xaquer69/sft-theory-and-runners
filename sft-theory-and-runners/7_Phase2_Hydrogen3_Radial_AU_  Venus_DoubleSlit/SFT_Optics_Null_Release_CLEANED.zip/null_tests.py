
import os, argparse, json, math
import numpy as np, pandas as pd

def normal_cdf(z): return 0.5*(1.0 + math.erf(z/math.sqrt(2.0)))
def pval_mean_zero(m, se):
    if se == 0 or not np.isfinite(se):
        return 1.0 if m == 0 else 0.0
    z = m/se; p = 2.0*(1.0 - normal_cdf(abs(z)))
    return max(min(p,1.0),0.0)
def slope_stats(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float); n=x.size
    X=np.vstack([x,np.ones_like(x)]).T
    slope,intercept=np.linalg.lstsq(X,y,rcond=None)[0]
    yhat=slope*x+intercept
    ss_res=np.sum((y-yhat)**2); ss_tot=np.sum((y-yhat.mean())**2) if False else np.sum((y-y.mean())**2)
    r2=1.0 - ss_res/ss_tot if ss_tot>0 else 1.0
    df=max(n-2,1); s2 = ss_res/df if df>0 else 0.0
    Sxx=np.sum((x-x.mean())**2)
    se_slope=math.sqrt(s2/Sxx) if Sxx>0 else float("inf")
    if not np.isfinite(se_slope) or se_slope==0: p=1.0 if slope==0 else 0.0
    else:
        z=slope/se_slope; p=2.0*(1.0 - normal_cdf(abs(z)))
    return slope, r2, se_slope, p
def bh_fdr(pvals,q=0.05):
    arr=np.asarray(pvals,float); idx=np.argsort(arr); m=len(arr); kmax=-1
    for rank,i in enumerate(idx, start=1):
        if arr[i] <= (rank/m)*q: kmax=rank
    return set(idx[:kmax]) if kmax>=1 else set()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--inputs","-i", nargs="+", required=True, help="CSV files (glob via shell)")
    ap.add_argument("--manifest","-m", default=None, help="manifest_null.json (optional)")
    ap.add_argument("--out","-o", default="artifacts", help="output folder")
    args=ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    defaults={"mean_p_min":0.05,"slope_p_min":0.05,"fdr_q":0.05,
              "predictors":["time","t","s0","S0"],
              "null_name_keys":["phase_null","i_dark","dark","background","bg","bias","offset","residual","null"]}
    M={}
    if args.manifest and os.path.exists(args.manifest):
        with open(args.manifest,"r",encoding="utf-8") as f: M=json.load(f)
    mean_p_min=M.get("mean_p_min",defaults["mean_p_min"])
    slope_p_min=M.get("slope_p_min",defaults["slope_p_min"])
    fdr_q=M.get("fdr_q",defaults["fdr_q"])
    roles=M.get("roles",{})
    pred_names=roles.get("predictors",defaults["predictors"])
    null_signals=set([s.lower() for s in roles.get("null_signals", [])])
    bounds=M.get("bounds",{})

    inv=[]; rows=[]; file_rows=[]
    for csvp in args.inputs:
        if not os.path.exists(csvp): continue
        df=pd.read_csv(csvp)
        for c in df.columns:
            if df[c].dtype==object:
                df[c]=pd.to_numeric(df[c],errors="ignore")
        pred=None
        for key in pred_names:
            for c in df.columns:
                if c.lower()==key.lower(): pred=c; break
            if pred: break
        if pred is None:
            for c in df.columns:
                if any(k in c.lower() for k in ["time","s0","t"]): pred=c; break
        if null_signals:
            ycols=[c for c in df.columns if c.lower() in null_signals]
        else:
            ycols=[]
            for c in df.columns:
                if c==pred: continue
                if pd.api.types.is_numeric_dtype(df[c]):
                    if any(k in c.lower() for k in defaults["null_name_keys"]):
                        ycols.append(c)
            if not ycols:
                ycols=[c for c in df.columns if c!=pred and pd.api.types.is_numeric_dtype(df[c])]
        inv.append({"csv_path":csvp,"n_rows":len(df),"n_cols":len(df.columns),
                    "predictor":pred if pred else "","n_null_cols":len(ycols)})
        for col in ycols:
            ser=pd.to_numeric(df[col],errors="coerce").dropna()
            n=ser.size
            m=float(ser.mean()); s=float(ser.std(ddof=1)); se=s/math.sqrt(n) if n>1 else float("inf")
            p_mean = pval_mean_zero(m,se) if n>=3 else float("nan")
            ci_lo=m-1.96*se; ci_hi=m+1.96*se
            slope=r2=se_slope=p_slope=float("nan")
            if pred and pd.api.types.is_numeric_dtype(df[pred]):
                x=pd.to_numeric(df[pred],errors="coerce").dropna()
                xy=pd.concat([x,ser],axis=1).dropna()
                if len(xy)>=3:
                    slope,r2,se_slope,p_slope = slope_stats(xy.iloc[:,0].values, xy.iloc[:,1].values)
            bounds_ok=True
            for key,(lo,hi) in bounds.items():
                if key.lower() in col.lower():
                    invalid=ser[(ser<lo)|(ser>hi)]
                    if len(invalid)>0: bounds_ok=False
            rows.append({"csv_path":csvp,"column":col,"n":int(n),
                         "mean":m,"std":s,"se":se,"mean_p":p_mean,"ci95_lo":ci_lo,"ci95_hi":ci_hi,
                         "slope":float(slope),"slope_se":float(se_slope),"slope_p":float(p_slope),"r2":float(r2),
                         "pass_mean":bool((ci_lo<=0.0<=ci_hi) or (p_mean>mean_p_min)),
                         "pass_slope":bool((not np.isfinite(p_slope)) or (p_slope>slope_p_min)),
                         "bounds_ok":bool(bounds_ok)})
    df_sum=pd.DataFrame(rows)
    def write_csv(df,p): 
        df.to_csv(p,index=False) if not df.empty else open(p,"w").write("")
    # FDR
    if not df_sum.empty:
        mask_mean=df_sum["mean_p"].apply(np.isfinite); rej_mean=bh_fdr(df_sum.loc[mask_mean,"mean_p"].values,q=fdr_q) if mask_mean.any() else set()
        rej_mean_idx=set(df_sum.loc[mask_mean].iloc[list(rej_mean)].index.tolist()) if mask_mean.any() else set()
        mask_slope=df_sum["slope_p"].apply(np.isfinite); rej_slope=bh_fdr(df_sum.loc[mask_slope,"slope_p"].values,q=fdr_q) if mask_slope.any() else set()
        rej_slope_idx=set(df_sum.loc[mask_slope].iloc[list(rej_slope)].index.tolist()) if mask_slope.any() else set()
        df_sum["fdr_mean_reject"]=df_sum.index.isin(rej_mean_idx)
        df_sum["fdr_slope_reject"]=df_sum.index.isin(rej_slope_idx)
        df_sum["gate_mean"]=df_sum["pass_mean"] & (~df_sum["fdr_mean_reject"])
        df_sum["gate_slope"]=df_sum["pass_slope"] & (~df_sum["fdr_slope_reject"])
        df_sum["gate_bounds"]=df_sum["bounds_ok"]
        df_sum["PASS_column"]=df_sum["gate_mean"] & df_sum["gate_slope"] & df_sum["gate_bounds"]
    inv_df=pd.DataFrame(inv)
    write_csv(inv_df, os.path.join(args.out,"optics_null_inventory.csv"))
    write_csv(df_sum, os.path.join(args.out,"optics_null_summary_per_column.csv"))
    if not df_sum.empty:
        for csvp, g in df_sum.groupby("csv_path"):
            file_rows.append({"csv_path":csvp,"n_columns_checked":int(len(g)),
                              "n_pass":int(g["PASS_column"].sum()),"n_fail":int((~g["PASS_column"]).sum()),
                              "PASS_file":bool(g["PASS_column"].all())})
    file_df=pd.DataFrame(file_rows)
    write_csv(file_df, os.path.join(args.out,"optics_null_summary_per_file.csv"))
    overall_pass=bool(file_df["PASS_file"].all()) if not file_df.empty else True
    with open(os.path.join(args.out,"optics_null_overall.json"),"w",encoding="utf-8") as f:
        json.dump({"overall_pass":overall_pass,"mean_p_min":mean_p_min,"slope_p_min":slope_p_min,"fdr_q":fdr_q}, f, indent=2)
    print(json.dumps({"overall_pass":overall_pass,"files":int(len(file_df)),"columns":int(df_sum.shape[0])}, indent=2))

if __name__=="__main__":
    raise SystemExit(main())
