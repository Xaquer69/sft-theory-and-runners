# Reproducibility — Venus perihelion (synthetic series)

Bundle contains synthetic perihelion precession for Venus (`varpi_arcsec` vs `centuries`) plus manifest & verifier.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python verify_venus_pack.py
```
Outputs PASS/FAIL and prints slope, R², and a 95% CI for the slope. Artifacts are checksummed in `checksums_SHA256.txt`.
