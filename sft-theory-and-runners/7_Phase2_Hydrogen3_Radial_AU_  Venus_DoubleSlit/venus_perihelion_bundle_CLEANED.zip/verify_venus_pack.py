import json, sys, numpy as np

CSV = "varpi_series_venus.csv"
MAN = "manifest_venus.json"

def load_series(path):
    # Supports the stacked format:
    #   centuries,
    #   varpi_arcsec
    #   x0
    #   y0
    #   x1
    #   y1
    #   ...
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = [ln.strip() for ln in f if ln.strip()!=""]
    # if typical CSV with comma in each line, fall back to pandas
    stacked = (len(lines)>=4 and "," not in lines[2] and "," not in lines[3])
    if stacked:
        vals = [float(x) for x in lines[2:]]
        x = np.array(vals[0::2], float)
        y = np.array(vals[1::2], float)
        return x, y
    # fallback: parse 2-column CSV
    import pandas as pd
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    x = df[df.columns[0]].to_numpy(float)
    y = df[df.columns[1]].to_numpy(float)
    return x, y

def fit_line(x, y):
    X = np.vstack([x, np.ones_like(x)]).T
    slope, intercept = np.linalg.lstsq(X, y, rcond=None)[0]
    yhat = slope*x + intercept
    ss_res = np.sum((y-yhat)**2); ss_tot = np.sum((y - y.mean())**2)
    r2 = 1 - ss_res/ss_tot
    # 95% CI (normal approx)
    n = len(x); p=2; s2 = ss_res/(n-p); Sxx = np.sum((x-x.mean())**2)
    se_slope = np.sqrt(s2/Sxx)
    zcrit = 1.96 if n>30 else 2.262
    ci = (slope - zcrit*se_slope, slope + zcrit*se_slope)
    return slope, intercept, r2, ci

def main():
    with open(MAN,"r",encoding="utf-8") as f:
        M = json.load(f)
    expected = M.get("expected_slope_arcsec_per_century", 8.624984)
    tol = M.get("tolerance_abs_arcsec_per_century", 0.2)
    r2_min = M.get("r2_min", 0.999)

    x,y = load_series(CSV)
    slope, intercept, r2, ci = fit_line(x,y)

    pass_slope = abs(slope - expected) <= tol
    pass_r2 = r2 >= r2_min

    print(f"slope_fit={slope:.6f}, expected={expected:.6f}, tol={tol}, R2={r2:.6f}")
    print(f"CI95: [{ci[0]:.6f}, {ci[1]:.6f}]")
    print("PASS_SLOPE =", pass_slope)
    print("PASS_R2    =", pass_r2)
    print("GLOBAL_PASS =", pass_slope and pass_r2)
    return 0 if (pass_slope and pass_r2) else 2

if __name__ == "__main__":
    sys.exit(main())
