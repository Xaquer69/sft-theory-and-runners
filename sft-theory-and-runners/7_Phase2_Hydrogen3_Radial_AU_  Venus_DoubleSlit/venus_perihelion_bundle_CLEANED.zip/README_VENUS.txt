VENUS — Perihelion Precession (synthetic series)
-------------------------------------------------
This bundle contains a synthetic 'centuries vs varpi_arcsec' series for Venus,
constructed to have a linear trend equal to the GR prediction at:
Δϖ ≈ 8.624984 arcsec/century

FILES
- varpi_series_venus.csv  (alternating lines: t, varpi)
- manifest_venus.json     (expected GR slope and PASS/FAIL thresholds)
- perihelion_venus_report.json (fit results, 95% CI, provenance)
- verify_venus.py         (reads the CSV, recomputes slope, checks PASS/FAIL)
- checksums_SHA256.txt

PASS/FAIL (from manifest)
- |slope_fit - expected_GR| ≤ 0.2 arcsec/century
- R² ≥ 0.999

HOW TO REPRODUCE
$ python3 verify_venus.py --csv varpi_series_venus.csv --manifest manifest_venus.json

This will print PASS/FAIL and write report_venus_verify.json
