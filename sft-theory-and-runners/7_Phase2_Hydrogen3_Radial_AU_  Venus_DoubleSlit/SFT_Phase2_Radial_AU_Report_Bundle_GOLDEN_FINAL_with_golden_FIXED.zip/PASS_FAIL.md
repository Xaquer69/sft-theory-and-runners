# PASS/FAIL — Golden path (Numerov + asymptotic BC), Rmax=110 a0, Δr=0.0035 a0

- Coulomb degeneracy: |E_2s − E_2p| ≤ 0.1 meV — **PASS**
  - H: Δ ≈ 0.0824 meV
  - T: Δ ≈ 0.0824 meV

- Hierarchy (T < H, ΔE_1s in [−7, −3] meV): **PASS** (see report §2 for analytical refs).

- Normalization & virial residuals: included in methodology (report §4).

Notes:
- Legacy Dirichlet results retained under results/legacy/ (splitting ≈ 4.076 meV → FAIL under revised criterion).
- See docs/SFT_Phase2_Radial_AU_Report_CORRECTED_v1.1_EN_GOLDEN_plus_err_conv.docx for full discussion, error vs analytical (6.3.1) and convergence plot (6.3.2).