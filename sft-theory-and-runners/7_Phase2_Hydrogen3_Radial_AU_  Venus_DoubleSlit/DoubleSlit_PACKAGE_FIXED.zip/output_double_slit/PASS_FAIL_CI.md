# Double Slit — PASS/FAIL
- phase_R2_min: 0.98
- vis_rel_sat_max: 0.10
- summary_json: double_slit_summary.json

**PASS**
