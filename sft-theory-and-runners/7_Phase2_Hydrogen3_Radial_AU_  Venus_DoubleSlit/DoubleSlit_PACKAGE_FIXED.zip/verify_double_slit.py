import os, json, numpy as np, pandas as pd
PHASE_R2_MIN=0.98; VIS_REL_SAT_MAX=0.1
def is_dec(arr, eps=1e-12): return np.all(np.diff(arr)<eps)
def last_rel(arr):
    if arr.size<2: return float("nan")
    a,b=arr[-2],arr[-1]
    return np.inf if a==0 and b!=0 else (0.0 if a==0 else abs(b-a)/abs(a))
def find(root, hint):
    for r,_,fs in os.walk(root):
        for fn in fs:
            lo=fn.lower()
            if hint in lo and lo.endswith('.csv'): return os.path.join(r,fn)
    return None
def main():
    base=os.getcwd()
    p=find(base,'shift') or find(base,'phase')
    v=find(base,'visibility')
    out={}
    okp=False; okv=False
    if p and os.path.exists(p):
        df=pd.read_csv(p)
        nums=[c for c in df.columns if np.issubdtype(df[c].dtype, np.number)]
        if len(nums)<2:
            for c in df.columns: df[c]=pd.to_numeric(df[c], errors='coerce')
            df=df.dropna(); nums=[c for c in df.columns if np.issubdtype(df[c].dtype, np.number)]
        x=df[nums[0]].to_numpy(float); y=df[nums[1]].to_numpy(float)
        X=np.vstack([x,np.ones_like(x)]).T
        slope,intercept=np.linalg.lstsq(X,y,rcond=None)[0]
        yhat=slope*x+intercept
        ss_res=np.sum((y-yhat)**2); ss_tot=np.sum((y-y.mean())**2)
        r2=1-ss_res/ss_tot
        out.update({"phase_slope":float(slope),"phase_r2":float(r2)})
        okp = (r2>=PHASE_R2_MIN)
    else:
        out["phase_error"]="phase/shift CSV not found"
    if v and os.path.exists(v):
        dv=pd.read_csv(v)
        cand=[c for c in dv.columns if 'vis' in c.lower()]
        arr=dv[cand[0]].to_numpy(float) if cand else dv[dv.columns[-1]].to_numpy(float)
        out["vis_monotonic"]=bool(is_dec(arr))
        out["vis_last_rel_change"]=float(last_rel(arr))
        out["vis_last_rel_change_gate"]=bool(out["vis_last_rel_change"]<=VIS_REL_SAT_MAX+1e-12)
        okv = out["vis_monotonic"] and out["vis_last_rel_change_gate"]
    else:
        out["visibility_error"]="visibility CSV not found"
    out["GLOBAL_PASS"]=bool(okp and okv)
    print(json.dumps(out, indent=2))
    return 0 if out["GLOBAL_PASS"] else 2
if __name__=='__main__': raise SystemExit(main())
