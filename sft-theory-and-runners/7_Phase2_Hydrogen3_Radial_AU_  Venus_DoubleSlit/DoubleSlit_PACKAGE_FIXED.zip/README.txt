Double Slit PACKAGED — 20250828T170243Z

Contenido:
- output_double_slit/…  → CSVs y summary listos (coinciden con PASS/FAIL).
- scripts/…             → run_auto.sh y run_auto_fixed.sh (CI/solver).
- original_bundle/…     → ZIP original y MANIFEST original (como referencia).
- MANIFEST_CI_NEW.md    → hashes SHA-256 de todos los ficheros clave en este paquete.

Reproducir (rápido):
  bash scripts/run_auto.sh --phase-r2-min 0.98 --vis-rel-sat 0.10

Notas:
- Este MANIFEST es específico de esta estructura; el MANIFEST original se conserva en original_bundle/.
