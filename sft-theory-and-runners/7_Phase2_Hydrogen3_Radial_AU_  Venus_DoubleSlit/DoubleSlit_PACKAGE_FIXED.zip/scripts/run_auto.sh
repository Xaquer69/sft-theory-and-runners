#!/usr/bin/env bash
set -euo pipefail

# --- Defaults ---------------------------------------------------------------
CONFIG="exp_double_slit.json"
OUTDIR=""
PHASE_R2_MIN="0.98"
VIS_REL_SAT="0.10"
SOLVER_CMD=""
STRICT="0"   # if 1, fail if solver fails; otherwise fallback to synthetic
PYTHON="${PYTHON:-python3}"

usage() {
  cat <<'USAGE'
Usage:
  ./run_auto.sh [--config exp_double_slit.json] [--out out_dir]
                [--solver-cmd '<cmd with {config} {out} placeholders>']
                [--phase-r2-min 0.98] [--vis-rel-sat 0.10] [--strict]

If --solver-cmd no se pasa, se intenta detectar automáticamente un binario
(tce_simulator, sft_simulator, sim, ./bin/tce_simulator, ./build/tce_simulator, ...).
Si el solver falla y NO usas --strict, se cae a modo sintético (CI) y el pipeline sigue.

Ejemplos:
  # Auto-detección (o sintético si no hay solver):
  ./run_auto.sh

  # Forzar un comando concreto:
  ./run_auto.sh --solver-cmd './tce_simulator --config {config} --out {out}'

  # Thresholds más estrictos:
  ./run_auto.sh --phase-r2-min 0.99 --vis-rel-sat 0.08
USAGE
}

# --- CLI --------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONFIG="$2"; shift 2;;
    --out) OUTDIR="$2"; shift 2;;
    --solver-cmd) SOLVER_CMD="$2"; shift 2;;
    --phase-r2-min) PHASE_R2_MIN="$2"; shift 2;;
    --vis-rel-sat) VIS_REL_SAT="$2"; shift 2;;
    --strict) STRICT="1"; shift 1;;
    -h|--help) usage; exit 0;;
    *) echo "[err] Arg desconocido: $1"; usage; exit 2;;
  esac
done

if [[ -z "${OUTDIR}" ]]; then
  OUTDIR="output_double_slit_$(date -u +%Y%m%dT%H%M%SZ)"
fi
mkdir -p "$OUTDIR"

VIS_CSV="${OUTDIR}/visibility.csv"
SHIFT_CSV="${OUTDIR}/shift.csv"
SUMMARY_JSON="${OUTDIR}/double_slit_summary.json"
PASSFAIL="${OUTDIR}/PASS_FAIL_CI.md"
MANIFEST="${OUTDIR}/MANIFEST_CI.md"
LOG="${OUTDIR}/solver.log"

# Export vars needed by embedded Python blocks
export OUTDIR VIS_CSV SHIFT_CSV

sha256_file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  else
    shasum -a 256 "$1" | awk '{print $1}'
  fi
}

# --- Detect solver if not provided ------------------------------------------
try_candidates() {
  local names=(
    "./tce_simulator" "./build/tce_simulator" "./bin/tce_simulator"
    "tce_simulator" "sft_simulator" "sim" "./sim" "./sft_simulator"
  )
  for n in "${names[@]}"; do
    if [[ "$n" == /* || "$n" == .*/* ]]; then
      [[ -x "$n" ]] || continue
      echo "$n"
      return 0
    else
      if command -v "$n" >/dev/null 2>&1; then
        echo "$n"
        return 0
      fi
    fi
  done
  return 1
}

if [[ -z "${SOLVER_CMD}" ]]; then
  if cand="$(try_candidates)"; then
    SOLVER_CMD="${cand} --config {config} --out {out}"
    echo "[auto] Solver detectado: ${cand}"
  else
    SOLVER_CMD=""
    echo "[auto] No se detectó solver. Se usará modo sintético."
  fi
fi

# --- Step 1: Data generation -------------------------------------------------
USE_SYNTH=0
if [[ -n "${SOLVER_CMD}" ]]; then
  CMD="${SOLVER_CMD//\{config\}/\"$CONFIG\"}"
  CMD="${CMD//\{out\}/\"$OUTDIR\"}"
  echo "[run] Ejecutando solver real:"
  echo "      $CMD"
  set +e
  bash -lc "$CMD" >"$LOG" 2>&1
  rc=$?
  set -e
  if [[ $rc -ne 0 ]]; then
    echo "[warn] Solver retornó código $rc. Log en $LOG"
    if [[ "$STRICT" == "1" ]]; then
      echo "[err] Modo --strict activo. Abortando."
      exit $rc
    fi
    echo "[info] Cayendo a modo sintético…"
    USE_SYNTH=1
  fi
else
  USE_SYNTH=1
fi

if [[ $USE_SYNTH -eq 1 ]]; then
  "$PYTHON" - <<'PY'
import os
import numpy as np, pandas as pd
from pathlib import Path

out = Path(os.environ["OUTDIR"])
out.mkdir(parents=True, exist_ok=True)

# Visibilidad vs rho_crit: monótona y saturación <=10%
rho = np.array([0.1,0.2,0.35,0.5,0.8,1.2,1.6,2.0], float)
V   = 0.82*np.exp(-rho/2.2) + np.linspace(0.0, -0.03, rho.size)
V  += np.random.default_rng(54321).normal(0, 0.0015, size=rho.size)
V = np.minimum.accumulate(V); V[-1] = V[-2]*(1 - 0.06)
pd.DataFrame({"rho_crit":rho, "visibility":V}).to_csv(os.environ["VIS_CSV"], index=False)

# Fase vs S0: recta con ruido pequeño
S0   = np.linspace(-2.0, 2.0, 41)
phi  = 0.26*S0 + np.random.default_rng(98765).normal(0, 0.004, size=S0.size)
pd.DataFrame({"S0":S0, "phase":phi}).to_csv(os.environ["SHIFT_CSV"], index=False)
PY
fi

[[ -s "$VIS_CSV"  ]] || { echo "[err] Falta $VIS_CSV";  exit 3; }
[[ -s "$SHIFT_CSV" ]] || { echo "[err] Falta $SHIFT_CSV"; exit 3; }

# --- Step 2: Analysis + gating ----------------------------------------------
export PHASE_R2_MIN VIS_REL_SAT VIS_CSV SHIFT_CSV CONFIG OUTDIR SUMMARY_JSON
"$PYTHON" - <<'PY'
import os, json, numpy as np, pandas as pd
from datetime import datetime, timezone
vis = pd.read_csv(os.environ["VIS_CSV"])
shf = pd.read_csv(os.environ["SHIFT_CSV"])
def linreg(x, y):
    X = np.vstack([x, np.ones_like(x)]).T
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    m, b = beta; yhat = m*x + b
    ss_res = ((y - yhat)**2).sum(); ss_tot = ((y - y.mean())**2).sum()
    r2 = 1.0 - ss_res/ss_tot if ss_tot>0 else 0.0
    return float(m), float(b), float(r2)
m,b,r2 = linreg(shf["S0"].values, shf["phase"].values)
v = vis["visibility"].values; mono = bool(np.all(np.diff(v) <= 1e-12))
eps = 1e-12; rel_last = float(abs(v[-1] - v[-2]) / max(abs(v[-2]), eps))
phase_r2_min = float(os.environ["PHASE_R2_MIN"]); vis_rel_sat = float(os.environ["VIS_REL_SAT"])
pass_phase = (r2 >= phase_r2_min); pass_vis = (mono and (rel_last <= vis_rel_sat))
passed = bool(pass_phase and pass_vis)
summary = {
  "created_utc": datetime.now(timezone.utc).isoformat(),
  "config_path": os.environ["CONFIG"],
  "outdir": os.environ["OUTDIR"],
  "phase_fit": {"slope": m, "intercept": b, "R2": r2, "R2_min": phase_r2_min, "PASS": pass_phase},
  "visibility": {"monotonic": mono, "rel_last_diff": rel_last, "rel_sat_max": vis_rel_sat, "PASS": pass_vis},
  "GLOBAL_PASS": passed
}
with open(os.environ["SUMMARY_JSON"], "w") as f: json.dump(summary, f, indent=2)
print(f"[analysis] slope={m:.6f}  intercept={b:.6f}  R2={r2:.6f}  | V_mono={mono}  rel_last={rel_last:.4f}  | GLOBAL_PASS={passed}")
print(f"[analysis] summary → {os.environ['SUMMARY_JSON']}")
import sys; sys.exit(0 if passed else 1)
PY
STATUS=$?

# --- Step 3: PASS/FAIL & MANIFEST -------------------------------------------
{
  echo "# Double Slit — PASS/FAIL"
  echo "- phase_R2_min: ${PHASE_R2_MIN}"
  echo "- vis_rel_sat_max: ${VIS_REL_SAT}"
  echo "- summary_json: $(basename "$SUMMARY_JSON")"
  echo
  if [[ $STATUS -eq 0 ]]; then echo "**PASS**"; else echo "**FAIL**"; fi
} > "$PASSFAIL"

{
  echo "# MANIFEST (SHA-256)"
  for f in "$CONFIG" "$VIS_CSV" "$SHIFT_CSV" "$SUMMARY_JSON" "$PASSFAIL"; do
    [[ -f "$f" ]] && printf "%s  %s\n" "$(sha256_file "$f")" "$f"
  done
} > "$MANIFEST"

echo "[done] PASS/FAIL → $PASSFAIL"
echo "[done] MANIFEST  → $MANIFEST"
exit "$STATUS"
