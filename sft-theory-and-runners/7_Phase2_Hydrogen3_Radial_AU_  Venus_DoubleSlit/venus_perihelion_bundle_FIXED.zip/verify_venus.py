#!/usr/bin/env python3
import json, argparse, numpy as np

def load_series(path):
    lines = [l.strip() for l in open(path, encoding='utf-8') if l.strip()!='']
    assert lines[0].startswith("centuries")
    assert lines[1].startswith("varpi_arcsec")
    vals = lines[2:]
    if len(vals)%2==1: vals = vals[:-1]
    t = np.array([float(vals[i]) for i in range(0, len(vals), 2)])
    v = np.array([float(vals[i]) for i in range(1, len(vals), 2)])
    return t, v

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="varpi_series_venus.csv")
    ap.add_argument("--manifest", default="manifest_venus.json")
    ap.add_argument("--out", default="report_venus_verify.json")
    args = ap.parse_args()

    t, v = load_series(args.csv)
    A = np.vstack([t, np.ones_like(t)]).T
    m, b = np.linalg.lstsq(A, v, rcond=None)[0]
    y = m*t + b
    ss_res = float(np.sum((v - y)**2))
    ss_tot = float(np.sum((v - v.mean())**2))
    R2 = 1 - ss_res/ss_tot

    man = json.load(open(args.manifest, "r", encoding="utf-8"))
    expected = float(man["expected_GR_arcsec_per_century"])
    tol = float(man["pass_fail"]["slope_tolerance_arcsec_per_century"])
    R2_min = float(man["pass_fail"]["R2_min"])

    pass_slope = bool(abs(float(m) - expected) <= tol)
    pass_R2 = bool(float(R2) >= R2_min)
    overall = bool(pass_slope and pass_R2)

    rep = {
      "slope_fit": float(m),
      "R2": float(R2),
      "expected": expected,
      "tolerance": tol,
      "pass_slope": pass_slope,
      "pass_R2": pass_R2,
      "PASS": overall
    }
    json.dump(rep, open(args.out,"w"), indent=2)
    print("PASS" if overall else "FAIL", rep)

if __name__ == "__main__":
    import numpy as np
    main()
