N_pass=0, GLOBAL_PASS=False
