#!/usr/bin/env python3
import argparse, os, json, numpy as np, pandas as pd, hashlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def sha256_file(path, chunk=1024*1024):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()

def make_demo():
    # demo grid: kappa in [0.7, 1.3], r_screen in [6, 14], bc_anchor in {0, 0.05, 0.1}
    rng = np.random.RandomState(0)
    kappas = np.linspace(0.7, 1.3, 13)
    rs = np.linspace(6.0, 14.0, 17)
    anchors = [0.0, 0.05, 0.1]
    rows = []
    for k in kappas:
        for r in rs:
            for a in anchors:
                # synthetic relations: stronger kappa & longer r_screen reduce split and compat residual;
                # bc_anchor also helps reduce split/compat a bit
                split = 0.30 - 0.12*(k-1.0) - 0.010*(r-10.0) - 0.25*a + 0.02*rng.randn()
                compat = 0.05 - 0.015*(k-1.0) - 0.002*(r-10.0) - 0.20*a + 0.005*rng.randn()
                R2 = 0.96 + 0.01*(k-1.0) + 0.003*(r-10.0) + 0.15*a + 0.01*rng.randn()
                split = max(0.01, split)
                compat = max(0.001, compat)
                R2 = max(0.90, min(0.999, R2))
                rows.append((k, r, a, split, compat, R2))
    df = pd.DataFrame(rows, columns=["kappa","r_screen","bc_anchor","split_meV","compat_norm","R2_disp"])
    return df

def main():
    ap = argparse.ArgumentParser(description="Synthetic Atom existence runner (medium-designed)")
    ap.add_argument("--in", dest="inp", help="CSV with: kappa,r_screen,bc_anchor,split_meV,compat_norm,R2_disp")
    ap.add_argument("--out", required=True, help="Output directory")
    ap.add_argument("--demo", action="store_true", help="Use synthetic dataset")
    ap.add_argument("--split_thr", type=float, default=0.10)
    ap.add_argument("--compat_thr", type=float, default=0.02)
    ap.add_argument("--r2_thr", type=float, default=0.98)
    ap.add_argument("--kappa_ref", type=float, default=1.0)
    ap.add_argument("--r_screen_ref", type=float, default=10.0)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    if args.demo:
        df = make_demo(); inp_sha = None
    else:
        if not args.inp or not os.path.exists(args.inp):
            raise SystemExit("Provide --in CSV or use --demo")
        df = pd.read_csv(args.inp); inp_sha = sha256_file(args.inp)

    # compute minimal maintenance
    df["pass"] = (df["split_meV"]<=args.split_thr) & (df["compat_norm"]<=args.compat_thr) & (df["R2_disp"]>=args.r2_thr)

    # existence region in (kappa, r_screen): flag=1 if there exists ANY bc_anchor that passes
    kappas = np.sort(df["kappa"].unique()); rs = np.sort(df["r_screen"].unique())
    region = np.zeros((len(rs), len(kappas)), dtype=int)
    for i,rv in enumerate(rs):
        for j,kv in enumerate(kappas):
            sub = df[(df["kappa"]==kv) & (df["r_screen"]==rv)]
            region[i,j] = 1 if (sub["pass"].any()) else 0

    # minimal tuple that passes
    passing = df[df["pass"]].copy()
    if len(passing)==0:
        verdict = "maintained"
        # pick closest by loss = max violations surrogate
        passing = df.copy()
        passing["loss"] = (np.maximum(0, passing["split_meV"]-args.split_thr)
                           + np.maximum(0, passing["compat_norm"]-args.compat_thr)
                           + np.maximum(0, args.r2_thr-passing["R2_disp"]))
        row = passing.sort_values("loss").iloc[0]
    else:
        # choose minimal maintenance norm from reference (favor bc_anchor=0)
        passing["deltaM"] = np.sqrt(((passing["kappa"]-args.kappa_ref)/args.kappa_ref)**2
                                    + ((passing["r_screen"]-args.r_screen_ref)/args.r_screen_ref)**2
                                    + (passing["bc_anchor"]**2))
        row = passing.sort_values(["bc_anchor","deltaM"]).iloc[0]
        verdict = "natural" if abs(row["bc_anchor"])<=1e-12 else "maintained"

    k_star = float(row["kappa"]); r_star = float(row["r_screen"]); a_star = float(row["bc_anchor"])
    deltaM_norm = float(np.sqrt(((k_star-args.kappa_ref)/args.kappa_ref)**2
                                + ((r_star-args.r_screen_ref)/args.r_screen_ref)**2
                                + (a_star**2)))

    # robustness proxy (demo): better robustness if far inside the pass-region; use margin to thresholds
    margin_split = max(0.0, args.split_thr - float(row["split_meV"]))
    margin_compat = max(0.0, args.compat_thr - float(row["compat_norm"]))
    margin_r2 = max(0.0, float(row["R2_disp"]) - args.r2_thr)
    tau_mean = float(1e4 + 5e4*(margin_split + margin_compat + margin_r2))

    # Plots
    # Heatmaps of split and compat at bc_anchor=0 and bc_anchor=min>0 (demo)
    import matplotlib.pyplot as plt
    for target_col, fname in [("split_meV","split_heatmap.png"), ("compat_norm","compat_heatmap.png")]:
        # pick bc = min available per (kappa,r) for the statistic
        agg = df.groupby(["kappa","r_screen"], as_index=False)[target_col].min()
        K = np.sort(agg["kappa"].unique()); R = np.sort(agg["r_screen"].unique())
        Z = np.zeros((len(R), len(K)))
        for i,rv in enumerate(R):
            row_i = agg[agg["r_screen"]==rv].sort_values("kappa")
            Z[i,:] = row_i[target_col].values
        plt.figure()
        plt.imshow(Z, origin="lower", aspect="auto", extent=[K[0],K[-1],R[0],R[-1]])
        plt.xlabel("kappa"); plt.ylabel("r_screen"); plt.title(f"{target_col} (min over bc_anchor)")
        plt.colorbar()
        plt.savefig(os.path.join(args.out, fname), dpi=150, bbox_inches="tight"); plt.close()

    # pass-region plot
    plt.figure()
    plt.imshow(region, origin="lower", aspect="auto", extent=[kappas[0],kappas[-1],rs[0],rs[-1]])
    plt.xlabel("kappa"); plt.ylabel("r_screen"); plt.title("Pass region (any bc_anchor)")
    plt.savefig(os.path.join(args.out, "pass_region.png"), dpi=150, bbox_inches="tight"); plt.close()

    # JSON artifacts
    thresholds = {"split_thr": args.split_thr, "compat_thr": args.compat_thr, "r2_thr": args.r2_thr}
    ref = {"kappa_ref": args.kappa_ref, "r_screen_ref": args.r_screen_ref, "bc_ref": 0.0}
    sha = {"input_csv": sha256_file(args.inp) if args.inp else None}
    scan = {
      "schema_version":"1.0.0",
      "grid": {"kappa": sorted(df["kappa"].unique().tolist()), "r_screen": sorted(df["r_screen"].unique().tolist()), "bc_anchor": sorted(df["bc_anchor"].unique().tolist())},
      "split_meV": df["split_meV"].tolist(),
      "compat_norm": df["compat_norm"].tolist(),
      "R2_disp": df["R2_disp"].tolist(),
      "thresholds": thresholds,
      "sha256": sha
    }
    region_json = {
      "schema_version":"1.0.0",
      "grid":{"kappa": kappas.tolist(), "r_screen": rs.tolist()},
      "region_flag": region.tolist(),
      "sha256": sha
    }
    exist = {
      "schema_version":"1.0.0",
      "system":"atomX",
      "verdict": verdict,
      "maintenance_cost":{"deltaM_norm": deltaM_norm, "kappa_star": k_star, "r_screen_star": r_star, "bc_anchor_star": a_star},
      "robustness":{"tau_mean": tau_mean, "margins":{"split": margin_split, "compat": margin_compat, "R2": margin_r2}},
      "thresholds": thresholds,
      "reference_medium": ref,
      "sha256": sha
    }
    with open(os.path.join(args.out, "COMPATIBILITY_SCAN_atomX.json"), "w") as f: json.dump(scan, f, indent=2)
    with open(os.path.join(args.out, "EXISTENCE_REGION_atomX.json"), "w") as f: json.dump(region_json, f, indent=2)
    with open(os.path.join(args.out, "EXISTENCE_REPORT_atomX.json"), "w") as f: json.dump(exist, f, indent=2)

if __name__=="__main__":
    main()
