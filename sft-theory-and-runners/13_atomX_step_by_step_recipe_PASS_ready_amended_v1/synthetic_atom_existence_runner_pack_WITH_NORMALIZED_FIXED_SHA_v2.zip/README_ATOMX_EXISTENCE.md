# Synthetic Atom (atomX) — Existence Runner (Medium-Designed Matter)

**Goal.** Decide if an atom-like configuration (degenerate levels, bound spectrum) **exists**:
- **natural:** gates pass with `bc_anchor = 0` (no maintenance control);
- **maintained:** gates pass only with `bc_anchor > 0` and/or tuned medium parameters.

**Medium parameters (inputs)**
- `kappa`      : kernel strength of the effective attraction (analogous to 1/r amplitude)
- `r_screen`   : screening length (units of the grid)
- `bc_anchor`  : boundary anchoring/control (0 = none)
- Observables: `split_meV` (target degeneracy gap), `compat_norm`, `R2_disp` (dispersion/stability proxy)

**Gates (defaults, configurable via CLI)**
- `split_meV <= 0.10`
- `compat_norm <= 0.02`
- `R2_disp >= 0.98`

**Verdict**
- Find the minimal triplet (kappa, r_screen, bc_anchor) that satisfies all gates.
- If `bc_anchor* == 0` at that minimum → **natural**; else → **maintained**.
- Maintenance cost is reported as a normalized norm of ΔM from a reference medium (`kappa_ref`, `r_screen_ref`, `bc_ref = 0`).

## Usage
```bash
python -m pip install -r requirements.txt

# Demo (synthetic dataset):
python runner/run_atomX.py --demo --out out/

# Real data (CSV):
python runner/run_atomX.py --in my_atom_scan.csv --out out/   --split_thr 0.10 --compat_thr 0.02 --r2_thr 0.98   --kappa_ref 1.0 --r_screen_ref 10.0
```

## Input CSV columns
`kappa,r_screen,bc_anchor,split_meV,compat_norm,R2_disp`

## Outputs (in `out/`)
- `EXISTENCE_REPORT_atomX.json`        (verdict, maintenance cost, robustness proxy)
- `EXISTENCE_REGION_atomX.json`        (grid in kappa×r_screen; flag if gates can be met for some bc_anchor)
- `COMPATIBILITY_SCAN_atomX.json`      (scan arrays and thresholds)
- Plots: `split_heatmap.png`, `compat_heatmap.png`, `pass_region.png`
