This folder includes EXISTENCE_REPORT_atomX_NORMALIZED.json created without modifying original files.
- Mapped verdict (e.g., 'exists' -> 'natural') to match schema
- Added witness.controls from REGION (kappa, r_screen) when recoverable
- Original EXISTENCE_REPORT_atomX.json remains untouched
