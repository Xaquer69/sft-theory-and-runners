print('Verifier: presence & non-empty region check. OK')
