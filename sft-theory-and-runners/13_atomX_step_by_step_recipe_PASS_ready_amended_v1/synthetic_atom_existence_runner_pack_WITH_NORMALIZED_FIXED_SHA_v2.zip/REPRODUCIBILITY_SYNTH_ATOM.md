# Reproducibility — Synthetic Atom (CPU-only)
Run `python verify_synth_atom.py` to validate JSONs and non-empty existence region.
