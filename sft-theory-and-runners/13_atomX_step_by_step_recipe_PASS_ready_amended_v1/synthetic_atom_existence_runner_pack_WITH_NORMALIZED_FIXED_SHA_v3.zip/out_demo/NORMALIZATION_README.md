This folder includes EXISTENCE_REPORT_atomX_NORMALIZED.json created without modifying original files.
- In v3, the base report is already schema-compliant (verdict natural/maintained), so NORMALIZED is a verbatim copy plus provenance fields.
- REGION/SCAN/plots were regenerated from runner/run_atomX.py --demo with preregistered thresholds.
