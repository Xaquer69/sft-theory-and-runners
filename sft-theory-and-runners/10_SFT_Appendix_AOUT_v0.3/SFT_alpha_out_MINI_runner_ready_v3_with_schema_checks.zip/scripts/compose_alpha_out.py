#!/usr/bin/env python3
import sys, json, math, time

def tier_from_rel_u95(rel_u95):
    if rel_u95 is None: return "Unrated"
    if rel_u95 <= 1e-6: return "Tier-3 (1e-6)"
    if rel_u95 <= 1e-4: return "Tier-2 (100 ppm)"
    if rel_u95 <= 1e-2: return "Tier-1 (1%)"
    return "Unrated"

def main():
    if len(sys.argv)<5:
        print("Usage: compose_alpha_out.py DISPERSION_LINEAR.json HBAR_FROM_ROTOR.json Q_EPS_SOLUTION.json ALPHA_OUT.json"); sys.exit(2)
    j_disp, j_hbar, j_qeps, out_json = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
    disp = json.load(open(j_disp))
    hbr  = json.load(open(j_hbar))
    qeps = json.load(open(j_qeps))
    c, uc = None, None
    if isinstance(disp.get("c"), dict):
        c = disp["c"].get("value"); uc = disp["c"].get("u95")
    else:
        c = disp.get("c"); uc = disp.get("u95_c")
    # ħ*
    hbar_star = None; uh = None
    if isinstance(hbr.get("hbar_star"), dict):
        hbar_star = hbr["hbar_star"].get("value"); uh = hbr["hbar_star"].get("u95")
    else:
        hbar_star = hbr.get("hbar_star")
    if hbar_star is None and "I" in hbr and "a" in hbr:
        I = hbr["I"]["value"] if isinstance(hbr["I"],dict) else hbr["I"]
        a = hbr["a"]["value"] if isinstance(hbr["a"],dict) else hbr["a"]
        if I is not None and a is not None and I>=0 and a>=0:
            hbar_star = math.sqrt(2*a*I)
            # simple propagation if u95 provided
            uI = hbr["I"].get("u95") if isinstance(hbr.get("I"),dict) else None
            ua = hbr["a"].get("u95") if isinstance(hbr.get("a"),dict) else None
            if uI is not None or ua is not None:
                # ln ħ = 0.5(ln a + ln I) + const → rel var add
                rel2 = 0.0
                if uI: rel2 += (0.5*uI/I)**2
                if ua: rel2 += (0.5*ua/a)**2
                uh = abs(hbar_star)*math.sqrt(rel2) if rel2>0 else None
    # q*, ε*
    q = None; uq = None
    e = None; ue = None
    if isinstance(qeps.get("q_star"), dict):
        q = qeps["q_star"].get("value"); uq = qeps["q_star"].get("u95")
    else:
        q = qeps.get("q_star")
    if isinstance(qeps.get("eps_star"), dict):
        e = qeps["eps_star"].get("value"); ue = qeps["eps_star"].get("u95")
    else:
        e = qeps.get("eps_star")
    missing = [name for name,val in dict(c=c,hbar_star=hbar_star,q_star=q,eps_star=e).items() if val is None]
    out = {
        "schema_version":"1.0.0",
        "inputs":{
            "c":{"value":c,"u95":uc},
            "hbar_star":{"value":hbar_star,"u95":uh},
            "q_star":{"value":q,"u95":uq},
            "eps_star":{"value":e,"u95":ue}
        }
    }
    if missing:
        out["status"]="INCOMPLETE"; out["missing"]=missing
    else:
        alpha = (q*q)/(4.0*math.pi*e*hbar_star*c)
        # relative uncertainty (95%) via first-order propagation; treat missing u95 as 0
        terms = []
        if uq: terms.append(abs(2*uq/q))
        if ue: terms.append(abs(ue/e))
        if uh: terms.append(abs(uh/hbar_star))
        if uc: terms.append(abs(uc/c))
        rel_u95 = math.sqrt(sum(t*t for t in terms)) if terms else None
        out["alpha_out"]={
            "value":alpha,
            "u95_rel": rel_u95,
            "tier": tier_from_rel_u95(rel_u95)
        }
        out["status"]="COMPLETE"
    with open(out_json,"w") as f: json.dump(out, f, indent=2)
    print(f"Wrote {out_json}; status={out.get('status')}")
if __name__=="__main__":
    main()
