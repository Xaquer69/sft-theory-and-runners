# SFT — Alpha‑Out MINI Runner (runnable demo)

This mini-pack lets a reviewer run an end‑to‑end **alpha‑out** demo on CPU with toy data.

## Quick start

```bash
python scripts/fit_dispersion.py Example/dispersion.csv Example/DISPERSION_LINEAR.json
python scripts/solve_q_eps.py Example/coulomb_profile.csv Example/field_energy.json Example/Q_EPS_SOLUTION.json
python scripts/compose_alpha_out.py Example/DISPERSION_LINEAR.json Example/HBAR_FROM_ROTOR.json Example/Q_EPS_SOLUTION.json Example/ALPHA_OUT.json
```

Or just run the verifier:

```bash
python scripts/verify_alpha_out_pipeline.py
```

## Notes
- **Toy policy (q*, ε*):** we set q* = 1 (ua), so ε* = 1/(4πA) from the fitted A in Er ≈ A/r².
- **HBAR_FROM_ROTOR.json:** for this demo we provide `hbar_star` directly; real pipelines may compute it from I and a.
- All JSONs include `schema_version` and are plain JSON (NaN/Inf not allowed).
