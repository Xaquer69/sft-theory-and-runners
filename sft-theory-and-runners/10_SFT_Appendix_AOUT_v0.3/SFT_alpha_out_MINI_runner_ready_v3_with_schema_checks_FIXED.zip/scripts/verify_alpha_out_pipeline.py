#!/usr/bin/env python3
import sys, json, subprocess, os

def load_json(p):
    with open(p) as f: return json.load(f)

def require_keys(obj, keys, name):
    missing = [k for k in keys if k not in obj]
    if missing:
        raise AssertionError(f"{name}: missing keys {missing}")

def assert_number(x, name):
    if not isinstance(x, (int, float)) or isinstance(x, bool):
        raise AssertionError(f"{name}: expected number, got {type(x)}")

def validate_dispersion(path, schema_version="1.0.0"):
    j = load_json(path)
    require_keys(j, ["schema_version","fit_model","c","R2_smallk","indices_used","status"], "DISPERSION_LINEAR.json")
    if j["schema_version"] != schema_version:
        raise AssertionError("DISPERSION_LINEAR.json: wrong schema_version")
    assert "value" in j["c"], "DISPERSION_LINEAR.json: c.value missing"
    assert_number(j["c"]["value"], "c.value")
    return True

def validate_qeps(path, schema_version="1.0.0"):
    j = load_json(path)
    require_keys(j, ["schema_version","A","q_star","eps_star","status"], "Q_EPS_SOLUTION.json")
    if j["schema_version"] != schema_version:
        raise AssertionError("Q_EPS_SOLUTION.json: wrong schema_version")
    assert "value" in j["A"], "A.value missing"
    assert "value" in j["q_star"], "q_star.value missing"
    assert "value" in j["eps_star"], "eps_star.value missing"
    return True

def validate_hbar(path, schema_version="1.0.0"):
    j = load_json(path)
    if j.get("schema_version") != schema_version:
        raise AssertionError("HBAR_FROM_ROTOR.json: wrong or missing schema_version")
    if "hbar_star" not in j:
        # must have I and a
        if not ("I" in j and "a" in j):
            raise AssertionError("HBAR_FROM_ROTOR.json must have hbar_star OR (I and a)")
    return True

def validate_alpha(path, schema_version="1.0.0"):
    j = load_json(path)
    require_keys(j, ["schema_version","inputs","status"], "ALPHA_OUT.json")
    if j["schema_version"] != schema_version:
        raise AssertionError("ALPHA_OUT.json: wrong schema_version")
    if j["status"]=="COMPLETE":
        assert "alpha_out" in j, "ALPHA_OUT.json COMPLETE but alpha_out missing"
        ao = j["alpha_out"]
        if "value" not in ao: raise AssertionError("alpha_out.value missing")
        if "tier" not in ao: raise AssertionError("alpha_out.tier missing")
    return True

def main():
    root = os.path.dirname(__file__)
    ex = os.path.join(root, "..", "Example")
    disp_in  = os.path.join(ex, "dispersion.csv")
    coul_in  = os.path.join(ex, "coulomb_profile.csv")
    field_in = os.path.join(ex, "field_energy.json")
    hbar_in  = os.path.join(ex, "HBAR_FROM_ROTOR.json")
    disp_out = os.path.join(ex, "DISPERSION_LINEAR.json")
    qeps_out = os.path.join(ex, "Q_EPS_SOLUTION.json")
    aout_out = os.path.join(ex, "ALPHA_OUT.json")
    # Run steps
    subprocess.check_call([sys.executable, os.path.join(root,"fit_dispersion.py"), disp_in, disp_out])
    subprocess.check_call([sys.executable, os.path.join(root,"solve_q_eps.py"), coul_in, field_in, qeps_out])
    subprocess.check_call([sys.executable, os.path.join(root,"compose_alpha_out.py"), disp_out, hbar_in, qeps_out, aout_out])
    # Structural validation ("schema checks")
    validate_dispersion(disp_out)
    validate_qeps(qeps_out)
    validate_hbar(hbar_in)
    validate_alpha(aout_out)
    # Final status gate
    a = load_json(aout_out)
    assert a.get("status")=="COMPLETE", "ALPHA_OUT.json not COMPLETE"
    tier = a.get("alpha_out",{}).get("tier","Unrated")
    print("VERIFY: PASS — status COMPLETE,", "tier:", tier, "| schema checks OK")
if __name__=="__main__":
    main()
