#!/usr/bin/env python3
import sys, json, csv, math

def read_csv(path):
    ks, ws = [], []
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            k = float(row["k"]); w = float(row["omega"])
            ks.append(k); ws.append(w)
    return ks, ws

def linreg(x, y):
    n = len(x)
    xm = sum(x)/n; ym = sum(y)/n
    Sxx = sum((xi-xm)**2 for xi in x)
    Sxy = sum((xi-xm)*(yi-ym) for xi,yi in zip(x,y))
    slope = Sxy/Sxx if Sxx>0 else 0.0
    intercept = ym - slope*xm
    # residuals & stats
    resid = [yi - (slope*xi+intercept) for xi,yi in zip(x,y)]
    SSE = sum(e*e for e in resid)
    dof = max(1, n-2)
    s2 = SSE/dof
    se_slope = math.sqrt(s2/Sxx) if Sxx>0 else float('inf')
    R2 = 1.0 - (SSE / sum((yi-ym)**2 for yi in y)) if n>2 else 0.0
    return slope, intercept, R2, se_slope

def main():
    if len(sys.argv)<3:
        print("Usage: fit_dispersion.py dispersion.csv DISPERSION_LINEAR.json"); sys.exit(2)
    csv_in, json_out = sys.argv[1], sys.argv[2]
    ks, ws = read_csv(csv_in)
    if len(ks)<3: raise SystemExit("Need >=3 rows in dispersion.csv")
    # small-k selection: lowest 60% |k| values
    pairs = sorted(zip(ks, ws), key=lambda t: abs(t[0]))
    m = max(3, int(0.6*len(pairs)))
    ks_s = [p[0] for p in pairs[:m]]
    ws_s = [p[1] for p in pairs[:m]]
    c, b, R2, se_c = linreg(ks_s, ws_s)  # omega ≈ c*k + b
    # If intercept is tiny, refit through origin for robustness
    if abs(b) < 1e-9:
        den = sum(k*k for k in ks_s)
        c = sum(k*w for k,w in zip(ks_s, ws_s))/den if den>0 else c
        # recompute standard error via residuals about origin fit
        resid = [w - c*k for k,w in zip(ks_s, ws_s)]
        SSE = sum(e*e for e in resid)
        dof = max(1, m-1)
        s2 = SSE/dof
        se_c = math.sqrt(s2/den) if den>0 else float('inf')
        # R2 recompute
        ym = sum(ws_s)/len(ws_s)
        ss_tot = sum((y-ym)**2 for y in ws_s)
        ss_res = sum((y-c*x)**2 for x,y in zip(ks_s, ws_s))
        R2 = 1.0 - (ss_res/ss_tot if ss_tot>0 else 0.0)
        b = 0.0
    u95_c = 1.96*se_c if math.isfinite(se_c) else None
    out = {
        "schema_version":"1.0.0",
        "fit_model":"omega = c*k (small-k)",
        "c":{"value": c, "u95": u95_c, "units":"ua"},
        "intercept":{"value": b},
        "R2_smallk": R2,
        "indices_used": list(range(m)),
        "status":"COMPLETE"
    }
    with open(json_out,"w") as f: json.dump(out, f, indent=2)
    print(f"Wrote {json_out}; c≈{c:.6g} ±{(u95_c or float('nan')):.3g} (95%), R2={R2:.4f}, m={m}")

if __name__=="__main__":
    main()
