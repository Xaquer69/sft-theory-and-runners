#!/usr/bin/env python3
import sys, json, csv, math

def read_coulomb(csv_path):
    rs, Er = [], []
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rs.append(float(row["r"]))
            Er.append(float(row["E_r"]))
    return rs, Er

def main():
    if len(sys.argv)<4:
        print("Usage: solve_q_eps.py coulomb_profile.csv field_energy.json Q_EPS_SOLUTION.json"); sys.exit(2)
    csv_in, field_json, out_json = sys.argv[1], sys.argv[2], sys.argv[3]
    rs, Er = read_coulomb(csv_in)
    if len(rs)<3: raise SystemExit("Need >=3 rows in coulomb_profile.csv")
    # Fit A in Er ≈ A/r^2 via y=Er*r^2, x=1 (mean of y)
    y = [e*(r*r) for e,r in zip(Er, rs)]
    n = len(y)
    A = sum(y)/n
    # Uncertainty of mean → u95_A
    if n>1:
        var = sum((yi-A)**2 for yi in y)/(n-1)
        se = math.sqrt(var/n)
        u95_A = 1.96*se
    else:
        u95_A = None
    # Toy policy: set q*=1 ua to identify eps* from A
    FOURPI = 4.0*math.pi
    q_star = 1.0
    eps_star = (1.0/(FOURPI*A)) if A!=0 else None
    u95_eps = None
    if eps_star is not None and u95_A is not None and A!=0:
        # delta method: eps = 1/(4πA) → d eps/dA = -1/(4π A^2)
        u95_eps = abs((1.0/(FOURPI*(A**2))) * u95_A)
    out = {
        "schema_version":"1.0.0",
        "model":"Er = (q*/(4π ε*))/r^2 (toy: q*=1)",
        "A":{"value":A,"u95":u95_A,"units":"ua"},
        "q_star":{"value":q_star,"u95":0.0,"units":"ua"},
        "eps_star":{"value":eps_star,"u95":u95_eps,"units":"ua"},
        "field_energy":{"value": json.load(open(field_json)).get('U', None),
                        "units": json.load(open(field_json)).get('units','ua')},
        "status":"COMPLETE" if eps_star is not None else "INCOMPLETE",
        "notes":"Toy assumption q*=1 to extract ε* from A."
    }
    with open(out_json,"w") as f: json.dump(out, f, indent=2)
    print(f"Wrote {out_json}; A≈{A:.6g} ±{(u95_A or float('nan')):.3g}, eps*≈{(eps_star or float('nan')):.6g} ±{(u95_eps or float('nan')):.3g} (95%)")

if __name__=="__main__":
    main()
