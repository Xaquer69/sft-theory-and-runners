# SFT — Alpha‑Out (v0.3‑FINAL) — Reviewer How‑To
Run in 4 steps: fit c → close ħ* → solve (q*,ε*) → compose α. See README_AOUT.md for details.