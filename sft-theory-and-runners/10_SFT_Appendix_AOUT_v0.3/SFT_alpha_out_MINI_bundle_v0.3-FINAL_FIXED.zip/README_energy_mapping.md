# Mapeo ENERGY_REPORT → field_energy.json (para α-out)
Si ya tienes un `ENERGY_REPORT.json` siguiendo el esquema de Doc9, puedes construir `field_energy.json` así:

- `U` := `components.tN.em`  (energía electromagnética a tiempo final)
- `B` := si tu pipeline reporta `B = ∫ E^2 dV` en algún campo, úsalo aquí; de lo contrario, deja `null` y `solve_q_eps.py` lo aproximará a partir del `coulomb_profile.csv`.

Ejemplo:
{
  "U": 0.1234,
  "B": null
}

Recuerda usar la **misma región de corte** que en el perfil radial (ventana de ajuste) para que U y B sean consistentes.
