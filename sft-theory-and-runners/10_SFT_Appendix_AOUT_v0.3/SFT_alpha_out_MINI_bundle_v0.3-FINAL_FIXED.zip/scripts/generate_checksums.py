#!/usr/bin/env python3
import hashlib, os, argparse
def sha256_of(path, buf=1024*1024):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        while True:
            b=f.read(buf)
            if not b: break
            h.update(b)
    return h.hexdigest()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root", default="."); args=ap.parse_args()
    entries=[]
    for root, dirs, files in os.walk(args.root):
        for fn in files:
            p=os.path.join(root,fn)
            if os.path.basename(fn)=="MANIFEST_SHA256.txt": continue
            entries.append((p, sha256_of(p)))
    entries.sort()
    with open("MANIFEST_SHA256.txt","w",encoding="utf-8") as f:
        for p,h in entries: f.write(f"{h}  {p}\n")
    print(f"Wrote MANIFEST_SHA256.txt with {len(entries)} entries.")
if __name__=="__main__": main()
