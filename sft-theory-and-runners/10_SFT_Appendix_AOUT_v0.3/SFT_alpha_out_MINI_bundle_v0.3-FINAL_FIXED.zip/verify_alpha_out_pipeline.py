#!/usr/bin/env python3
"""SFT alpha-out mini-bundle verifier.

This verifier is designed to be reviewer-friendly:
- Verifies file integrity via checksums_SHA256.txt
- Validates Examples/ JSON artifacts against Schemas/ (jsonschema draft 2020-12)
- Runs a smoke test for the alpha-out computation chain using the included
  example CSVs (dispersion + Coulomb profile). The smoke test writes outputs
  to _run/ and reports which *inputs are missing* for a full alpha-out.

Note:
A FULL alpha-out requires (at minimum):
  - A rotor-derived hbar* (or rotor fit 'a' + moment of inertia I)
  - A Coulomb run ENERGY_REPORT or field_energy.json providing U (EM energy).

Usage:
  python3 verify_alpha_out_pipeline.py
  python3 verify_alpha_out_pipeline.py --no-run
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent


def _run(cmd: list[str]) -> tuple[int, str]:
    """Run a command and capture combined output."""
    p = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return p.returncode, p.stdout


def check_integrity() -> dict:
    rc, out = _run(["sha256sum", "-c", "checksums_SHA256.txt"]) if (ROOT / "checksums_SHA256.txt").exists() else (2, "missing checksums_SHA256.txt")
    # Summarize OK/FAIL counts
    ok = sum(1 for line in out.splitlines() if line.strip().endswith(": OK"))
    fail = sum(1 for line in out.splitlines() if line.strip().endswith(": FAILED"))
    return {"rc": rc, "ok": ok, "failed": fail, "raw": out.strip()}


def _load_json(p: Path) -> dict:
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def validate_examples() -> dict:
    """Validate Examples/*.json against Schemas/*.schema.json where possible."""
    schemas_dir = ROOT / "Schemas"
    examples_dir = ROOT / "Examples"

    # Map example -> schema by filename prefix
    mapping = {
        "ppn_results": "ppn_results.schema.json",
        "energy_report": "energy_report.schema.json",
    }

    results = []
    for ex in sorted(examples_dir.glob("*.json")):
        schema_name = None
        for prefix, sch in mapping.items():
            if ex.name.startswith(prefix):
                schema_name = sch
                break
        if not schema_name:
            continue
        schema_path = schemas_dir / schema_name
        try:
            schema = _load_json(schema_path)
            inst = _load_json(ex)
            v = Draft202012Validator(schema)
            errs = sorted(v.iter_errors(inst), key=lambda e: list(e.absolute_path))
            results.append({
                "file": ex.name,
                "schema": schema_name,
                "valid": len(errs) == 0,
                "n_errors": len(errs),
                "errors": [
                    {"path": "/".join(map(str, e.absolute_path)), "message": e.message}
                    for e in errs[:10]
                ],
            })
        except Exception as e:
            results.append({"file": ex.name, "schema": schema_name, "valid": False, "error": str(e)})

    return {
        "validated": len(results),
        "passed": sum(1 for r in results if r.get("valid")),
        "failed": sum(1 for r in results if not r.get("valid")),
        "details": results,
    }


def smoke_run_alpha_out() -> dict:
    """Run the chain on example CSVs and report missing inputs."""
    run_dir = ROOT / "_run"
    run_dir.mkdir(exist_ok=True)

    disp_in = ROOT / "Examples" / "dispersion.csv"
    coul_in = ROOT / "Examples" / "coulomb_profile.csv"
    field_energy = run_dir / "field_energy.json"

    # Use the provided template (U,B null) unless the user supplies their own field_energy.json.
    template = ROOT / "field_energy_from_energy_report_TEMPLATE.json"
    if not field_energy.exists():
        field_energy.write_text(template.read_text(encoding="utf-8"), encoding="utf-8")

    disp_out = run_dir / "DISPERSION_LINEAR.json"
    qe_out = run_dir / "Q_EPS_SOLUTION.json"
    hbar_in = ROOT / "HBAR_FROM_ROTOR.json"
    hbar_copy = run_dir / "HBAR_FROM_ROTOR.json"
    hbar_copy.write_text(hbar_in.read_text(encoding="utf-8"), encoding="utf-8")
    alpha_out = run_dir / "ALPHA_OUT.json"

    rc1, out1 = _run(["python3", "scripts/fit_dispersion.py", str(disp_in), str(disp_out)])
    rc2, out2 = _run(["python3", "scripts/solve_q_eps.py", str(coul_in), str(field_energy), str(qe_out)])
    rc3, out3 = _run(["python3", "scripts/compose_alpha_out.py", str(disp_out), str(hbar_copy), str(qe_out), str(alpha_out)])

    # Load computed artifacts for summary
    D = _load_json(disp_out) if disp_out.exists() else {}
    Q = _load_json(qe_out) if qe_out.exists() else {}
    A = _load_json(alpha_out) if alpha_out.exists() else {}

    return {
        "rc": max(rc1, rc2, rc3),
        "commands": {
            "fit_dispersion": {"rc": rc1, "stdout": out1.strip()},
            "solve_q_eps": {"rc": rc2, "stdout": out2.strip()},
            "compose_alpha_out": {"rc": rc3, "stdout": out3.strip()},
        },
        "computed": {
            "c_estimate": D.get("c_estimate"),
            "R2_smallk": D.get("R2_smallk"),
            "A_fit": Q.get("fit_A_from_profile"),
            "B": Q.get("B"),
            "eps_star": Q.get("eps_star"),
            "q_star": Q.get("q_star"),
            "alpha_out_status": A.get("status"),
            "missing": A.get("missing", []),
        },
        "notes": [
            "This smoke-test uses U=null (from template), so eps_star/q_star are expected to be null.",
            "To complete alpha-out, provide field_energy.json with U (e.g., components.tN.em from ENERGY_REPORT.json) and a schema-grade HBAR_FROM_ROTOR.json.",
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-run", action="store_true", help="skip the alpha-out smoke run")
    args = ap.parse_args()

    report = {
        "timestamp": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "integrity": check_integrity(),
        "schemas_examples": validate_examples(),
    }
    if not args.no_run:
        report["alpha_out_smoke_run"] = smoke_run_alpha_out()

    out_path = ROOT / "verify_report.json"
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))

    # Return non-zero only if integrity fails or example schema validation fails.
    if report["integrity"]["rc"] != 0:
        return 2
    if report["schemas_examples"]["failed"] != 0:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
