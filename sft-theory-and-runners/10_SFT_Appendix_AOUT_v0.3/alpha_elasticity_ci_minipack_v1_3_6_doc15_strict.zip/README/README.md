# Alpha Elasticity Validation Suite — Minimal Runnable CI Pack

This pack is a **CPU-only** runnable implementation of the **Alpha-Elasticity Validation Suite (CI/Synthetic)**.
It is designed to validate **pipeline integrity** and **verifier behavior** (PASS/FAIL gates), not physical claims.

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Verify checksums
sha256sum -c checksums_SHA256.txt

# Run verifier (produces out/ALPHA_ELASTICITY_REPORT.json and out/MANIFEST_SHA256.txt)
python3 verify_alpha_elasticity_ci.py
```

## Artifact contract (minimal)
Outputs are written to `out/`:

- `ALPHA_ELASTICITY_REPORT.json` (schema-validated)
- `MANIFEST_SHA256.txt` (hashes for all input+output artifacts used)
- `DECISION_RULE.json` (frozen thresholds, referenced by `gate_id`)
- `SCAN_ALPHA_ELASTICITY.json` (optional scan artifact; included here as minimal stub)

## Status labels
- `CI`: CPU-only synthetic / convenience verification (no physical validation)

## Notes
- The verifier uses a small synthetic generator + deterministic seeds.
- Fixtures under `fixtures/` provide PASS and FAIL examples for regression tests.


## Doc15-strict notes
- Inputs are on-disk `S_field_*.npz` + `meta_*.json` under `data/datasets/`.
- No data-dependent calibration: the estimator never sees alpha_reference; alpha_reference is computed from meta via a locked mapping for scoring only.
- Two manifests are produced: `ALPHA_ELASTICITY_MANIFEST_SHA256.txt` and `MANIFEST_SHA256.txt`.
