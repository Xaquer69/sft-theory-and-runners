# Reproducibility — Alpha‑Out Mini‑Bundle (v0.3, CPU‑only)
