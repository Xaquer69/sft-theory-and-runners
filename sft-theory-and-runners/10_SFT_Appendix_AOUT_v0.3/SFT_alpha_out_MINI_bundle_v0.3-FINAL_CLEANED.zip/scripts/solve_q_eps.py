import json, sys, math
import pandas as pd
import numpy as np

# Usage: python solve_q_eps.py coulomb_profile.csv field_energy.json Q_EPS_SOLUTION.json

csv_in, fe_json, out_json = sys.argv[1], sys.argv[2], sys.argv[3]
df = pd.read_csv(csv_in)
r = df['r'].to_numpy(float)
Er = df['E_r'].to_numpy(float)
order = np.argsort(r)
r = r[order]; Er = Er[order]
n = len(r)
lo = int(0.2*n); hi = int(0.8*n)
rr = r[lo:hi]; ee = Er[lo:hi]
X = (1.0/(rr**2))[:,None]
A = float(np.linalg.lstsq(X, ee, rcond=None)[0][0])
with open(fe_json, "r") as f: fed = json.load(f)
U = fed.get("U", None)
B = fed.get("B", None)
if B is None:
  dr = np.mean(np.diff(r))
  B = float(np.sum((Er**2) * (4.0*math.pi*(r**2)) * dr))
eps_star = 2.0*U/B if (U is not None and B and B>0) else None
q_star = 4.0*math.pi*A*eps_star if eps_star is not None else None
payload = {"fit_A_from_profile":A,"U":U,"B":B,"eps_star":eps_star,"q_star":q_star,
           "notes":"Ensure same cutoff region as profile window for consistency."}
with open(out_json, "w") as f: json.dump(payload, f, indent=2)
print(json.dumps(payload, indent=2))
