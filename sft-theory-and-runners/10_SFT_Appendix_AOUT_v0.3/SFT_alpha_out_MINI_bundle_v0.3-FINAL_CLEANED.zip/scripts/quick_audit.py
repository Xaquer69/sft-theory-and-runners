#!/usr/bin/env python3
import json, os, argparse, glob
REQ_PPN_A = ["schema_version","route","conventions","fit","derived","qa","provenance","timestamp"]
REQ_PPN_B = ["schema_version","route","conventions","observables_fit","derived","qa","provenance","timestamp"]
REQ_ENERGY = ["schema_version","integrator","grid","units","components","conservation","discretization","provenance","timestamp"]
def loadj(p): 
    with open(p,"r",encoding="utf-8") as f: return json.load(f)
def check_ppn(d):
    missing=[]; 
    if d.get("route")=="A":
        for k in REQ_PPN_A:
            if k not in d: missing.append(k)
    else:
        for k in REQ_PPN_B:
            if k not in d: missing.append(k)
    ok = (not missing) and "derived" in d and all(k in d["derived"] for k in ["beta","gamma"])
    return ok, missing
def check_energy(d):
    missing=[k for k in REQ_ENERGY if k not in d]; ok=not missing; return ok, missing
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--dir", default="Examples"); args=ap.parse_args()
    out={"ppn":[], "energy":[], "summary":{}}
    for p in glob.glob(os.path.join(args.dir, "ppn_results_*.json")):
        d=loadj(p); ok, miss=check_ppn(d); out["ppn"].append({"file": os.path.basename(p), "ok": ok, "missing": miss})
    for p in glob.glob(os.path.join(args.dir, "energy_report_*.json")):
        d=loadj(p); ok, miss=check_energy(d); out["energy"].append({"file": os.path.basename(p), "ok": ok, "missing": miss})
    out["summary"]["ppn_ok"]=sum(1 for x in out["ppn"] if x["ok"]); out["summary"]["ppn_total"]=len(out["ppn"])
    out["summary"]["energy_ok"]=sum(1 for x in out["energy"] if x["ok"]); out["summary"]["energy_total"]=len(out["energy"])
    with open("quick_audit_report.json","w",encoding="utf-8") as f: json.dump(out,f,indent=2,ensure_ascii=False)
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=="__main__": main()
