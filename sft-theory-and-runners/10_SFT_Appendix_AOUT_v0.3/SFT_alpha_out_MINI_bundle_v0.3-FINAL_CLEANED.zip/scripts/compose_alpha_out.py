import json, sys, math

# Usage: python compose_alpha_out.py DISPERSION_LINEAR.json HBAR_FROM_ROTOR.json Q_EPS_SOLUTION.json ALPHA_OUT.json

def load(p):
  with open(p,"r") as f: return json.load(f)

disp, hb, qe, outp = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
D = load(disp); H = load(hb); Q = load(qe)

c = D.get("c_estimate")
hbar = H.get("hbar_star")
if hbar is None and "fit_params" in H and "I" in H and H["I"] not in (None, 0):
  a = H["fit_params"]["a"]; I = H["I"]; hbar = (2.0*a*I)**0.5

q = Q.get("q_star"); eps = Q.get("eps_star")
res = {"inputs":{"c":c,"hbar_star":hbar,"q_star":q,"eps_star":eps}}
if None not in (c,hbar,q,eps):
  res["alpha_out"] = (q*q)/(4.0*math.pi*eps*hbar*c)
  res["status"] = "OK"
else:
  res["status"] = "INCOMPLETE"
  res["missing"] = [k for k,v in [("c",c),("hbar_star",hbar),("q_star",q),("eps_star",eps)] if v is None]
with open(outp,"w") as f: json.dump(res, f, indent=2)
print(json.dumps(res, indent=2))
