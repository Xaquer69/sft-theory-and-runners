import json, sys
import pandas as pd
import numpy as np

# Usage: python fit_dispersion.py dispersion.csv DISPERSION_LINEAR.json

csv_in, json_out = sys.argv[1], sys.argv[2]
df = pd.read_csv(csv_in)
k = df['k'].to_numpy(float)
w = df['omega'].to_numpy(float)
idx = np.argsort(np.abs(k))
n = max(3, int(0.2*len(k)))
sel = idx[:n]
ks = k[sel]; ws = w[sel]
c = float(np.dot(ks, ws) / np.dot(ks, ks))
res = ws - c*ks
R2 = 1 - (res@res) / np.sum((ws - ws.mean())**2) if len(ws)>2 else float("nan")
payload = {"fit_model":"omega = c * k (small-k)","n_points_smallk":int(n),"c_estimate":c,"R2_smallk":float(R2)}
with open(json_out, "w") as f: json.dump(payload, f, indent=2)
print(json.dumps(payload, indent=2))
