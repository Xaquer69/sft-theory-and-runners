# SFT — Alpha‑Out MINI Review Package (v0.2-AOUT)
Timestamp (UTC): 2025-09-16 16:43:09Z

## Purpose & scope (alpha‑out)
This bundle is for **limited external review**. It documents the **α‑in calibration** (single‑pass) and the **operational tests** (PPN extraction, energy/continuity, convergence) without exposing internal scratch or intermediate notebooks. Claims are restricted to the scope explicitly stated in **Doc9** and the **Appendix**.

**Do not** re‑tune parameters between demonstrations. All results must be derived under the same frozen calibration \{q*, ħ*, ε*, μ*\}.

## Contents
- **Doc9/** — main statement for reviewers (preferred: `9_SFT_Argument_with_Appendix.docx`).  
- **Appendices/** — English addendum (consistency, ontological scale, thermal decoherence).  
- **Schemas/** — JSON Schemas for `PPN_RESULTS.json` and `ENERGY_REPORT.json`.  
- **Examples/** — minimal JSON artifacts that conform to the schemas (route A & B for PPN; energy with/without collapse).  
- **scripts/** — `quick_audit.py` (light checks) and `generate_checksums.py` (builds MANIFEST).  
- **MANIFEST_SHA256.txt** — checksums for integrity.

## Quick start (reviewers)
1. Open **Doc9/9_SFT_Argument_with_Appendix.docx** and read *Quick Start* + *Last‑Mile Appendix*.
2. Validate **Examples/** against **Schemas/** with any JSON Schema validator.
3. (Optional) Run **scripts/quick_audit.py --dir Examples** to produce `quick_audit_report.json`.
4. Verify integrity using **MANIFEST_SHA256.txt**.

## Conventions & QA gates (short)
- Notation: **φ ≡ U/c²** (dimensionless), **S ≡ −U**.  
- PPN: fit (a1,c1,a2) → **γ=c1/a1**, **β=1+a2/a1²**; report **95% CI**.  
- Mesh scaling: verify dispersion slope **ξ≈−1/12** (central differences), **3‑grid EOC** (target **p≈2**), and **energy/continuity** (with collapse ledger when applicable).  
- Decoherence (thermal): FDT‑consistent noise; check **ln V** linear in **T** and path length at fixed grid; **grid‑independence** at fixed **T**.

## Language guardrails
- Use “**consistent with**” rather than “predicts” unless explicitly pre‑registered.  
- Keep the **α‑in** policy explicit; any α‑out claim must be labeled as such and accompanied by a pre‑registered protocol.

— End of README —
