print('alpha-out verifier placeholder ready; run on provided JSONs')
