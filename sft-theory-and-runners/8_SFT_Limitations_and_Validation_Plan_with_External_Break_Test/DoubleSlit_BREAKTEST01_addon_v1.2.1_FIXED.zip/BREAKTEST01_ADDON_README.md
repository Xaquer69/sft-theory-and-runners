# BREAKTEST01 (DoubleSlit) — Observable-level rescaling gate (v1.1)

This addon adds a preregistered BREAKTEST01 gate that checks the scaling of `phase_slope`
under a simple rescaling λ applied to the phase/shift observable CSV.

## Run
```bash
python3 breaktest01_run_doubleslit.py
```

Outputs:
- `_BREAKTEST01_runs/BREAKTEST01_REPORT.json`
- `_BREAKTEST01_runs/BREAKTEST01_MANIFEST_SHA256.txt`

## What is rescaled
This DoubleSlit pack does **not** expose a raw field `S(x)`.
So BREAKTEST01 is applied at the **observable level**:
- `output_double_slit/shift.csv` → multiply the **y-column** (`phase`) by λ.

### Visibility
`output_double_slit/visibility.csv` is **not modified by default**.
If you explicitly preregister it, set:
`observable_inputs.visibility_csv.scale_by_lambda = true` in `DECISION_RULE_BREAKTEST01.json`.

## Audit rules
- Tightening thresholds is only allowed if preregistered (no post-hoc tuning).
- The runner verifies the SHA256 of `DECISION_RULE_BREAKTEST01.json` before running.
