#!/usr/bin/env python3
"""BREAKTEST01 for DoubleSlit_PACKAGE_FIXED (v1.1)

Creates lambda-variant copies under _BREAKTEST01_runs/, applies a preregistered
observable-level rescaling, runs verify_double_slit.py in each, and evaluates
a preregistered scaling gate.

Decision rule: DECISION_RULE_BREAKTEST01.json
decision_rule_sha256: b9b301c687193fa0830425c50e3f757e0011f6ad7f3e27892e6f02c5a421ed63
"""

from __future__ import annotations

import json
import hashlib
import shutil
import subprocess
import re
from pathlib import Path
from typing import Any, Optional, Tuple, Union

import pandas as pd
import numpy as np

# --- Self-checks (fail fast) -------------------------------------------------
def _self_check(decision_rule_path):
    # 1) Ensure this file is syntactically valid (already imported) and decision rule is readable JSON.
    try:
        with open(decision_rule_path, "r", encoding="utf-8") as f:
            dr = json.load(f)
    except Exception as e:
        raise SystemExit(f"BREAKTEST01 FAIL: cannot load decision rule JSON: {decision_rule_path} :: {e}")

    # 2) Minimal required fields (keep this lightweight and pack-agnostic)
    required_top = ["breaktest_id", "lambdas", "scaling_test", "tolerance_rel"]
    missing = [k for k in required_top if k not in dr]
    if missing:
        raise SystemExit(f"BREAKTEST01 FAIL: decision rule missing fields: {missing}")

    if not isinstance(dr["lambdas"], list) or len(dr["lambdas"]) < 2:
        raise SystemExit("BREAKTEST01 FAIL: decision rule 'lambdas' must be a list with >=2 entries.")
    if dr["scaling_test"] not in ("phase_slope", "phase_slope_linear"):
        # accept common aliases; otherwise require explicit mapping
        raise SystemExit(f"BREAKTEST01 FAIL: unexpected scaling_test={dr['scaling_test']!r}.")
    try:
        tol = float(dr["tolerance_rel"])
    except Exception:
        raise SystemExit("BREAKTEST01 FAIL: tolerance_rel must be numeric.")
    if not (0.0 < tol < 1.0):
        raise SystemExit("BREAKTEST01 FAIL: tolerance_rel must be in (0,1).")

    return dr

# -----------------------------------------------------------------------------

DECISION_RULE_PATH = "DECISION_RULE_BREAKTEST01.json"


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(cmd, cwd: Path) -> Tuple[int, str]:
    p = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    return p.returncode, (p.stdout or "") + "\n" + (p.stderr or "")


def find_csv(root: Path, hint: str) -> Optional[Path]:
    hint = hint.lower()
    for p in root.rglob("*.csv"):
        if hint in p.name.lower():
            return p
    return None


def _col_to_name(df: pd.DataFrame, col: Union[str, int, None]) -> Optional[str]:
    if col is None:
        return None
    if isinstance(col, int):
        return df.columns[col]
    return str(col)


def _detect_two_numeric_cols(df: pd.DataFrame) -> Tuple[str, str]:
    # Use a numeric view to detect columns with at least one numeric value.
    numeric = df.apply(pd.to_numeric, errors="coerce")
    nums = [c for c in df.columns if numeric[c].notna().any()]
    if len(nums) < 2:
        raise RuntimeError("Could not detect >=2 numeric columns in CSV")
    return nums[0], nums[1]


def scale_csv_y(src: Path, dst: Path, lam: float, *, x_column: Union[str, int, None] = None, y_column: Union[str, int, None] = None) -> Tuple[str, str]:
    """Multiply the y-column by lambda and write back. Returns (xcol, ycol) used."""
    df = pd.read_csv(src)

    # Resolve explicit columns if provided; otherwise fall back to numeric detection.
    ycol = _col_to_name(df, y_column)
    xcol = _col_to_name(df, x_column)
    if ycol is None:
        xdet, ydet = _detect_two_numeric_cols(df)
        xcol = xcol or xdet
        ycol = ydet

    # Scale only ycol; keep other columns unchanged.
    y = pd.to_numeric(df[ycol], errors="coerce")
    df[ycol] = y.astype(float) * float(lam)

    dst.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(dst, index=False)
    return xcol, ycol


def parse_json_from_verify(output: str) -> dict:
    # verify script prints JSON to stdout
    try:
        return json.loads(output)
    except Exception:
        # sometimes extra stderr; try to extract first JSON object
        m = re.search(r"\{.*\}", output, re.DOTALL)
        if not m:
            raise
        return json.loads(m.group(0))


def _resolve_csv_spec(root: Path, spec: Optional[dict], *, default_hint: str) -> Tuple[Path, Optional[Union[str, int]], Optional[Union[str, int]], str]:
    """Return (path, x_col, y_col, mode) where mode is 'explicit' or 'heuristic'."""
    if isinstance(spec, dict) and spec.get("relpath"):
        p = root / spec["relpath"]
        if not p.exists():
            raise FileNotFoundError(f"CSV not found at preregistered path: {spec['relpath']}")
        return p, spec.get("x_column"), spec.get("y_column"), "explicit"

    p = find_csv(root, default_hint)
    if p is None:
        raise FileNotFoundError(f"Could not find required CSV (hint='{default_hint}')")
    return p, None, None, "heuristic"


def main() -> int:
    root = Path(".").resolve()

    decision = json.loads((root / DECISION_RULE_PATH).read_text(encoding="utf-8"))
    expected_sha = "b9b301c687193fa0830425c50e3f757e0011f6ad7f3e27892e6f02c5a421ed63"
    actual_sha = sha256_file(root / DECISION_RULE_PATH)
    if actual_sha != expected_sha:
        raise SystemExit(f"DECISION_RULE sha256 mismatch: expected {expected_sha}, got {actual_sha}")

    lambdas = decision["lambdas"]
    targets = decision["scaling_targets"]
    target = targets[0]
    ref_lam = float(target.get("reference_lambda", 1.0))
    tol_rel = float(target["tolerance_rel"])

    obs_inputs = decision.get("observable_inputs", {})

    phase_path, phase_x_spec, phase_y_spec, phase_mode = _resolve_csv_spec(
        root,
        obs_inputs.get("phase_csv"),
        default_hint="shift",
    )

    vis_spec = obs_inputs.get("visibility_csv")
    vis_path, vis_x_spec, vis_y_spec, vis_mode = _resolve_csv_spec(
        root,
        vis_spec,
        default_hint="visibility",
    )

    # Backward compatible: if key missing, behave like legacy v1.0 (scale visibility).
    scale_visibility = True
    if isinstance(vis_spec, dict) and ("scale_by_lambda" in vis_spec):
        scale_visibility = bool(vis_spec["scale_by_lambda"])

    base_dir = root / "_BREAKTEST01_runs"
    base_dir.mkdir(exist_ok=True)

    # Snapshot pack (exclude breaktest runs dir)
    snapshot = base_dir / "base_pack"
    if snapshot.exists():
        shutil.rmtree(snapshot)
    shutil.copytree(root, snapshot, ignore=shutil.ignore_patterns("_BREAKTEST01_runs"))

    results = []
    slopes = {}

    # Remember exactly what we touched for audit.
    rel_phase = phase_path.relative_to(root)
    rel_vis = vis_path.relative_to(root)

    phase_cols_used = None
    vis_cols_used = None

    lambda_run_dirs = {}  # lam -> run_dir
    for lam in lambdas:
        run_dir = base_dir / f"lambda_{lam:g}"
        lambda_run_dirs[lam] = run_dir
        if run_dir.exists():
            shutil.rmtree(run_dir)
        shutil.copytree(snapshot, run_dir)

        # Scale phase/shift observable
        px, py = scale_csv_y(run_dir / rel_phase, run_dir / rel_phase, lam, x_column=phase_x_spec, y_column=phase_y_spec)
        phase_cols_used = (px, py)

        # Optionally scale visibility observable (preregistered)
        if scale_visibility:
            vx, vy = scale_csv_y(run_dir / rel_vis, run_dir / rel_vis, lam, x_column=vis_x_spec, y_column=vis_y_spec)
            vis_cols_used = (vx, vy)
        else:
            # still resolve columns for reporting
            dv = pd.read_csv(run_dir / rel_vis)
            vx = _col_to_name(dv, vis_x_spec)
            vy = _col_to_name(dv, vis_y_spec)
            if vy is None:
                vx_det, vy_det = _detect_two_numeric_cols(dv)
                vx = vx or vx_det
                vy = vy_det
            vis_cols_used = (vx, vy)

        code, out = run(["python3", "verify_double_slit.py"], cwd=run_dir)
        (run_dir / "BREAKTEST01_verify_log.txt").write_text(out, encoding="utf-8")

        j = parse_json_from_verify(out)
        j["lambda"] = lam
        results.append(j)
        slopes[float(lam)] = float(j.get("phase_slope", float("nan")))

    # Scaling gate: slope(lam)/slope(ref) ~ (lam/ref)^exponent
    ref_slope = slopes.get(ref_lam)
    gate_ok = True
    gate_details = []
    for lam in map(float, lambdas):
        if lam == ref_lam:
            continue
        expected = (lam / ref_lam) ** float(target["expected_exponent"])
        ratio = slopes[lam] / ref_slope if ref_slope not in (0, None) else float("nan")
        rel_err = abs(ratio - expected) / (abs(expected) + 1e-12)
        ok = bool(rel_err <= tol_rel + 1e-12)
        gate_details.append({
            "lambda": lam,
            "ratio": ratio,
            "expected_ratio": expected,
            "rel_err": rel_err,
            "tolerance_rel": tol_rel,
            "pass": ok
        })
        gate_ok = gate_ok and ok

    report = {
        "suite_version": "BREAKTEST01-DoubleSlit-v1.2",
        "gate_id": "BREAKTEST01_DOUBLESLIT_SLOPE_SCALING",
        "decision_rule_ref": DECISION_RULE_PATH,
        "decision_rule_sha256": actual_sha,
        "inputs": {
            "phase_csv": {
                "relpath": str(rel_phase).replace("\\\\", "/"),
                "x_column": phase_cols_used[0] if phase_cols_used else None,
                "y_column": phase_cols_used[1] if phase_cols_used else None,
                "found_by": phase_mode,
                "scaled_by_lambda": True,
            },
            "visibility_csv": {
                "relpath": str(rel_vis).replace("\\\\", "/"),
                "x_column": vis_cols_used[0] if vis_cols_used else None,
                "y_column": vis_cols_used[1] if vis_cols_used else None,
                "found_by": vis_mode,
                "scaled_by_lambda": bool(scale_visibility),
            }
        },
        "lambdas": lambdas,
        "scaling_gate": {
            "observable": "phase_slope",
            "reference_lambda": ref_lam,
            "expected_exponent": target["expected_exponent"],
            "tolerance_rel": tol_rel,
            "details": gate_details,
            "PASS": gate_ok
        },
        "per_lambda_verify": results,
        "GLOBAL_PASS": bool(gate_ok and all(r.get("GLOBAL_PASS") for r in results))
    }

    out_path = base_dir / "BREAKTEST01_REPORT.json"
    out_path.write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")

    # manifest (sha256) — sha256sum -c compatible (HASH  RELPATH)
    # Include core files + per-lambda modified inputs/logs for auditability.
    manifest_entries = {}

    # Core files
    try:
        manifest_entries["breaktest01_run_doubleslit.py"] = sha256_file(Path(__file__))
    except Exception:
        pass
    manifest_entries[Path(DECISION_RULE_PATH).name] = sha256_file(root / DECISION_RULE_PATH)
    manifest_entries[out_path.name] = sha256_file(out_path)

    # Per-lambda inputs/logs (if present)
    for lam, run_dir in lambda_run_dirs.items():
        for rel in [
            "output_double_slit/shift.csv",
            "output_double_slit/visibility.csv",
            "BREAKTEST01_verify_log.txt",
            "BREAKTEST01_checksums.txt",
        ]:
            p = run_dir / rel
            if p.exists():
                manifest_entries[f"lambda_{lam:g}/{rel}"] = sha256_file(p)

    manifest_text = "\n".join([f"{h}  {name}" for name, h in sorted(manifest_entries.items())]) + "\n"
    (base_dir / "BREAKTEST01_MANIFEST_SHA256.txt").write_text(manifest_text, encoding="utf-8")

    print(json.dumps(report, indent=2))
    return 0 if report["GLOBAL_PASS"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
