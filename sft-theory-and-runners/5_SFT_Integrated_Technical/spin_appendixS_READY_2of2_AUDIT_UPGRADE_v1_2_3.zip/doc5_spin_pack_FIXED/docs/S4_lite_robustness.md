# S.4-lite Robustez (sensibilidad y validación cruzada)

Este paquete **carece de la cobertura S.4 ≥2×2 (≥2 rejillas × ≥2 semillas)**, pero aporta **evidencia cuantitativa de robustez** con los datos existentes.

## A) Lazo FR 2π — sensibilidad a ruido de fase por **enlace**
- Archivo base: `data/overlaps/overlaps_gridA_seed01.npy` (400 pasos).
- Criterio de pase: `|π − |φ_net|| ≤ 0.1π` (mismo umbral de S.4).
- Procedimiento: para cada ensayo, se perturba **cada solapamiento** con ruido de fase εₖ ∼ 𝒩(0, σ) y se recalcula la fase neta envuelta.
- Distancia a π observada:
  - Desde overlaps: **2.760465e-06 rad**
  - Desde consolidado CSV: **1.638882e-06 rad**
- **Tasa de pase** (1000 ensayos por σ):
  - σ=0.001 rad → **100.0% PASS**
  - σ=0.005 rad → **100.0% PASS**
  - σ=0.01 rad → **100.0% PASS**
  - σ=0.05 rad → **100.0% PASS**
  - σ=0.1 rad → **97.0% PASS**
  - σ=0.2 rad → **71.7% PASS**
  - σ=0.3 rad → **51.7% PASS**

## B) Espectro rotacional E ≈ a·j(j+1) + b
- Datos: `data/original/spin_spectrum_levels.csv` (n=8 niveles).
- **R² (ajuste completo)**: **0.998698**
- **LOOCV R²** (deja-uno-fuera): **0.997635**
- **Bootstrap R² (95% CI)**: **[0.996116, 0.999874]** (media 0.998590)
- Todo por encima del umbral típico de **0.98**, indicando **estabilidad** del ajuste.

## C) Conclusión
Aunque no se cumple el requisito formal **≥2×2** de S.4, los resultados muestran **margen de seguridad amplio** en el lazo 2π y **consistencia** del espectro rotacional bajo validación cruzada y bootstrap.
