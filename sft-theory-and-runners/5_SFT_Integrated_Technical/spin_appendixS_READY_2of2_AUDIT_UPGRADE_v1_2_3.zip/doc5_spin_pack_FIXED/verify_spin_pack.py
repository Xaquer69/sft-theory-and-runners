#!/usr/bin/env python3
"""
verify_spin_pack.py — audit-grade verifier for the Spin / Appendix S CPU pack.

Goals:
  1) Recompute the 2π sign-flip (Berry phase) from overlap .npy files (if present),
     and compare to the provided consolidated CSV.
  2) Validate rotor spectrum fit metrics from provided summaries (no refit unless inputs exist).
  3) Emit a Doc9-style minimal report + SHA-256 manifest.

This script is intentionally conservative: if required inputs are missing, it marks
the corresponding check as INCONCLUSIVE (not FAIL), and explains why.
"""

import json
import os
import hashlib
from pathlib import Path
from math import pi
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_manifest(entries: dict, out_path: Path):
    lines = [f"{h}  {name}" for name, h in sorted(entries.items())]
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def wrap_to_0_2pi(x: float) -> float:
    # map to [0, 2π)
    y = x % (2 * pi)
    return y

def dist_to_pi(x: float) -> float:
    # distance to π on circle [0,2π)
    x = wrap_to_0_2pi(x)
    return abs(x - pi)

def recompute_fr_from_overlaps(data_dir: Path):
    """
    Recompute phase for each overlap array in data/overlaps/*.npy.
    Assumes each file stores complex overlaps along a path; product phase gives net Berry phase.
    """
    overlaps_dir = data_dir / "overlaps"
    if not overlaps_dir.exists():
        return {"status": "INCONCLUSIVE", "reason": "data/overlaps/ not found", "rows": []}

    npy_files = sorted(overlaps_dir.glob("*.npy"))
    if not npy_files:
        return {"status": "INCONCLUSIVE", "reason": "no .npy files in data/overlaps/", "rows": []}

    rows = []
    for f in npy_files:
        arr = np.load(f, allow_pickle=False)
        # Accept shapes (N,) complex or (N,2) float -> interpret as complex
        if np.iscomplexobj(arr):
            overlaps = arr
        else:
            arr = np.asarray(arr)
            if arr.ndim == 2 and arr.shape[1] == 2:
                overlaps = arr[:,0] + 1j * arr[:,1]
            else:
                return {"status": "INCONCLUSIVE", "reason": f"unsupported overlap array shape in {f.name}: {arr.shape}", "rows": []}

        # Net phase from product of overlaps
        prod = np.prod(overlaps.astype(np.complex128))
        phase = float(np.angle(prod))
        phase_0_2pi = wrap_to_0_2pi(phase)
        d_pi = dist_to_pi(phase_0_2pi)
        rows.append({
            "file": f.name,
            "phase_rad": phase_0_2pi,
            "dist_to_pi_rad": d_pi,
            "dist_to_pi_over_pi": d_pi / pi,
        })

    return {"status": "OK", "reason": "", "rows": rows}

def load_consolidated_csv():
    # Prefer LOCAL consolidated if present
    for name in ["FR_2pi_consolidated_LOCAL.csv", "FR_2pi_consolidated_2of2.csv", "FR_2pi_rows_recomputed_v2.csv"]:
        p = HERE / name
        if p.exists():
            return p
    return None

def check_fr_gate(recomputed: dict, tol_over_pi: float = 0.10):
    """Gate: distance-to-π ≤ tol_over_pi * π for all rows."""
    if recomputed["status"] != "OK":
        return {"status": recomputed["status"], "pass": None, "tol_over_pi": tol_over_pi, "n": 0, "failed": 0, "details": recomputed.get("reason", "")}

    rows = recomputed["rows"]
    failed = [r for r in rows if r["dist_to_pi_over_pi"] > tol_over_pi]
    return {
        "status": "OK",
        "pass": len(failed) == 0,
        "tol_over_pi": tol_over_pi,
        "n": len(rows),
        "failed": len(failed),
        "failed_files": [r["file"] for r in failed],
    }

def check_rotor_fit(reports_dir: Path):
    """Validate rotor fit metrics from existing summaries (no refit)."""
    # Look for common summary JSON/CSV
    candidates = [
        reports_dir / "PASS_FAIL_summary.json",
        reports_dir / "spin_rotor_fit_summary.json",
        reports_dir / "rotor_fit_summary.json",
    ]
    for c in candidates:
        if c.exists():
            try:
                data = json.loads(c.read_text(encoding="utf-8"))
                return {"status": "OK", "source": c.name, "data": data}
            except Exception as e:
                return {"status": "INCONCLUSIVE", "reason": f"cannot parse {c.name}: {e}"}

    # CSV fallback
    csv_candidates = [
        HERE / "data" / "spin_spectrum_summary_merged.csv",
        HERE / "_originals" / "data" / "spin_spectrum_summary_merged.csv",
    ]
    for c in csv_candidates:
        if c.exists():
            try:
                df = pd.read_csv(c)
                # Expect R2 column or similar
                cols = [x.lower() for x in df.columns]
                r2_col = None
                for col in df.columns:
                    if col.lower() in ("r2", "r_squared", "fit_r2", "rsq"):
                        r2_col = col
                        break
                if r2_col is None:
                    return {"status": "INCONCLUSIVE", "reason": f"{c.name} present but no R2-like column found"}
                r2 = float(df[r2_col].iloc[0])
                return {"status": "OK", "source": c.name, "data": {"r2": r2}}
            except Exception as e:
                return {"status": "INCONCLUSIVE", "reason": f"cannot read {c.name}: {e}"}

    return {"status": "INCONCLUSIVE", "reason": "no rotor fit summary found"}

def main():
    data_dir = HERE / "data"
    reports_dir = HERE / "reports"
    out_dir = HERE / "_VERIFY_OUT"
    out_dir.mkdir(exist_ok=True)

    # Recompute FR from overlaps
    fr_recomputed = recompute_fr_from_overlaps(data_dir)
    fr_gate = check_fr_gate(fr_recomputed, tol_over_pi=0.10)

    # Rotor fit (existing summaries)
    rotor = check_rotor_fit(reports_dir)

    # Combine verdict
    checks = {
        "FR_2pi_signflip": fr_gate,
        "rotor_fit": rotor,
    }

    # GLOBAL_PASS logic: only if all determinate checks are PASS and none FAIL
    determinate = [v for v in checks.values() if isinstance(v, dict) and v.get("pass") is not None]
    any_fail = any(v.get("pass") is False for v in determinate)
    all_pass = (len(determinate) > 0) and all(v.get("pass") is True for v in determinate)
    global_pass = all_pass and not any_fail

    report = {
        "verifier": "verify_spin_pack.py",
        "version": "v1.0",
        "global_pass": bool(global_pass),
        "notes": "INCONCLUSIVE checks do not force FAIL; they indicate missing inputs for recomputation.",
        "checks": checks,
    }

    report_path = out_dir / "VERIFY_SPIN_REPORT.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Write a manifest
    manifest_entries = {
        "verify_spin_pack.py": sha256_file(Path(__file__)),
        "VERIFY_SPIN_REPORT.json": sha256_file(report_path),
    }
    # Include consolidated CSV if present
    c = load_consolidated_csv()
    if c is not None:
        manifest_entries[c.name] = sha256_file(c)

    # Include any overlap files used
    overlaps_dir = data_dir / "overlaps"
    if overlaps_dir.exists():
        for f in sorted(overlaps_dir.glob("*.npy")):
            manifest_entries[f"data/overlaps/{f.name}"] = sha256_file(f)

    # Include rotor summaries if present
    if (reports_dir / "PASS_FAIL_summary.json").exists():
        manifest_entries["reports/PASS_FAIL_summary.json"] = sha256_file(reports_dir / "PASS_FAIL_summary.json")

    manifest_path = out_dir / "VERIFY_SPIN_MANIFEST_SHA256.txt"
    write_manifest(manifest_entries, manifest_path)

    print(f"[VERIFY] global_pass={report['global_pass']}")
    print(f"[VERIFY] report: {report_path}")
    print(f"[VERIFY] manifest: {manifest_path}")

if __name__ == "__main__":
    main()
