# Reproducibility (CPU-only)

This package provides all **analysis artifacts** and scripts to verify the key claims (Appendix S): the **2π sign flip** and the **rotational spectrum** fit \(E \propto j (j+1)\), without requiring a GPU.

## Quick start

```bash
# 1) Verify file integrity
sha256sum -c checksums_SHA256.txt

# 2) Run the end-to-end CPU pipeline (Appendix S partial bundle)
# NOTE: This bundle is partial (e.g., single grid/seed) unless explicitly labeled otherwise.
python scripts/spin_pipeline.py   --overlaps data/overlaps   --grid_id gridA   --L 8   --dx 0.125   --AMR 1   --seed 1   --smoothing 0   --K 120   --levels_csv data/original/spin_spectrum_levels.csv   --summary_out reports/spin_spectrum_summary.csv   --overlap_out reports/spin_overlap_results.csv \
  --provenance_out json/spin_provenance_LOCAL.json

# 3) Audit-grade verifier (recomputes FR from overlaps if available; validates rotor-fit summaries)
python verify_spin_pack.py
```



Then run the analysis scripts (examples):

```bash
# 2π sign flip analysis
python scripts/sft_spin_FR_analyzer.py --input data --out reports

# Rotational spectrum fit
python scripts/sft_spin_rotor_inertia_fit.py --input data --out reports
```

> If your system lacks `scripts/` paths or exact names, check the package `scripts/` folder; the commands above are representative. All computations are **NumPy/Pandas CPU** operations.

## Data integrity

- All file SHA-256 hashes are recorded in `checksums_SHA256.txt`.
- Extra duplicates (if any existed in the source ZIP) were preserved under `/_duplicates/`.
- Originals of any CSVs that were cleaned to remove example rows are preserved under `/_originals/` with the same relative path.

## Expected results

- **2π sign flip**: The net phase error \(|\pi - \phi_{net}|\) should be \(\ll 0.1\pi\) on the provided runs.
- **Rotational spectrum**: A linear fit of \(\Delta E\) vs. \(j(j+1))\) should yield \(R^2 \gtrsim 0.98\) on the provided consolidated CSVs.

Small floating-point differences are expected across platforms (tolerances: `rtol=1e-4`, `atol=1e-6`).

## Provenance

- A machine-readable inventory is in `/_meta/MANIFEST.json`.


## Note on robustness (Appendix S.4)
This bundle is **partial** (e.g., single grid/seed) unless explicitly labeled otherwise. For full robustness, provide ≥2 grids and ≥2 seeds and rerun the pipeline and verifier.
