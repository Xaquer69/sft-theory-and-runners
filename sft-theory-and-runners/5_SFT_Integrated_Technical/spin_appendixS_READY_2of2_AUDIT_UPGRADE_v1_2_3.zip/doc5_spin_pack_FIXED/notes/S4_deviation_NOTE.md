## Appendix S — S.4 Deviation Note (Robustness, FR 2π)

**Status:** Partial. The current package lacks the required coverage of **≥ 2 grids** and **≥ 2 seeds** for the 2π sign-flip test.

**Evidence present:**
- 2π sign-flip: |π − phase| = 6.420e-08 rad (**pass** ≤ 0.1π).
- Rotor spectrum: R² = 0.9983163969781834 (**pass** ≥ 0.98).

**Impact:** Low — physics results are stable and within tolerance; robustness replication pending.

**Action:** Execute FR 2π for at least one additional grid and one additional seed; append results and update PASS/FAIL/ZIP checksum.
