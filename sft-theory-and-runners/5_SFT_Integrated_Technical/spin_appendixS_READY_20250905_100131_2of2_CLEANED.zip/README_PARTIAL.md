# Spin FR/Rotors — Package (Partial Compliance)

This package **passes** the physics checks but **does not** meet Appendix S **S.4 robustness (≥2 grids & ≥2 seeds)**.

## What passes
- **Sign-flip (2π):** |π − phase| = 6.420e-08 rad, steps = 400, pass ≤ 0.1π = True.
- **Rotor spectrum:** R² = 0.9983163969781834 (≥ 0.98 = True), Î ≈ 3.2230395339573708; intercept ≈ 6.302075867572488e-05.

## What is missing (S.4)
- FR 2π **robustness** with **≥ 2 grids** *and* **≥ 2 seeds**. Current coverage: rows=1, grids=1, seeds=1 (all rows pass: True).

## How to complete S.4 (next run plan)
1. Add FR 2π for **gridA/seed2**, **gridB/seed1**, **gridB/seed2** (either overlaps `.npy` including closure, or spinor path CSV).
2. Append rows to `spin_overlap_results.csv` with fields: `grid_id, seed_id, loop_label=2pi, net_phase_wrapped_rad or phase_rad, distance_to_pi_rad, tolerance_rad, pass`.
3. Recompute `PASS_FAIL_summary.json` and ZIP + SHA-256.

---
This README is auto-generated here to document the current status.


---

## S.4-lite (robustez numérica) y exención solicitada

Este paquete **no** cumple el requisito formal de S.4 (≥2 rejillas × ≥2 semillas). Sin embargo, se incluye **evidencia de robustez** en:
- `docs/S4_lite_robustness.md` — sensibilidad Monte Carlo del lazo FR 2π y validaciones del espectro.
- `docs/S4_waiver.md` — texto de **excepción acotada** propuesto.
- `reports/S4_lite_stats.json` — métricas en formato máquina.

**Estado:** *Partial compliance + mitigation*. Si se añaden una rejilla y una semilla adicionales al lazo 2π, este paquete puede actualizarse a **FULL** sin tocar el resto.
