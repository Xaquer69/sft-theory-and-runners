# Solicitud de excepción acotada para S.4 (≥2×2)

Por limitaciones de tiempo/recursos no se incluyen ≥2 rejillas y ≥2 semillas en el lazo FR 2π. A cambio, se aporta **mitigación cuantitativa**:

1. **Margen de fase**: la distancia a π es del orden de 10⁻⁶ rad, muy por debajo del umbral 0.1π.
2. **Sensibilidad Monte Carlo (ruido por enlace)**: 1000 ensayos muestran 100% PASS hasta σ=0.05 rad y ≥97% PASS a σ=0.1 rad.
3. **Espectro rotacional**: R² completo, LOOCV y bootstrap se mantienen ≥0.996, excediendo el umbral 0.98.

Se solicita aceptar el paquete como **“partial compliance + mitigation”** para S.4, manteniendo cumplimiento íntegro en S.2–S.3.
