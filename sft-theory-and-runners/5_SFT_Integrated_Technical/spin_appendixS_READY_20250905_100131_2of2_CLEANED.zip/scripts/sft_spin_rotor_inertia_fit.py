
import json, numpy as np, pandas as pd
def fit_inertia(csv_path, out_json=None):
    df = pd.read_csv(csv_path)
    w = df["omega"].to_numpy(); dE = df["delta_E"].to_numpy()
    X = w**2
    A = np.vstack([X, np.ones_like(X)]).T
    slope, intercept = np.linalg.lstsq(A, dE, rcond=None)[0]
    dE_hat = slope*X + intercept
    r2 = 1 - np.sum((dE-dE_hat)**2)/np.sum((dE-dE.mean())**2)
    I_hat = 2*slope
    res = {"I_hat": float(I_hat), "intercept": float(intercept), "R2": float(r2),
           "num_points": int(len(w))}
    if out_json:
        with open(out_json,"w") as f: json.dump(res,f,indent=2)
    return res
