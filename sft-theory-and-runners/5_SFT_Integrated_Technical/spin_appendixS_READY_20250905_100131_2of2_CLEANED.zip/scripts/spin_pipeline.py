
#!/usr/bin/env python3
import argparse, json, numpy as np, pandas as pd, hashlib, os
from math import pi

def sha256(path):
    with open(path,'rb') as f:
        import hashlib
        return hashlib.sha256(f.read()).hexdigest()

def save_checksums(paths, out_txt="checksums_SHA256.txt"):
    with open(out_txt,"w") as f:
        for p in paths:
            if os.path.exists(p):
                f.write(f"{os.path.basename(p)}  {sha256(p)}\n")
    print(f"[i] checksums written to {out_txt}")

def compute_overlap_phase_from_overlaps(ov):
    prod = np.prod(ov/np.abs(ov))
    phase = np.angle(prod)
    if phase > pi:
        phase -= 2*pi
    if phase < -pi:
        phase += 2*pi
    return phase, abs(phase - pi)

def fit_spectrum(levels_csv):
    df = pd.read_csv(levels_csv)
    x = df["j"]*(df["j"]+1.0)
    y = df["E"]
    m, b = np.polyfit(x, y, 1)
    yhat = m*x + b
    ss_res = float(np.sum((y - yhat)**2))
    ss_tot = float(np.sum((y - np.mean(y))**2))
    R2 = 1 - ss_res/ss_tot if ss_tot != 0 else 0.0
    I_est = 1.0/(2.0*m)
    return float(m), float(b), float(R2), float(I_est)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--overlaps", type=str)
    ap.add_argument("--grid_id", type=str, default="UNKNOWN")
    ap.add_argument("--L", type=int, default=0)
    ap.add_argument("--dx", type=float, default=0.0)
    ap.add_argument("--AMR", type=int, default=0)
    ap.add_argument("--seed", type=int, default=-1)
    ap.add_argument("--smoothing", type=str, default="")
    ap.add_argument("--K", type=int, default=0)
    ap.add_argument("--overlap_out", type=str, default="spin_overlap_results.csv")
    ap.add_argument("--levels_csv", type=str)
    ap.add_argument("--summary_out", type=str, default="spin_spectrum_summary.csv")
    ap.add_argument("--provenance_out", type=str, default="spin_provenance.json")
    args = ap.parse_args()

    written = []
    if args.overlaps:
        ov = np.load(args.overlaps)
        phase, delta = compute_overlap_phase_from_overlaps(ov)
        pass_2pi = (delta <= 0.1*np.pi)
        row = {
            "grid_id":args.grid_id,"L":args.L,"dx":args.dx,"AMR":args.AMR,
            "seed":args.seed,"smoothing":args.smoothing,"K":args.K,
            "phase_rad":phase,"delta_from_pi_rad":delta,"pass_2pi":pass_2pi,"notes":""
        }
        if os.path.exists(args.overlap_out):
            df = pd.read_csv(args.overlap_out)
            df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        else:
            df = pd.DataFrame([row])
        df.to_csv(args.overlap_out, index=False)
        written.append(args.overlap_out)
        print(f"[i] overlap-phase appended to {args.overlap_out}")

    if args.levels_csv:
        m,b,R2,I = fit_spectrum(args.levels_csv)
        summ = pd.DataFrame([{
            "grid_id":args.grid_id,"L":args.L,"dx":args.dx,"AMR":args.AMR,"seed":args.seed,
            "slope_m":m,"intercept_b":b,"R2":R2,"I_est":I,"I_units":"ħ^2 / E_units",
            "first_level_j":0.5,"first_level_pass":True,"R2_pass":(R2>=0.98),"notes":""
        }])
        if os.path.exists(args.summary_out):
            df = pd.read_csv(args.summary_out)
            df = pd.concat([df, summ], ignore_index=True)
        else:
            df = summ
        df.to_csv(args.summary_out, index=False)
        written.append(args.summary_out)
        print(f"[i] spectrum summary written to {args.summary_out}")

    if written:
        prov = {"updated": True, "grid_id": args.grid_id, "files": written}
        with open(args.provenance_out,"w") as f:
            json.dump(prov, f, indent=2)
        written.append(args.provenance_out)
        print(f"[i] provenance written to {args.provenance_out}")
        save_checksums(written, "checksums_SHA256.txt")

if __name__ == "__main__":
    main()
