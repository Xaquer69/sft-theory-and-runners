
import json, numpy as np, pandas as pd
def berry_phase_from_spinor_csv(csv_path, out_json=None):
    df = pd.read_csv(csv_path)
    z1 = df["z1_re"].to_numpy() + 1j*df["z1_im"].to_numpy()
    z2 = df["z2_re"].to_numpy() + 1j*df["z2_im"].to_numpy()
    norms = np.sqrt((z1*np.conj(z1) + z2*np.conj(z2)).real); z1/=norms; z2/=norms
    z = np.vstack([z1,z2]).T

    # Overlaps including the closing link
    overlaps = np.sum(np.conj(z[:-1]) * z[1:], axis=1)
    closing = np.vdot(z[-1], z[0])
    total_phase = np.angle(np.prod(overlaps) * closing)

    # Map to [-pi, pi]
    total_phase = (total_phase + np.pi) % (2*np.pi) - np.pi
    final_overlap = closing
    res = {"berry_phase_rad": float(total_phase),
           "berry_phase_pi": float(total_phase/np.pi),
           "final_overlap_arg_pi": float(np.angle(final_overlap)/np.pi),
           "final_overlap_mag": float(np.abs(final_overlap)),
           "num_steps": int(z.shape[0])}
    if out_json:
        with open(out_json,"w") as f: json.dump(res,f,indent=2)
    return res
