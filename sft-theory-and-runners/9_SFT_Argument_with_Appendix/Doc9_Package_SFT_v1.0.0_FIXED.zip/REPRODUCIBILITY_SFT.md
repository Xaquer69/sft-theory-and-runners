
# Reproducibility — SFT unified (Doc 9, v1.0.0)

This package follows Doc 9's *Reviewer Quick Start* and Quick Audit Table. It is **CPU‑only** for the quick checks and ships with hashes and a manifest for external auditing.

## Quick start (Option A — Python)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -U numpy pandas scipy matplotlib pytest
pytest -q || true  # optional if tests are included
```

## Quick start (Option B — Docker)
See `docker/` if present in this package. Example:
```bash
docker build -t sft-min-valid:0.9 docker/
docker run --rm -v $PWD:/work -w /work sft-min-valid:0.9 python scripts/generate_smoke_artifacts.py
```

## What to verify (shortlist)
- **EOC synthetic (CPU):** slope p ≈ 1.8–2.0, CI95% within [1.70, 2.05], R² ≥ 0.995.
- **Venus (synthetic):** `|slope − 8.624984| ≤ 0.2` arcsec/century, `R² ≥ 0.999`.
- **Spin‑½ spectrum:** fit R² ≥ 0.98, first level `j = 1/2`. (FR 2π optional if overlaps provided.)
- **Energy accounting (if provided):** ΔE_rel ≤ 1e−3 and continuity residuals recorded.
- **PPN (if provided):** conventions (−,+,+,+), bridge `S ≡ −U`; report β, γ with CI.

## Integrity
All files in this archive are listed in `/_meta/MANIFEST.json` and hashed in `checksums_SHA256.txt`. Duplicates (if any) from upstream are preserved in `/_duplicates/`.
