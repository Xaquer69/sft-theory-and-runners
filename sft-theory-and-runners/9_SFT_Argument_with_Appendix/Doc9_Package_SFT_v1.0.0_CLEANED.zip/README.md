# SFT — Doc 9 Review Package (v1.0.0)
Timestamp (UTC): 2025-09-15 14:50:24Z

## Contents
- **Doc9/**: main document for reviewers (prefer the _with_Appendix version if present).
- **Appendices/**: addenda (English consistency notes; JSON snippets guide).
- **Schemas/**: JSON Schemas for `PPN_RESULTS.json` and `ENERGY_REPORT.json`.
- **Examples/**: ready‑made example JSONs for both artifacts.
- **Templates/**: blank JSON templates and a (Spanish) folder template document.
- **scripts/**: helper scripts for quick checks and checksums.
- **MANIFEST_SHA256.txt**: checksums for all files in this zip.

## Quick Start (reviewers)
1. Open **Doc9/9_SFT_Argument_with_Appendix.docx** (or the available Doc9) and skim the Quick Start + Appendix.
2. Validate example artifacts against **Schemas/** using any JSON Schema validator.
3. Optionally run **scripts/quick_audit.py** on the **Examples/** folder to produce a minimal `quick_audit_report.json`.
4. Use **MANIFEST_SHA256.txt** to verify file integrity.

## Notes
- Conventions: φ ≡ U/c² (dimensionless), S ≡ −U; PPN extraction via (a1,c1,a2) → γ=c1/a1, β=1+a2/a1².
- Figures/CSV are not included; `artifacts_sha256` fields in example JSONs show where they would be referenced.
