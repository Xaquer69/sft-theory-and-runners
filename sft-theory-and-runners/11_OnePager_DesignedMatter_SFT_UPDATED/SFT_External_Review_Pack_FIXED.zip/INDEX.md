# SFT External Review Pack — FINAL
Generated: 2026-02-04 17:12 UTC (FIXED)

This pack is CPU-only and contains:
- `docs/OnePager_DesignedMatter_SFT_UPDATED.docx` (overview + addendum)
- `runners/synthetic_atom_existence_runner_pack_WITH_NORMALIZED_FIXED_SHA_v3.zip` (AtomX runner, split = 0.19, with per-pack checksums)

## How to verify quickly
1) Verify global manifest (this pack): open `MANIFEST_SHA256.txt` and check each hash.
2) Open the runner ZIP and verify its internal `checksums_SHA256.txt` (all entries should be OK).
3) In the runner ZIP, inspect:
   - `out_demo/EXISTENCE_REPORT_atomX.json` → ensure `thresholds.split_thr = 0.19`.
   - `out_demo/COMPATIBILITY_SCAN_atomX.json` → ensure `split_thr = 0.19`.
   - `out_demo/EXISTENCE_REGION_atomX.json` → region matches REPORT verdict.
4) Read `docs/OnePager_DesignedMatter_SFT_UPDATED.docx` for context and criteria.

## Notes
- All artifacts are CPU-checkable; no CUDA required.
- The global manifest excludes itself from hashing (no self-reference).

### Update (spin-½)
- Añadido `runners/SFT_compatibility_scan_spin12_demo_WITH_FROM_SCAN.zip` con `EXISTENCE_REGION_spin12_from_SCAN.json` y `EXISTENCE_REPORT_spin12_from_SCAN.json` (verdict=maintained, witness incluido).
- Se crearon `SFT_master_validation_table.json/.csv` con hashes y estado de cada runner.

### Update (Hydrogen)
- Añadido `runners/hydrogen_existence_runner_pack_WITH_FROM_SCAN.zip` con `COMPATIBILITY_SCAN_H.json`, `EXISTENCE_REGION_H_from_SCAN.json` y `EXISTENCE_REPORT_H_NORMALIZED.json` (verdict=maintained, witness=anchor_strength=0.02).

### Fix note (2026-02-04)
- Replaced AtomX runner ZIP with v3: regenerated `out_demo` from `runner/run_atomX.py --demo` so REGION/REPORT are consistent.
- Updated global MANIFEST_SHA256 and master validation table.
