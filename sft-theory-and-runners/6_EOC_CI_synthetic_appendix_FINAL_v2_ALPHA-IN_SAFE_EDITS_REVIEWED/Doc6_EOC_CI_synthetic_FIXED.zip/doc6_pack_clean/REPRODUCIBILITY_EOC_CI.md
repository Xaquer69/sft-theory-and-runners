# Reproducibility — EOC (synthetic, CI/CPU-only)

Thresholds: 1.70 ≤ p ≤ 2.05 and R² ≥ 0.995; errors strictly decreasing.
Run `python verify_eoc_ci.py` after installing numpy/pandas.
