# EOC/CI Synthetic Appendix — Verification README
_Last updated: 2025-09-01 11:35 UTC_

## Scope
This package provides a **CPU-only, synthetic** convergence (EOC) sanity check for the solver.  
**It is *not* used to support scientific claims** in the manuscript; it serves Continuous Integration (CI) health checks.

## PASS/FAIL Policy
A run **PASS**es if **all** of the following are true:
- Observed order **p** satisfies **1.70 ≤ p ≤ 2.05**
- Linear fit quality **R² ≥ 0.995** on log–log (error vs h)
- **Monotonic decrease** of error as resolution increases (N↑, h=1/N↓)

We adopt the **canonical sign** convention with **h = 1/N**, so p should be **positive** near 2 for a 2nd‑order scheme.

## Protocol (recommended defaults)
- CFL = 0.25  
- Boundary Conditions = **periodic**  
- AMR = **off** (uniform meshes)  
- Norm = **L2** at a fixed final time **t_f** (e.g., 200 t₀)  
- Grids: N ∈ {32, 48, 64, 96, 128} (or similar)  
- Seed (if any stochasticity): **12345**

## Repro Steps (no extraction needed)
You can compute the SHA‑256 of each member without unzipping and recompute EOC metrics with this Python snippet:

```python
import zipfile, hashlib, io, numpy as np, pandas as pd, math

def sha256_member(zf, name):
    h = hashlib.sha256()
    with zf.open(name, "r") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

zf = zipfile.ZipFile("Doc 6_EOC_CI_synthetic.zip", "r")
for m in zf.infolist():
    if not m.is_dir():
        print(sha256_member(zf, m.filename), " ", m.filename)
```

To recompute **p** and **R²**, point to the EOC CSV(s) inside the ZIP and run a log–log linear fit on error vs h (with h=1/N).

## Repro Steps (with extraction)
```bash
unzip -o "Doc 6_EOC_CI_synthetic.zip" -d ./eoc_zip
cd eoc_zip
sha256sum -c ../EOC_MANIFEST_SHA256.txt  # expects "HASH␠␠PATH" lines
```

Then run your preferred EOC script on the extracted CSV(s).

## Provenance & Traceability
- This README includes the **PASS/FAIL policy** and **protocol** so the package is self‑contained.
- `EOC_MANIFEST_SHA256.txt` lists **SHA‑256** for each file *inside* the ZIP; keep both files together when sharing with reviewers.
- If you add new CSVs, regenerate the manifest and re‑run the EOC check.

---
Contact: maintainers of the SFT/DSM CI pipeline
