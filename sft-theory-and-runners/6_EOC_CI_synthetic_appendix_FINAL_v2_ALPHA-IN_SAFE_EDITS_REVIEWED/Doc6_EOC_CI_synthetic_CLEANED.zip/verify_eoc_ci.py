import json, numpy as np, pandas as pd
df=pd.read_csv('EOC_synthetic.csv')
x=np.log(1.0/df['N'].astype(float).values); y=np.log(df['error'].astype(float).values)
a1,a0=np.polyfit(x,y,1); p=float(a1); yhat=a1*x+a0
ss_res=float(np.sum((y-yhat)**2)); ss_tot=float(np.sum((y-y.mean())**2)); r2=float(1-ss_res/ss_tot)
n=len(x); se=float(np.sqrt(ss_res/(n-2))/np.sqrt(np.sum((x-x.mean())**2)))
ci=[float(p-1.96*se), float(p+1.96*se)]
mono=bool(np.all(np.diff(df.sort_values('N')['error'].values.astype(float))<0))
out={'p_hat':p,'R2':r2,'CI95':ci,'monotonic_errors':mono,'GLOBAL_PASS': (1.70<=p<=2.05 and r2>=0.995 and mono)}
print(json.dumps(out, indent=2))
