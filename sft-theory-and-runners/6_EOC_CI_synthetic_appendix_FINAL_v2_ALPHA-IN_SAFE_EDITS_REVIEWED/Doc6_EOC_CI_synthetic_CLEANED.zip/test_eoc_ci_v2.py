import numpy as np
import pandas as pd

P_MIN, P_MAX = 1.700, 2.05
R2_MIN = 0.995

def test_eoc_ci_synthetic():
    df = pd.read_csv("EOC_synthetic.csv")  # columnas: N,error (o n,error)
    cols = {c.lower(): c for c in df.columns}
    N_col = cols.get("n", list(df.columns)[0])
    E_col = cols.get("error", list(df.columns)[1])
    N = df[N_col].to_numpy(dtype=float)
    err = df[E_col].to_numpy(dtype=float)

    x = np.log(1.0 / N)           # h = 1/N
    y = np.log(err)
    m, b = np.polyfit(x, y, 1)    # m = p
    yhat = m * x + b
    R2 = 1 - ((y - yhat)**2).sum() / ((y - y.mean())**2).sum()

    order = np.argsort(N)
    mono_ok = np.all(np.diff(err[order]) < 0)

    assert P_MIN <= m <= P_MAX, f"p={m:.4f} fuera de [{P_MIN},{P_MAX}]"
    assert R2 >= R2_MIN, f"R^2={R2:.4f} < {R2_MIN}"
    assert mono_ok, "El error no decrece monótonamente con N"

    print(f"[CI EOC] PASS: p={m:.4f}, R^2={R2:.4f}, monotonic={mono_ok}")
